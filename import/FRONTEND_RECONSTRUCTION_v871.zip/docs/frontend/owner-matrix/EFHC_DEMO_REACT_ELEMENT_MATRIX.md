# Матрица миграции HTML v866 → React v870

30 октября 2026. FRONTEND_v866.html — замороженный визуальный канон. FRONTEND_RECONSTRUCTION_v870.zip — текущий код Test-3 по прямому подтверждению OWNER.

SHA-256 v870: `449a5db3cf41479ba8eea5723a87ba7f8bc028455ec684384b77b3bf334c9b25`
SHA-256 HTML-канона: `9b6371f5fb62939596b78206f95031c447e9f2b375e62b30704403bb25102aef`

## Что подтверждено

- Реестр сохранён: 777 статических элементов HTML, 30 областей, 57 динамических функций; React route table содержит 43 маршрута.
- В frontend/src между v866 и v870: 6 изменённых, 4 новых, 0 удалённых файлов. Все 33 CSS-файла побайтово совпадают. Это не доказательство тождественности всего рендера: Layout/_app и входные данные изменены.
- Адаптеры данных Панелей, Рангов и Заданий уже существуют. Четыре текущих теста их инвариантов прошли. Их нельзя выдавать за полный browser/data parity.
- Подключение fixtures зависит от двух build-флагов, runtime-флага и отсутствия globalId. Все условия указаны в JSON; фактические флаги опубликованной страницы не проверены.
- Различие точности Рангов сохраняется: HTML format8 против React formatFixedDown(..., 2). Номера мест сами по себе не объявляются дефектом: helper React возвращает обычные цифры.
- Малый Kernel реконструкции: PASS, без изменений. Замороженный HTML совпадает с SHA в SSOT v870.

## Как читать матрицу

Для каждого ID указаны отдельные source_role FROZEN_HTML / REACT_V870, хеши и строки, кандидаты компонентов, состояние проверки и proposed_files. Последние — предложение границ будущего исправления, не разрешение редактирования. SOURCE_CANDIDATE не является подтверждённым визуальным соответствием. REGION_ONLY означает связь лишь с областью страницы. UNRESOLVED не означает, что элемент отсутствует или подлежит удалению.

| Область эталона | React entrypoints | Визуальная проверка |
|---|---|---|
| efhcOwner0562Splash | UNRESOLVED | NOT_RUN |
| energyPage | frontend/src/pages/index.tsx | NOT_RUN |
| panelsPage | frontend/src/pages/panels.tsx | NOT_RUN |
| panelsPortfolioPage | frontend/src/pages/panels/portfolio.tsx | NOT_RUN |
| exchangePage | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | NOT_RUN |
| tasksPage | frontend/src/pages/tasks.tsx | NOT_RUN |
| referralsPage | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | NOT_RUN |
| ranksPage | frontend/src/pages/ranks.tsx | NOT_RUN |
| referralsMyPage | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals/my.tsx | NOT_RUN |
| profilePage | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | NOT_RUN |
| profileSettingsOverlay | frontend/src/components/ProfileModal.tsx | NOT_RUN |
| profileAvatarOverlay | frontend/src/components/profile/AvatarPreferenceEditor.tsx | NOT_RUN |
| hubPage | frontend/src/features/hub/HubPage.tsx; frontend/src/pages/hub.tsx | NOT_RUN |
| withdrawPage | frontend/src/pages/withdraw.tsx | NOT_RUN |
| withdrawRequiredAdOverlay | UNRESOLVED | NOT_RUN |
| faqPage | frontend/src/pages/faq.tsx | NOT_RUN |
| languageLabPage | UNRESOLVED | NOT_RUN |
| adsPage | frontend/src/pages/ads.tsx | NOT_RUN |
| errorPage | frontend/src/pages/404.tsx; frontend/src/pages/500.tsx | NOT_RUN |
| adminPage | frontend/src/pages/admin/index.tsx | NOT_RUN |
| adminWithdrawalsPage | frontend/src/pages/admin/withdrawals.tsx | NOT_RUN |
| adminWithdrawDecisionOverlay | UNRESOLVED | NOT_RUN |
| adminAdsPage | UNRESOLVED | NOT_RUN |
| adminUsersPage | frontend/src/pages/admin/users.tsx | NOT_RUN |
| adminShopPage | frontend/src/pages/admin/shop.tsx | NOT_RUN |
| adminBankPage | frontend/src/pages/admin/bank.tsx | NOT_RUN |
| adminBonusesPage | frontend/src/components/admin/AdminBonusesAnalytics.tsx; frontend/src/pages/admin/bonuses.tsx | NOT_RUN |
| adminDetailPage | UNRESOLVED | NOT_RUN |
| adminApiWorkbenchPage | frontend/src/pages/admin/api-workbench.tsx | NOT_RUN |
| global-shell | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | NOT_RUN |

## Поэлементная матрица

| Element ID | Элемент | React-кандидат | Статус |
|---|---|---|---|
| demo.efhcOwner0562Splash.efhcOwner0562Splash | EFHC загрузка | — | UNRESOLVED |
| demo.efhcOwner0562Splash.node-73 | efhc-splash-inner | — | UNRESOLVED |
| demo.efhcOwner0562Splash.node-74 | img | — | UNRESOLVED |
| demo.efhcOwner0562Splash.node-75 | EFHC | — | UNRESOLVED |
| demo.efhcOwner0562Splash.node-76 | efhc-splash-loading | — | UNRESOLVED |
| demo.efhcOwner0562Splash.efhcOwner0562Percent | 0% | — | UNRESOLVED |
| demo.efhcOwner0562Splash.node-79 | efhc-splash-rail | — | UNRESOLVED |
| demo.efhcOwner0562Splash.efhcOwner0562Fill | efhcOwner0562Fill | — | UNRESOLVED |
| demo.global-shell.frontendWorkspace | frontendWorkspace | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-83 | preview-column | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-84 | unified-shell | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-85 | efhc-independent-shell | frontend/src/components/Layout.tsx:734 | SOURCE_CANDIDATE |
| demo.global-shell.node-86 | efhc-independent-shell_frame | frontend/src/components/Layout.tsx:748 | SOURCE_CANDIDATE |
| demo.global-shell.node-87 | efhc-header-divider | frontend/src/components/GlobalHeader.tsx:293 | SOURCE_CANDIDATE |
| demo.global-shell.node-88 | efhc-game-header | frontend/src/components/GlobalHeader.tsx:300; frontend/src/components/GlobalHeader.tsx:297; frontend/src/components/StatusIndicator.tsx:13 | SOURCE_CANDIDATE |
| demo.global-shell.profileBox | profileBox | frontend/src/components/GlobalHeader.tsx:306 | SOURCE_CANDIDATE |
| demo.global-shell.node-90 | Открыть профиль | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-91 | efhc-game-header_avatar | frontend/src/components/GlobalHeader.tsx:309 | SOURCE_CANDIDATE |
| demo.global-shell.node-92 | efhc-game-header_profile-copy | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-93 | Открыть профиль | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-94 | EFHC Player | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.profileStatusRow | Уровень и статусы пользователя | frontend/src/components/GlobalHeader.tsx:360 | SOURCE_CANDIDATE |
| demo.global-shell.node-96 | Lvl 9 | frontend/src/components/GlobalHeader.tsx:365 | SOURCE_CANDIDATE |
| demo.global-shell.activBadge | Activ | frontend/src/components/GlobalHeader.tsx:360; frontend/src/components/StatusIndicator.tsx:13 | SOURCE_CANDIDATE |
| demo.global-shell.vipBadge | VIP | frontend/src/components/GlobalHeader.tsx:360; frontend/src/components/StatusIndicator.tsx:13 | SOURCE_CANDIDATE |
| demo.global-shell.headerBalance | Открыть баланс | frontend/src/components/GlobalHeader.tsx:173; frontend/src/components/GlobalHeader.tsx:385; frontend/src/components/GlobalHeader.tsx:393; frontend/src/components/GlobalHeader.tsx:392; frontend/src/components/GlobalHeader.tsx:384 | SOURCE_CANDIDATE |
| demo.global-shell.node-100 | svg | frontend/src/components/icons/EfhcCoin.tsx:19 | SOURCE_CANDIDATE |
| demo.global-shell.balanceValue | 12345678.12345678 | frontend/src/components/GlobalHeader.tsx:401 | SOURCE_CANDIDATE |
| demo.global-shell.node-104 | efhc-game-header_actions | frontend/src/components/GlobalHeader.tsx:410 | SOURCE_CANDIDATE |
| demo.global-shell.adminAction | adminAction | frontend/src/components/GlobalHeader.tsx:418 | SOURCE_CANDIDATE |
| demo.global-shell.node-106 | svg | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-110 | efhc-header-action | frontend/src/components/GlobalHeader.tsx:418 | SOURCE_CANDIDATE |
| demo.global-shell.node-111 | svg | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-115 | Кошелёк | frontend/src/components/GlobalHeader.tsx:418 | SOURCE_CANDIDATE |
| demo.global-shell.node-116 | svg | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-118 | Кошелёк | frontend/src/components/GlobalHeader.tsx:443 | SOURCE_CANDIDATE |
| demo.global-shell.node-119 | efhc-header-action | frontend/src/components/GlobalHeader.tsx:418 | SOURCE_CANDIDATE |
| demo.global-shell.node-120 | svg | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-124 | Hub | frontend/src/components/GlobalHeader.tsx:465; frontend/src/components/GlobalHeader.tsx:418 | SOURCE_CANDIDATE |
| demo.global-shell.node-125 | svg | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.headerThemeSlots | headerThemeSlots | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-142 | efhc-main unified-pages | frontend/src/components/Layout.tsx:744 | SOURCE_CANDIDATE |
| demo.energyPage.energyPage | energyPage | frontend/src/pages/index.tsx:503; frontend/src/pages/index.tsx:465 | SOURCE_CANDIDATE |
| demo.energyPage.node-144 | efhc-energy-stage | frontend/src/pages/index.tsx:290; frontend/src/pages/index.tsx:291; frontend/src/pages/index.tsx:287 | SOURCE_CANDIDATE |
| demo.energyPage.node-145 | efhc-energy-stage_image | frontend/src/pages/index.tsx:293 | SOURCE_CANDIDATE |
| demo.energyPage.node-146 | efhc-energy-stage_veil | frontend/src/pages/index.tsx:294 | SOURCE_CANDIDATE |
| demo.energyPage.energyFrameThemeSlots | energyFrameThemeSlots | frontend/src/pages/index.tsx:297 | SOURCE_CANDIDATE |
| demo.energyPage.node-158 | efhc-energy-stage_body | frontend/src/pages/index.tsx:311 | SOURCE_CANDIDATE |
| demo.energyPage.node-159 | Энергия | frontend/src/pages/index.tsx:312 | SOURCE_CANDIDATE |
| demo.energyPage.node-160 | efhc-energy-stage_meter | frontend/src/pages/index.tsx:316 | SOURCE_CANDIDATE |
| demo.energyPage.node-161 | efhc-energy-stage_icon-slot | frontend/src/pages/index.tsx:317 | SOURCE_CANDIDATE |
| demo.energyPage.node-162 | efhc-energy-stage_icon-hit-zone | frontend/src/pages/index.tsx:321; frontend/src/pages/index.tsx:320 | SOURCE_CANDIDATE |
| demo.energyPage.energyIcon | energyIcon | frontend/src/pages/index.tsx:324 | SOURCE_CANDIDATE |
| demo.energyPage.energyValue | 8123.12345678 | frontend/src/pages/index.tsx:332 | SOURCE_CANDIDATE |
| demo.energyPage.node-165 | Всего сгенерировано · kWh | frontend/src/pages/index.tsx:519; frontend/src/pages/index.tsx:345 | SOURCE_CANDIDATE |
| demo.energyPage.node-166 | efhc-energy-stage_progress-head | frontend/src/pages/index.tsx:349 | SOURCE_CANDIDATE |
| demo.energyPage.node-167 | Прогресс | frontend/src/pages/index.tsx:520 | SOURCE_CANDIDATE |
| demo.energyPage.progressPct | 24% | frontend/src/pages/index.tsx:197 | SOURCE_CANDIDATE |
| demo.energyPage.node-169 | efhc-energy-stage_progress-zone | frontend/src/pages/index.tsx:358; frontend/src/pages/index.tsx:357 | SOURCE_CANDIDATE |
| demo.energyPage.progressTrack | progressTrack | frontend/src/pages/index.tsx:364; frontend/src/pages/index.tsx:365; frontend/src/pages/index.tsx:362 | SOURCE_CANDIDATE |
| demo.energyPage.progressFill | progressFill | frontend/src/pages/index.tsx:237 | SOURCE_CANDIDATE |
| demo.energyPage.node-172 | efhc-energy-stage_level | frontend/src/pages/index.tsx:374 | SOURCE_CANDIDATE |
| demo.energyPage.energyLevelLabel | Lvl 9 | frontend/src/pages/index.tsx:375 | SOURCE_CANDIDATE |
| demo.energyPage.node-176 | efhc-energy-stage_range | frontend/src/pages/index.tsx:381 | SOURCE_CANDIDATE |
| demo.energyPage.progressNumber | 1 876.87654322 kWh | frontend/src/pages/index.tsx:387; frontend/src/pages/index.tsx:386 | SOURCE_CANDIDATE |
| demo.energyPage.node-180 | efhc-energy-stage_chips | frontend/src/pages/index.tsx:401 | SOURCE_CANDIDATE |
| demo.energyPage.node-181 | efhc-energy-chip | frontend/src/pages/index.tsx:405 | SOURCE_CANDIDATE |
| demo.energyPage.node-182 | Активных панелей | frontend/src/pages/index.tsx:523 | SOURCE_CANDIDATE |
| demo.energyPage.panelCount | 12 | frontend/src/pages/index.tsx | REGION_ONLY |
| demo.energyPage.node-184 | efhc-energy-chip | frontend/src/pages/index.tsx:413; frontend/src/pages/index.tsx:405 | SOURCE_CANDIDATE |
| demo.energyPage.node-186 | Генерация | frontend/src/pages/index.tsx:522 | SOURCE_CANDIDATE |
| demo.energyPage.rateValue | 0.00001337 | frontend/src/pages/index.tsx | REGION_ONLY |
| demo.energyPage.node-189 | efhc-energy-chip | frontend/src/pages/index.tsx:405 | SOURCE_CANDIDATE |
| demo.energyPage.node-190 | Доступно kWh | frontend/src/pages/index.tsx:524 | SOURCE_CANDIDATE |
| demo.energyPage.availableValue | 421.12500000 | frontend/src/pages/index.tsx | REGION_ONLY |
| demo.panelsPage.panelsPage | panelsPage | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.panelsHero | panelsHero | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-194 | panels-hero-head | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-195 | min-w-0 | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-196 | Энергетические модули | frontend/src/pages/panels.tsx:152 | SOURCE_CANDIDATE |
| demo.panelsPage.node-197 | Панели | frontend/src/pages/panels.tsx:153 | SOURCE_CANDIDATE |
| demo.panelsPage.generationTier | VIP | frontend/src/pages/panels.tsx:72 | SOURCE_CANDIDATE |
| demo.panelsPage.node-199 | panels-generation-tier-dot | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.generationTierText | VIP | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-201 | panels-stats | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-202 | panels-stat | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-203 | Активных | frontend/src/pages/panels.tsx:172 | SOURCE_CANDIDATE |
| demo.panelsPage.activeCount | 60 | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-205 | panels-stat | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-206 | Общая генерация | frontend/src/pages/panels.tsx:176 | SOURCE_CANDIDATE |
| demo.panelsPage.effectiveRate | 0.00001482 kWh/с | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-208 | panels-stat | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-209 | Генерация | frontend/src/pages/panels.tsx:184 | SOURCE_CANDIDATE |
| demo.panelsPage.generationRate | 0.00000741 kWh/с | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-211 | panels-card panels-activation-card | frontend/src/pages/panels.tsx:200 | SOURCE_CANDIDATE |
| demo.panelsPage.node-212 | Активация панели | frontend/src/pages/panels.tsx:84 | SOURCE_CANDIDATE |
| demo.panelsPage.node-213 | activation-grid | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-214 | activation-values | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-215 | activation-value | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-216 | Активация панели: 100 EFHC | frontend/src/pages/panels.tsx:206 | SOURCE_CANDIDATE |
| demo.panelsPage.node-217 | 100 EFHC | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-218 | activation-value | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-219 | Всего доступно | frontend/src/pages/panels.tsx:212 | SOURCE_CANDIDATE |
| demo.panelsPage.activationTotal | 12345678.12345678 EFHC | frontend/src/pages/panels.tsx | REGION_ONLY |
| demo.panelsPage.node-221 | Сначала списываются бонусы, потом основные EFHC. | frontend/src/pages/panels.tsx:220 | SOURCE_CANDIDATE |
| demo.panelsPage.activationWarning | Нужно 100 EFHC суммарно на бонусном и основном балансе. | frontend/src/pages/panels.tsx:225 | SOURCE_CANDIDATE |
| demo.panelsPage.activatePanel | Активировать панель | frontend/src/pages/panels.tsx:234; frontend/src/pages/panels.tsx:79; frontend/src/pages/panels.tsx:232; frontend/src/pages/panels.tsx:233; frontend/src/pages/panels.tsx:231 | SOURCE_CANDIDATE |
| demo.panelsPage.node-224 | Мои панели | frontend/src/pages/panels.tsx:248; frontend/src/pages/panels.tsx:245 | SOURCE_CANDIDATE |
| demo.panelsPortfolioPage.panelsPortfolioPage | panelsPortfolioPage | frontend/src/pages/panels/portfolio.tsx:200 | SOURCE_CANDIDATE |
| demo.panelsPortfolioPage.node-226 | Мои панели | frontend/src/pages/panels/portfolio.tsx:202 | SOURCE_CANDIDATE |
| demo.panelsPortfolioPage.node-227 | panels-card panels-list-card | frontend/src/pages/panels/portfolio.tsx:205 | SOURCE_CANDIDATE |
| demo.panelsPortfolioPage.panelsTabs | panelsTabs | frontend/src/pages/panels/portfolio.tsx:216 | SOURCE_CANDIDATE |
| demo.panelsPortfolioPage.node-229 | Активные | frontend/src/pages/panels/portfolio.tsx:221 | SOURCE_CANDIDATE |
| demo.panelsPortfolioPage.node-230 | Архив | frontend/src/pages/panels/portfolio.tsx:235 | SOURCE_CANDIDATE |
| demo.panelsPortfolioPage.node-231 | panels-tab-hint-row | frontend/src/pages/panels/portfolio.tsx | REGION_ONLY |
| demo.panelsPortfolioPage.tabHint | Активные панели генерируют энергию и учитываются в производстве. | frontend/src/pages/panels/portfolio.tsx:251 | SOURCE_CANDIDATE |
| demo.panelsPortfolioPage.panelsSortDirection | Сначала старые | frontend/src/pages/panels/portfolio.tsx | REGION_ONLY |
| demo.panelsPortfolioPage.panelsList | panelsList | frontend/src/pages/panels/portfolio.tsx:294; frontend/src/pages/panels/portfolio.tsx:293 | SOURCE_CANDIDATE |
| demo.panelsPortfolioPage.panelsListEnd | Конец списка | frontend/src/pages/panels/portfolio.tsx:429 | SOURCE_CANDIDATE |
| demo.exchangePage.exchangePage | exchangePage | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.exchangeHero | exchangeHero | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.node-239 | source-hero-head | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.node-241 | Обмен энергии | frontend/src/pages/exchange.tsx:110 | SOURCE_CANDIDATE |
| demo.exchangePage.node-242 | Обмен | frontend/src/components/ExchangePanel.tsx:164; frontend/src/pages/exchange.tsx:111 | SOURCE_CANDIDATE |
| demo.exchangePage.node-243 | Односторонний обмен доступной энергии. Курс фиксирован: 1 kWh = 1 EFHC. | frontend/src/pages/exchange.tsx:112 | SOURCE_CANDIDATE |
| demo.exchangePage.exchangeStatsSurface | exchangeStatsSurface | frontend/src/pages/exchange.tsx:117 | SOURCE_CANDIDATE |
| demo.exchangePage.node-245 | source-stat | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.node-246 | Доступно kWh | frontend/src/pages/exchange.tsx:122 | SOURCE_CANDIDATE |
| demo.exchangePage.exchangeAvailable | 421.12500000 | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.node-248 | source-stat | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.node-249 | Курс | frontend/src/pages/exchange.tsx:125 | SOURCE_CANDIDATE |
| demo.exchangePage.node-250 | 1 kWh = 1 EFHC | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.node-251 | source-stat | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.node-252 | Основной баланс · EFHCm | frontend/src/pages/exchange.tsx:127 | SOURCE_CANDIDATE |
| demo.exchangePage.exchangeMainBalance | 12345600.12345678 | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.exchangeBody | exchangeBody | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.exchangeCard | exchangeCard | frontend/src/components/ExchangePanel.tsx:170; frontend/src/components/ExchangePanel.tsx:171 | SOURCE_CANDIDATE |
| demo.exchangePage.node-256 | Обмен | frontend/src/components/ExchangePanel.tsx:164; frontend/src/pages/exchange.tsx:111 | SOURCE_CANDIDATE |
| demo.exchangePage.node-257 | Введите количество kWh. Обратный обмен EFHC → kWh отсутствует. | frontend/src/components/ExchangePanel.tsx:175 | SOURCE_CANDIDATE |
| demo.exchangePage.exchangeActionSurface | exchangeActionSurface | frontend/src/components/ExchangePanel.tsx:180 | SOURCE_CANDIDATE |
| demo.exchangePage.node-259 | source-row exchange-available-row | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.node-261 | Доступно для обмена | frontend/src/components/ExchangePanel.tsx:186 | SOURCE_CANDIDATE |
| demo.exchangePage.exchangeMaxValue | 421.12500000 | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.exchangeMaxButton | MAX | frontend/src/components/ExchangePanel.tsx:197 | SOURCE_CANDIDATE |
| demo.exchangePage.node-264 | source-field | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.node-265 | Количество kWh | frontend/src/components/ExchangePanel.tsx:202 | SOURCE_CANDIDATE |
| demo.exchangePage.exchangeInput | Количество kWh | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.node-267 | source-preview | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.node-268 | Получите · EFHCm | frontend/src/components/ExchangePanel.tsx:221 | SOURCE_CANDIDATE |
| demo.exchangePage.exchangeReceive | 0.00000000 | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.exchangeHelper | exchangeHelper | frontend/src/components/ExchangePanel.tsx; frontend/src/pages/exchange.tsx | REGION_ONLY |
| demo.exchangePage.exchangeAction | Обменять kWh | frontend/src/components/ExchangePanel.tsx:243; frontend/src/components/ExchangePanel.tsx:236; frontend/src/pages/exchange.tsx:181 | SOURCE_CANDIDATE |
| demo.exchangePage.node-272 | source-history-boundary efhc-exchange-history-boundary | frontend/src/pages/exchange.tsx:163 | SOURCE_CANDIDATE |
| demo.exchangePage.node-273 | История операций хранится в профиле. | frontend/src/pages/exchange.tsx:167; frontend/src/pages/exchange.tsx:166 | SOURCE_CANDIDATE |
| demo.exchangePage.node-274 | Открыть историю | frontend/src/pages/exchange.tsx:176; frontend/src/pages/exchange.tsx:171 | SOURCE_CANDIDATE |
| demo.exchangePage.node-275 | EFHCm | frontend/src/components/ExchangePanel.tsx:236; frontend/src/pages/exchange.tsx:183; frontend/src/pages/exchange.tsx:184; frontend/src/pages/exchange.tsx:181 | SOURCE_CANDIDATE |
| demo.exchangePage.node-276 | Вывод | frontend/src/pages/exchange.tsx:187 | SOURCE_CANDIDATE |
| demo.tasksPage.tasksPage | tasksPage | frontend/src/pages/tasks.tsx | REGION_ONLY |
| demo.tasksPage.node-278 | source-game-hero | frontend/src/pages/tasks.tsx | REGION_ONLY |
| demo.tasksPage.node-279 | source-hero-head | frontend/src/pages/tasks.tsx | REGION_ONLY |
| demo.tasksPage.node-281 | Зарабатывайте бонусы | frontend/src/pages/tasks.tsx:235 | SOURCE_CANDIDATE |
| demo.tasksPage.node-282 | Задания | frontend/src/pages/tasks.tsx:235 | SOURCE_CANDIDATE |
| demo.tasksPage.node-283 | Выполняйте задания и рекламу. Все начисления учитываются в системном EFHCb-журнале заданий. | frontend/src/pages/tasks.tsx:235 | SOURCE_CANDIDATE |
| demo.tasksPage.node-284 | standalone-bonus-earnings-strip | frontend/src/pages/tasks.tsx | REGION_ONLY |
| demo.tasksPage.node-287 | Заработано за всё время | frontend/src/pages/tasks.tsx:237 | SOURCE_CANDIDATE |
| demo.tasksPage.tasksEarned | 0.02000000 | frontend/src/pages/tasks.tsx | REGION_ONLY |
| demo.tasksPage.node-291 | Остаток EFHC бонус | frontend/src/pages/tasks.tsx:239 | SOURCE_CANDIDATE |
| demo.tasksPage.tasksBonusRemaining | 250.50000000 | frontend/src/pages/tasks.tsx | REGION_ONLY |
| demo.tasksPage.tasksList | tasksList | frontend/src/pages/tasks.tsx:233 | SOURCE_CANDIDATE |
| demo.referralsPage.referralsPage | referralsPage | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-295 | source-game-hero | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-296 | source-hero-head | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-298 | Партнёрская система | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-299 | Рефералы | frontend/src/pages/referrals.tsx:143 | SOURCE_CANDIDATE |
| demo.referralsPage.node-300 | Приглашайте пользователей, достигайте уровней и получайте EFHCb. | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-301 | source-stats | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-302 | source-stat | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-303 | Активные | frontend/src/pages/referrals.tsx:148 | SOURCE_CANDIDATE |
| demo.referralsPage.node-304 | 17 | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-305 | source-stat | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-306 | Неактивные | frontend/src/pages/referrals.tsx:152 | SOURCE_CANDIDATE |
| demo.referralsPage.node-307 | 7 | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-308 | source-stat | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-309 | Всего | frontend/src/pages/referrals.tsx:156 | SOURCE_CANDIDATE |
| demo.referralsPage.node-310 | 24 | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-311 | standalone-bonus-earnings-strip | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-314 | Заработано за всё время | frontend/src/pages/referrals.tsx:161 | SOURCE_CANDIDATE |
| demo.referralsPage.referralsEarned | 2.70000000 | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-318 | Остаток EFHC бонус | frontend/src/pages/referrals.tsx:163 | SOURCE_CANDIDATE |
| demo.referralsPage.referralsBonusRemaining | 250.50000000 | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-320 | source-card | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-321 | Пригласить пользователя | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-322 | Используйте персональную ссылку. Привязка создаётся только при первой регистрации. | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-323 | source-card | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.referralLink | https://t.me/efhc_bot?start=REF1234567890 | frontend/src/pages/referrals.tsx:92 | SOURCE_CANDIDATE |
| demo.referralsPage.copyReferral | Копировать ссылку | frontend/src/pages/referrals.tsx:198 | SOURCE_CANDIDATE |
| demo.referralsPage.node-326 | standalone-referral-share-grid | frontend/src/pages/referrals.tsx:209 | SOURCE_CANDIDATE |
| demo.referralsPage.node-327 | Telegram | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-328 | svg | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-330 | WhatsApp | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-331 | svg | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-333 | Viber | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-334 | svg | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-336 | Facebook | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-337 | svg | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-339 | X | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-340 | svg | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-342 | source-card | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-343 | source-row | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-344 | Уровни достижений | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-345 | 1 | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.referralProgressTrack | referralProgressTrack | frontend/src/pages/referrals.tsx:269; frontend/src/pages/referrals.tsx:270; frontend/src/pages/referrals.tsx:267; frontend/src/pages/referrals.tsx:265 | SOURCE_CANDIDATE |
| demo.referralsPage.node-348 | efhc-energy-progress-fill | frontend/src/pages/referrals.tsx:274 | SOURCE_CANDIDATE |
| demo.referralsPage.node-349 | :  2 · 83 | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-350 | До следующего уровня | frontend/src/pages/referrals.tsx:282 | SOURCE_CANDIDATE |
| demo.referralsPage.node-352 | активных | frontend/src/pages/referrals.tsx:327 | SOURCE_CANDIDATE |
| demo.referralsPage.node-353 | standalone-referral-achievement-rail | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-354 | standalone-referral-achievement-track | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-356 | standalone-referral-achievement-nodes | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-382 | необходимо активных рефералов | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals.tsx | REGION_ONLY |
| demo.referralsPage.node-383 | Мои Рефералы | frontend/src/pages/referrals.tsx:354; frontend/src/pages/referrals.tsx:351 | SOURCE_CANDIDATE |
| demo.ranksPage.ranksPage | ranksPage | frontend/src/pages/ranks.tsx:188 | SOURCE_CANDIDATE |
| demo.ranksPage.node-385 | source-game-hero | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.node-386 | source-hero-head | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.node-388 | Ранги | frontend/src/pages/ranks.tsx:191 | SOURCE_CANDIDATE |
| demo.ranksPage.rankRefresh | Обновить | frontend/src/pages/ranks.tsx:195 | SOURCE_CANDIDATE |
| demo.ranksPage.node-390 | source-stats two | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.node-391 | source-stat | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.node-392 | Моё место | frontend/src/pages/ranks.tsx:207 | SOURCE_CANDIDATE |
| demo.ranksPage.rankMyPlace | #42 | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.node-394 | source-stat | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.rankMetricLabel | Моя энергия | frontend/src/pages/ranks.tsx:174 | SOURCE_CANDIDATE |
| demo.ranksPage.rankMyEnergy | 8123.12345678 kWh | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.myRankCard | myRankCard | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.node-398 | Моя позиция | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.node-399 | source-rank-row is-mine | frontend/src/pages/ranks.tsx:56; frontend/src/pages/ranks.tsx:59 | SOURCE_CANDIDATE |
| demo.ranksPage.rankMyMedal | 42 | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.node-401 | @efhc_player | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.rankMyCardEnergy | 8123.12345678 kWh | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.node-403 | source-card | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.node-404 | source-row | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.node-405 | Топ-100 | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.findMyRank | Найти меня | frontend/src/pages/ranks.tsx:248 | SOURCE_CANDIDATE |
| demo.ranksPage.rankList | rankList | frontend/src/pages/ranks.tsx | REGION_ONLY |
| demo.ranksPage.loadMoreRanks | Загрузить ещё | frontend/src/pages/ranks.tsx:320 | SOURCE_CANDIDATE |
| demo.referralsMyPage.referralsMyPage | referralsMyPage | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals/my.tsx | REGION_ONLY |
| demo.referralsMyPage.node-410 | Мои Рефералы | frontend/src/pages/referrals/my.tsx:33 | SOURCE_CANDIDATE |
| demo.referralsMyPage.node-411 | source-referrals-tabs-surface | frontend/src/pages/referrals/my.tsx:34 | SOURCE_CANDIDATE |
| demo.referralsMyPage.referralTabs | referralTabs | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals/my.tsx | REGION_ONLY |
| demo.referralsMyPage.node-413 | (17) | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals/my.tsx | REGION_ONLY |
| demo.referralsMyPage.node-414 | Активные | frontend/src/pages/referrals/my.tsx:40 | SOURCE_CANDIDATE |
| demo.referralsMyPage.node-415 | (7) | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals/my.tsx | REGION_ONLY |
| demo.referralsMyPage.node-416 | Неактивные | frontend/src/pages/referrals/my.tsx:46 | SOURCE_CANDIDATE |
| demo.referralsMyPage.referralList | referralList | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals/my.tsx | REGION_ONLY |
| demo.referralsMyPage.loadMoreReferrals | Загрузить ещё | frontend/src/components/referrals/ReferralRoster.tsx; frontend/src/pages/referrals/my.tsx | REGION_ONLY |
| demo.profilePage.profilePage | profilePage | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-420 | source-profile-topbar | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.profileBack | profileBack | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-423 | Назад | frontend/src/components/ProfileModal.tsx:848; frontend/src/features/profile/WebProfilePage.tsx:318 | SOURCE_CANDIDATE |
| demo.profilePage.node-424 | Профиль | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-425 | source-row | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.standaloneProfileAdminButton | Админ | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-427 | Выход | frontend/src/features/profile/WebProfilePage.tsx:331 | SOURCE_CANDIDATE |
| demo.profilePage.node-428 | source-profile-hero | frontend/src/features/profile/WebProfilePage.tsx:338; frontend/src/features/profile/WebProfilePage.tsx:339 | SOURCE_CANDIDATE |
| demo.profilePage.standaloneProfileAvatar | Изменить фото профиля | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-430 | source-profile-identity | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-431 | source-row | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-432 | EFHC Player | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.standaloneProfileAdminBadge | Администратор | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-434 | standalone-profile-global-id | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.profileGlobalId | 0000657667 | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-437 | source-profile-third-row | frontend/src/features/profile/WebProfilePage.tsx:377 | SOURCE_CANDIDATE |
| demo.profilePage.profileLevel | Lvl 9 | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.profileVipStatus | VIP | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.profileActivStatus | Activ | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.profileTabs | profileTabs | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-442 | Профиль | frontend/src/features/profile/WebProfilePage.tsx:416 | SOURCE_CANDIDATE |
| demo.profilePage.node-443 | Кошелёк | frontend/src/components/GlobalHeader.tsx:443; frontend/src/components/ProfileModal.tsx:729 | SOURCE_CANDIDATE |
| demo.profilePage.node-444 | Баланс | frontend/src/features/profile/WebProfilePage.tsx:428 | SOURCE_CANDIDATE |
| demo.profilePage.node-445 | FAQ | frontend/src/components/GlobalHeader.tsx:433; frontend/src/components/ProfileModal.tsx:743; frontend/src/components/profile/ProfileFaqSection.tsx:32; frontend/src/features/profile/WebProfilePage.tsx:434 | SOURCE_CANDIDATE |
| demo.profilePage.node-446 | source-profile-content | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-447 | source-stats two | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-448 | source-stat | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-449 | Имя пользователя | frontend/src/features/profile/WebProfilePage.tsx:508 | SOURCE_CANDIDATE |
| demo.profilePage.node-450 | EFHC Player | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-451 | source-stat | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-452 | Сгенерировано | frontend/src/features/profile/WebProfilePage.tsx:225 | SOURCE_CANDIDATE |
| demo.profilePage.profileEnergyValue | 8123.12345678 kWh | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-454 | source-card source-profile-settings-card | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-455 | source-row | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-457 | Интерфейс | frontend/src/components/ProfileModal.tsx:833; frontend/src/features/profile/WebProfilePage.tsx:522 | SOURCE_CANDIDATE |
| demo.profilePage.node-458 | Язык и настройки аккаунта. | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.profileSettingsButton | ⚙ | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-460 | source-profile-compact-controls | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-461 | source-profile-compact-control | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.profileLanguageButton | Язык | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.profileLanguageFlag | 🇷🇺 | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.profileLanguageName | Русский | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.profileLanguageMenu | profileLanguageMenu | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-467 | source-profile-content | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-468 | standalone-wallet-layout | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-469 | Привязанные кошельки | frontend/src/components/profile/ProfileWalletSection.tsx:96; frontend/src/components/profile/ProfileWalletSection.tsx:94; frontend/src/components/profile/ProfileWalletSection.tsx:93 | SOURCE_CANDIDATE |
| demo.profilePage.standaloneWalletConnect | Подключить кошелёк | frontend/src/components/Layout.tsx:884; frontend/src/components/profile/wallet/WalletConnectBanner.tsx:59 | SOURCE_CANDIDATE |
| demo.profilePage.standaloneWalletList | standaloneWalletList | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-472 | source-profile-content standalone-legal-page | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-473 | Вернуться в профиль | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-474 | source-card standalone-legal-card | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-475 | Условия использования | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-476 | Правила использования аккаунта, операций и функций EFHC. | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-477 | Ознакомьтесь с актуальными условиями продукта. | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-478 | Конфиденциальность, правила, безопасность и поддержка. | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-479 | source-profile-content standalone-legal-page | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-480 | Вернуться в профиль | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-481 | source-card standalone-legal-card | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-482 | Политика конфиденциальности | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-483 | Как EFHC использует данные аккаунта и защищает пользовательскую информацию. | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-484 | Ознакомьтесь с актуальной информацией о конфиденциальности. | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-485 | Конфиденциальность, правила, безопасность и поддержка. | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-486 | source-profile-content standalone-history-sheet | frontend/src/components/profile/ProfileHistorySection.tsx:187; frontend/src/components/profile/ProfileHistorySection.tsx:188; frontend/src/components/profile/ProfileHistorySection.tsx:190; frontend/src/components/profile/ProfileHistorySection.tsx:185 | SOURCE_CANDIDATE |
| demo.profilePage.node-487 | efhc-history-balance-header | frontend/src/components/profile/ProfileHistorySection.tsx:195 | SOURCE_CANDIDATE |
| demo.profilePage.node-488 | standalone-history-balances efhc-history-balance-stack | frontend/src/components/profile/ProfileHistorySection.tsx:172; frontend/src/components/profile/ProfileHistorySection.tsx:171 | SOURCE_CANDIDATE |
| demo.profilePage.node-489 | standalone-history-balance-row efhc-history-balance-row | frontend/src/components/profile/history/BalanceSummaryCard.tsx:13 | SOURCE_CANDIDATE |
| demo.profilePage.node-490 | efhc-history-balance-label | frontend/src/components/profile/history/BalanceSummaryCard.tsx:17 | SOURCE_CANDIDATE |
| demo.profilePage.node-491 | efhc-history-balance-dot | frontend/src/components/profile/history/BalanceSummaryCard.tsx:18 | SOURCE_CANDIDATE |
| demo.profilePage.node-492 | Общий баланс · EFHC | frontend/src/components/profile/ProfileHistorySection.tsx:175 | SOURCE_CANDIDATE |
| demo.profilePage.historyTotalBalance | 0.00000000 | frontend/src/components/profile/history/BalanceSummaryCard.tsx:21 | SOURCE_CANDIDATE |
| demo.profilePage.node-494 | standalone-history-balance-row efhc-history-balance-row | frontend/src/components/profile/history/BalanceSummaryCard.tsx:13 | SOURCE_CANDIDATE |
| demo.profilePage.node-495 | efhc-history-balance-label | frontend/src/components/profile/history/BalanceSummaryCard.tsx:17 | SOURCE_CANDIDATE |
| demo.profilePage.node-496 | efhc-history-balance-dot | frontend/src/components/profile/history/BalanceSummaryCard.tsx:18 | SOURCE_CANDIDATE |
| demo.profilePage.node-497 | Основной баланс · EFHCm | frontend/src/components/profile/ProfileHistorySection.tsx:176 | SOURCE_CANDIDATE |
| demo.profilePage.historyMainBalance | 0.00000000 | frontend/src/components/profile/history/BalanceSummaryCard.tsx:21 | SOURCE_CANDIDATE |
| demo.profilePage.node-499 | standalone-history-balance-row efhc-history-balance-row | frontend/src/components/profile/history/BalanceSummaryCard.tsx:13 | SOURCE_CANDIDATE |
| demo.profilePage.node-500 | efhc-history-balance-label | frontend/src/components/profile/history/BalanceSummaryCard.tsx:17 | SOURCE_CANDIDATE |
| demo.profilePage.node-501 | efhc-history-balance-dot | frontend/src/components/profile/history/BalanceSummaryCard.tsx:18 | SOURCE_CANDIDATE |
| demo.profilePage.node-502 | Бонусный баланс · EFHCb | frontend/src/components/profile/ProfileHistorySection.tsx:177 | SOURCE_CANDIDATE |
| demo.profilePage.historyBonusBalance | 0.00000000 | frontend/src/components/profile/history/BalanceSummaryCard.tsx:21 | SOURCE_CANDIDATE |
| demo.profilePage.node-504 | standalone-history-sheet-head efhc-history-section-head | frontend/src/components/profile/ProfileHistorySection.tsx:199 | SOURCE_CANDIDATE |
| demo.profilePage.node-505 | История операций | frontend/src/components/profile/ProfileHistorySection.tsx:200 | SOURCE_CANDIDATE |
| demo.profilePage.node-506 | standalone-history-head-actions efhc-history-head-actions | frontend/src/components/profile/ProfileHistorySection.tsx:201 | SOURCE_CANDIDATE |
| demo.profilePage.standaloneHistoryExport | Скачать CSV | frontend/src/components/profile/ProfileHistorySection.tsx:204 | SOURCE_CANDIDATE |
| demo.profilePage.standaloneHistoryExportXlsx | Скачать XLSX | frontend/src/components/profile/ProfileHistorySection.tsx:209 | SOURCE_CANDIDATE |
| demo.profilePage.standaloneHistoryRefresh | Обновить | frontend/src/components/profile/ProfileHistorySection.tsx:212 | SOURCE_CANDIDATE |
| demo.profilePage.standaloneHistoryWithdraw | Вывод | frontend/src/components/profile/ProfileHistorySection.tsx:215; frontend/src/components/profile/ProfileHistorySection.tsx:214 | SOURCE_CANDIDATE |
| demo.profilePage.node-511 | efhc-history-bank-nav | frontend/src/components/profile/ProfileHistorySection.tsx:221 | SOURCE_CANDIDATE |
| demo.profilePage.standaloneHistoryFilters | Разделы истории | frontend/src/components/profile/ProfileHistorySection.tsx:222 | SOURCE_CANDIDATE |
| demo.profilePage.node-513 | Все | frontend/src/components/profile/ProfileHistorySection.tsx:222; frontend/src/components/profile/ProfileHistorySection.tsx:229 | SOURCE_CANDIDATE |
| demo.profilePage.node-514 | Покупки | frontend/src/components/profile/ProfileHistorySection.tsx:222 | SOURCE_CANDIDATE |
| demo.profilePage.node-515 | Обмен | frontend/src/components/profile/ProfileHistorySection.tsx:222 | SOURCE_CANDIDATE |
| demo.profilePage.node-516 | Вывод | frontend/src/components/profile/ProfileHistorySection.tsx:222 | SOURCE_CANDIDATE |
| demo.profilePage.node-517 | Бонусы | frontend/src/components/profile/ProfileHistorySection.tsx:222 | SOURCE_CANDIDATE |
| demo.profilePage.node-518 | Панели | frontend/src/components/profile/ProfileHistorySection.tsx:222 | SOURCE_CANDIDATE |
| demo.profilePage.standaloneHistoryPageHint | Все операции аккаунта в единой хронологии. | frontend/src/components/profile/ProfileHistorySection.tsx:237 | SOURCE_CANDIDATE |
| demo.profilePage.standaloneHistoryPageTitle | history.withdraw_requests | frontend/src/components/profile/ProfileHistorySection.tsx:247 | SOURCE_CANDIDATE |
| demo.profilePage.standaloneHistoryLedger | standaloneHistoryLedger | frontend/src/components/profile/history/HistoryOperationFeed.tsx:167 | SOURCE_CANDIDATE |
| demo.profilePage.node-522 | source-profile-content | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-523 | source-card | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-524 | FAQ | frontend/src/components/GlobalHeader.tsx:433; frontend/src/components/ProfileModal.tsx:743; frontend/src/components/profile/ProfileFaqSection.tsx:32; frontend/src/features/profile/WebProfilePage.tsx:434 | SOURCE_CANDIDATE |
| demo.profilePage.node-525 | Откройте полный FAQ как отдельный центр помощи. В профиле остаётся только чистая кнопка перехода. | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profilePage.node-526 | Открыть FAQ | frontend/src/features/profile/WebProfilePage.tsx; frontend/src/pages/web-profile.tsx | REGION_ONLY |
| demo.profileSettingsOverlay.profileSettingsOverlay | profileSettingsOverlay | frontend/src/components/ProfileModal.tsx | REGION_ONLY |
| demo.profileSettingsOverlay.node-528 | standalone-settings-dialog | frontend/src/components/ProfileModal.tsx | REGION_ONLY |
| demo.profileSettingsOverlay.node-529 | source-row | frontend/src/components/ProfileModal.tsx | REGION_ONLY |
| demo.profileSettingsOverlay.profileSettingsTitle | Настройки | frontend/src/components/ProfileModal.tsx | REGION_ONLY |
| demo.profileSettingsOverlay.profileSettingsClose | Закрыть | frontend/src/components/ProfileModal.tsx | REGION_ONLY |
| demo.profileSettingsOverlay.node-533 | standalone-settings-row | frontend/src/components/ProfileModal.tsx | REGION_ONLY |
| demo.profileSettingsOverlay.node-534 | Меньше анимации | frontend/src/components/ProfileModal.tsx:845 | SOURCE_CANDIDATE |
| demo.profileSettingsOverlay.node-535 | Выкл. | frontend/src/components/NetworkStatus.tsx:18 | SOURCE_CANDIDATE |
| demo.profileSettingsOverlay.node-536 | standalone-settings-row | frontend/src/components/ProfileModal.tsx | REGION_ONLY |
| demo.profileSettingsOverlay.node-537 | Звуки интерфейса | frontend/src/components/ProfileModal.tsx:846 | SOURCE_CANDIDATE |
| demo.profileSettingsOverlay.node-538 | Вкл. | frontend/src/components/ProfileModal.tsx | REGION_ONLY |
| demo.profileSettingsOverlay.node-539 | standalone-settings-row | frontend/src/components/ProfileModal.tsx | REGION_ONLY |
| demo.profileSettingsOverlay.node-540 | Виброотклик | frontend/src/components/ProfileModal.tsx:847 | SOURCE_CANDIDATE |
| demo.profileSettingsOverlay.node-541 | Вкл. | frontend/src/components/ProfileModal.tsx | REGION_ONLY |
| demo.profileSettingsOverlay.node-542 | standalone-settings-row | frontend/src/components/ProfileModal.tsx | REGION_ONLY |
| demo.profileSettingsOverlay.node-543 | Фоновая музыка | frontend/src/components/ProfileModal.tsx:848 | SOURCE_CANDIDATE |
| demo.profileSettingsOverlay.node-544 | Выкл. | frontend/src/components/NetworkStatus.tsx:18 | SOURCE_CANDIDATE |
| demo.profileAvatarOverlay.profileAvatarOverlay | profileAvatarOverlay | frontend/src/components/profile/AvatarPreferenceEditor.tsx | REGION_ONLY |
| demo.profileAvatarOverlay.node-546 | standalone-settings-dialog | frontend/src/components/profile/AvatarPreferenceEditor.tsx | REGION_ONLY |
| demo.profileAvatarOverlay.node-547 | source-row | frontend/src/components/profile/AvatarPreferenceEditor.tsx | REGION_ONLY |
| demo.profileAvatarOverlay.profileAvatarDialogTitle | Изменить фото профиля | frontend/src/components/profile/AvatarPreferenceEditor.tsx | REGION_ONLY |
| demo.profileAvatarOverlay.profileAvatarClose | Закрыть | frontend/src/components/profile/AvatarPreferenceEditor.tsx | REGION_ONLY |
| demo.profileAvatarOverlay.node-550 | standalone-avatar-settings | frontend/src/components/profile/AvatarPreferenceEditor.tsx | REGION_ONLY |
| demo.profileAvatarOverlay.standaloneAvatarSocialHeading | Фото из привязанных аккаунтов | frontend/src/components/profile/AvatarPreferenceEditor.tsx:98 | SOURCE_CANDIDATE |
| demo.profileAvatarOverlay.standaloneAvatarSocialGrid | standaloneAvatarSocialGrid | frontend/src/components/profile/AvatarPreferenceEditor.tsx | REGION_ONLY |
| demo.profileAvatarOverlay.node-553 | Иконка профиля | frontend/src/components/profile/AvatarPreferenceEditor.tsx:113 | SOURCE_CANDIDATE |
| demo.profileAvatarOverlay.standaloneAvatarPresets | standaloneAvatarPresets | frontend/src/components/profile/AvatarPreferenceEditor.tsx | REGION_ONLY |
| demo.profileAvatarOverlay.node-555 | По ссылке (HTTPS) | frontend/src/components/profile/AvatarPreferenceEditor.tsx:124 | SOURCE_CANDIDATE |
| demo.profileAvatarOverlay.standaloneAvatarUrlInput | Прямая HTTPS-ссылка на аватар | frontend/src/components/profile/AvatarPreferenceEditor.tsx | REGION_ONLY |
| demo.profileAvatarOverlay.node-557 | standalone-avatar-url-actions | frontend/src/components/profile/AvatarPreferenceEditor.tsx | REGION_ONLY |
| demo.profileAvatarOverlay.standaloneAvatarCheckUrl | Предпросмотр | frontend/src/components/profile/AvatarPreferenceEditor.tsx:130 | SOURCE_CANDIDATE |
| demo.profileAvatarOverlay.standaloneAvatarSaveUrl | Сохранить | frontend/src/components/profile/AvatarPreferenceEditor.tsx:75 | SOURCE_CANDIDATE |
| demo.profileAvatarOverlay.standaloneAvatarClearUrl | Удалить ссылку | frontend/src/components/profile/AvatarPreferenceEditor.tsx:132 | SOURCE_CANDIDATE |
| demo.profileAvatarOverlay.standaloneAvatarUrlPreview | standaloneAvatarUrlPreview | frontend/src/components/profile/AvatarPreferenceEditor.tsx | REGION_ONLY |
| demo.profileAvatarOverlay.standaloneAvatarUrlStatus | standaloneAvatarUrlStatus | frontend/src/components/profile/AvatarPreferenceEditor.tsx | REGION_ONLY |
| demo.hubPage.hubPage | hubPage | frontend/src/features/hub/HubPage.tsx:61 | SOURCE_CANDIDATE |
| demo.hubPage.node-564 | HUB | frontend/src/features/hub/HubPage.tsx:70; frontend/src/features/hub/HubPage.tsx:65 | SOURCE_CANDIDATE |
| demo.withdrawPage.withdrawPage | withdrawPage | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-566 | source-game-hero standalone-withdraw-hero | frontend/src/pages/withdraw.tsx:328; frontend/src/pages/withdraw.tsx:329 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-567 | source-hero-head | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-569 | Вывод средств | frontend/src/pages/withdraw.tsx:333 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-570 | Вывод | frontend/src/pages/withdraw.tsx:334 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-571 | Минимальная сумма вывода: 10.00000000 EFHCm. | frontend/src/pages/withdraw.tsx:335 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-572 | standalone-withdraw-summary-list | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-573 | standalone-withdraw-summary-row | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-574 | Доступно к выводу | frontend/src/pages/withdraw.tsx:339 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-575 | EFHCm | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.withdrawBalance | 12345600.12345678 | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-577 | standalone-withdraw-summary-row | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-578 | Основной кошелёк | frontend/src/pages/withdraw.tsx:343 | SOURCE_CANDIDATE |
| demo.withdrawPage.withdrawWalletSummary | — | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-580 | source-card exchange-card-variant | frontend/src/pages/withdraw.tsx:354 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-581 | Новая заявка | frontend/src/pages/withdraw.tsx:352 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-582 | standalone-withdraw-exchange-panel | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-583 | source-row standalone-withdraw-available-row | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-585 | Доступно к выводу | frontend/src/pages/withdraw.tsx:339 | SOURCE_CANDIDATE |
| demo.withdrawPage.withdrawActionBalance | 12345600.12345678 EFHCm | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.withdrawMaxButton | MAX | frontend/src/pages/withdraw.tsx:376 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-588 | source-field | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-589 | Сумма EFHCm | frontend/src/pages/withdraw.tsx:382 | SOURCE_CANDIDATE |
| demo.withdrawPage.withdrawInput | withdrawInput | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.efhc-withdraw-amount-helper | Введите сумму не менее 10.00000000 EFHCm и не больше доступного основного баланса. | frontend/src/pages/withdraw.tsx:412; frontend/src/pages/withdraw.tsx:391 | SOURCE_CANDIDATE |
| demo.withdrawPage.withdrawCreate | Создать заявку | frontend/src/pages/withdraw.tsx:430 | SOURCE_CANDIDATE |
| demo.withdrawPage.withdrawStatus | withdrawStatus | frontend/src/pages/withdraw.tsx:24 | SOURCE_CANDIDATE |
| demo.withdrawRequiredAdOverlay.withdrawRequiredAdOverlay | withdrawRequiredAdOverlay | — | UNRESOLVED |
| demo.withdrawRequiredAdOverlay.node-595 | standalone-settings-dialog | — | UNRESOLVED |
| demo.withdrawRequiredAdOverlay.withdrawRequiredAdTitle | Просмотр рекламы | — | UNRESOLVED |
| demo.withdrawRequiredAdOverlay.withdrawRequiredAdState | Подготовка рекламного окна… | — | UNRESOLVED |
| demo.withdrawPage.node-598 | source-card efhc-history-bank-module | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-599 | Мои заявки | frontend/src/pages/withdraw.tsx:436 | SOURCE_CANDIDATE |
| demo.withdrawPage.withdrawFilters | withdrawFilters | frontend/src/pages/withdraw.tsx:439 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-601 | Все | frontend/src/pages/withdraw.tsx:444; frontend/src/pages/withdraw.tsx:439; frontend/src/pages/withdraw.tsx:455 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-602 | В обработке | frontend/src/pages/withdraw.tsx:445; frontend/src/pages/withdraw.tsx:439 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-603 | Выплачено | frontend/src/pages/withdraw.tsx:446; frontend/src/pages/withdraw.tsx:439 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-604 | Отменено | frontend/src/pages/withdraw.tsx:447; frontend/src/pages/withdraw.tsx:439 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-605 | Отклонено | frontend/src/pages/withdraw.tsx:448; frontend/src/pages/withdraw.tsx:439 | SOURCE_CANDIDATE |
| demo.withdrawPage.withdrawList | withdrawList | frontend/src/pages/withdraw.tsx:472 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-607 | source-card | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-608 | Последние операции EFHC | frontend/src/pages/withdraw.tsx:588 | SOURCE_CANDIDATE |
| demo.withdrawPage.withdrawHistoryList | withdrawHistoryList | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-610 | standalone-withdraw-history-export | frontend/src/pages/withdraw.tsx:656 | SOURCE_CANDIDATE |
| demo.withdrawPage.node-611 | Экспорт истории | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.node-612 | standalone-withdraw-history-export-actions | frontend/src/pages/withdraw.tsx | REGION_ONLY |
| demo.withdrawPage.withdrawExportCsv | CSV | frontend/src/pages/withdraw.tsx:665 | SOURCE_CANDIDATE |
| demo.withdrawPage.withdrawExportXlsx | XLSX | frontend/src/pages/withdraw.tsx:673 | SOURCE_CANDIDATE |
| demo.faqPage.faqPage | faqPage | frontend/src/pages/faq.tsx:201 | SOURCE_CANDIDATE |
| demo.faqPage.node-616 | source-card standalone-faq-simple | frontend/src/pages/faq.tsx | REGION_ONLY |
| demo.faqPage.faqHeroTitle | FAQ | frontend/src/pages/faq.tsx | REGION_ONLY |
| demo.faqPage.node-618 | source-field localization-search | frontend/src/pages/faq.tsx | REGION_ONLY |
| demo.faqPage.faqSearch | Поиск по слову или фразе | frontend/src/pages/faq.tsx | REGION_ONLY |
| demo.faqPage.faqSearchClear | × | frontend/src/pages/faq.tsx | REGION_ONLY |
| demo.faqPage.faqSearchStatus | faqSearchStatus | frontend/src/pages/faq.tsx | REGION_ONLY |
| demo.faqPage.node-622 | source-card | frontend/src/pages/faq.tsx | REGION_ONLY |
| demo.faqPage.faqList | faqList | frontend/src/pages/faq.tsx | REGION_ONLY |
| demo.languageLabPage.languageLabPage | languageLabPage | — | UNRESOLVED |
| demo.languageLabPage.node-625 | source-game-hero | — | UNRESOLVED |
| demo.languageLabPage.node-626 | source-hero-head | — | UNRESOLVED |
| demo.languageLabPage.node-628 | Release localization | — | UNRESOLVED |
| demo.languageLabPage.node-629 | Языковая лаборатория | — | UNRESOLVED |
| demo.languageLabPage.node-630 | Все 16 языков и полный актуальный набор строк каждого языка. Никаких сокращённых демонстрационных переводов. | — | UNRESOLVED |
| demo.languageLabPage.node-631 | 文 | — | UNRESOLVED |
| demo.languageLabPage.node-632 | source-stats | — | UNRESOLVED |
| demo.languageLabPage.node-633 | source-stat | — | UNRESOLVED |
| demo.languageLabPage.node-634 | Locales | — | UNRESOLVED |
| demo.languageLabPage.labLocaleCount | 16 | — | UNRESOLVED |
| demo.languageLabPage.node-636 | source-stat | — | UNRESOLVED |
| demo.languageLabPage.node-637 | Keys / locale | — | UNRESOLVED |
| demo.languageLabPage.labKeyCount | 1717 | — | UNRESOLVED |
| demo.languageLabPage.node-639 | source-stat | — | UNRESOLVED |
| demo.languageLabPage.node-640 | FAQ / locale | — | UNRESOLVED |
| demo.languageLabPage.node-641 | 230 | — | UNRESOLVED |
| demo.languageLabPage.node-642 | source-card localization-toolbar | — | UNRESOLVED |
| demo.languageLabPage.node-643 | localization-toolbar-row | — | UNRESOLVED |
| demo.languageLabPage.node-644 | ← Приложение | — | UNRESOLVED |
| demo.languageLabPage.node-645 | source-field | — | UNRESOLVED |
| demo.languageLabPage.node-646 | Язык предпросмотра | — | UNRESOLVED |
| demo.languageLabPage.labLanguageSelect | labLanguageSelect | — | UNRESOLVED |
| demo.languageLabPage.node-648 | source-field localization-search | — | UNRESOLVED |
| demo.languageLabPage.node-649 | Поиск по ключу или тексту | — | UNRESOLVED |
| demo.languageLabPage.labSearch | labSearch | — | UNRESOLVED |
| demo.languageLabPage.node-651 | source-field | — | UNRESOLVED |
| demo.languageLabPage.node-652 | Раздел ключей | — | UNRESOLVED |
| demo.languageLabPage.labNamespace | labNamespace | — | UNRESOLVED |
| demo.languageLabPage.localeNativeRibbon | localeNativeRibbon | — | UNRESOLVED |
| demo.languageLabPage.viewportTestRow | viewportTestRow | — | UNRESOLVED |
| demo.languageLabPage.node-658 | 320 | — | UNRESOLVED |
| demo.languageLabPage.node-659 | 360 | — | UNRESOLVED |
| demo.languageLabPage.node-660 | 390 | — | UNRESOLVED |
| demo.languageLabPage.node-661 | 412 | — | UNRESOLVED |
| demo.languageLabPage.node-662 | FULL | — | UNRESOLVED |
| demo.languageLabPage.labStatus | labStatus | — | UNRESOLVED |
| demo.languageLabPage.node-664 | source-card language-comparison-card | — | UNRESOLVED |
| demo.languageLabPage.node-665 | Сравнение одного ключа во всех 16 языках | — | UNRESOLVED |
| demo.languageLabPage.node-666 | Нажмите любую строку ниже. Сравнение показывает фактический текст и длину каждого перевода. | — | UNRESOLVED |
| demo.languageLabPage.languageComparison | languageComparison | — | UNRESOLVED |
| demo.languageLabPage.node-668 | source-card | — | UNRESOLVED |
| demo.languageLabPage.node-669 | Полный каталог строк выбранного языка | — | UNRESOLVED |
| demo.languageLabPage.localeStringGrid | localeStringGrid | — | UNRESOLVED |
| demo.languageLabPage.localeLoadMore | Показать ещё | — | UNRESOLVED |
| demo.adsPage.adsPage | adsPage | frontend/src/pages/ads.tsx | REGION_ONLY |
| demo.adsPage.node-673 | source-game-hero | frontend/src/pages/ads.tsx | REGION_ONLY |
| demo.adsPage.node-674 | source-hero-head | frontend/src/pages/ads.tsx | REGION_ONLY |
| demo.adsPage.node-676 | Реклама | frontend/src/pages/ads.tsx | REGION_ONLY |
| demo.adsPage.node-677 | Реклама → Задания | frontend/src/pages/ads.tsx:45 | SOURCE_CANDIDATE |
| demo.adsPage.node-678 | Рекламные задания доступны в разделе «Задания». | frontend/src/pages/ads.tsx:51 | SOURCE_CANDIDATE |
| demo.adsPage.node-679 | AD | frontend/src/pages/ads.tsx | REGION_ONLY |
| demo.adsPage.node-680 | source-card | frontend/src/pages/ads.tsx | REGION_ONLY |
| demo.adsPage.node-681 | Реклама находится в разделе «Задания» | frontend/src/pages/ads.tsx:44 | SOURCE_CANDIDATE |
| demo.adsPage.node-682 | Параметры запроса сохраняются при переходе. | frontend/src/pages/ads.tsx:54 | SOURCE_CANDIDATE |
| demo.adsPage.node-683 | Открыть задания | frontend/src/pages/ads.tsx | REGION_ONLY |
| demo.errorPage.errorPage | errorPage | frontend/src/pages/404.tsx:15; frontend/src/pages/500.tsx:45 | SOURCE_CANDIDATE |
| demo.errorPage.node-685 | source-card | frontend/src/pages/404.tsx; frontend/src/pages/500.tsx | REGION_ONLY |
| demo.errorPage.node-686 | EFHC SYSTEM | frontend/src/pages/404.tsx; frontend/src/pages/500.tsx | REGION_ONLY |
| demo.errorPage.node-687 | Раздел не найден | frontend/src/pages/404.tsx:21 | SOURCE_CANDIDATE |
| demo.errorPage.node-688 | Системные пользовательские страницы также используют выбранную глобальную тему. | frontend/src/pages/404.tsx:27 | SOURCE_CANDIDATE |
| demo.errorPage.node-689 | На главный экран | frontend/src/pages/404.tsx:23 | SOURCE_CANDIDATE |
| demo.adminPage.adminPage | adminPage | frontend/src/components/admin/AdminPage.tsx:63 | SOURCE_CANDIDATE |
| demo.adminPage.node-691 | admin-reference-hero | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-692 | Административный режим | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-693 | Рабочие модули, показатели и действия администратора. | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-694 | admin-reference-stats | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-695 | admin-reference-stat | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.adminHomeUsers | 0 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-698 | admin-reference-stat | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.adminHomeActivePanels | 0 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-701 | admin-reference-stat | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.adminHomeGeneratedKwh | 0.00000000 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-704 | admin-reference-stat | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.adminHomeMainBalance | 0.00000000 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-707 | admin-home-bank-charts-v218 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-708 | admin-home-bank-chart-v218 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-713 | admin-home-bank-chart-v218 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-718 | admin-reference-section | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-720 | Цветовые категории административных модулей | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-731 | admin-reference-grid | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-732 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-735 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-738 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-741 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-744 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-747 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-750 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-753 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-756 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-759 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-762 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-765 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-768 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-771 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-774 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminPage.node-777 | admin-reference-module admin-module-v132 | frontend/src/pages/admin/index.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.adminWithdrawalsPage | adminWithdrawalsPage | frontend/src/components/admin/AdminPage.tsx:63 | SOURCE_CANDIDATE |
| demo.adminWithdrawalsPage.node-781 | source-profile-topbar | frontend/src/components/admin/AdminPage.tsx:67 | SOURCE_CANDIDATE |
| demo.adminWithdrawalsPage.node-782 | Назад | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-785 | ☰ Меню | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-786 | release-admin-facts | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-787 | release-admin-fact | frontend/src/components/admin/AdminDashboardUiKit.tsx:477; frontend/src/pages/admin/withdrawals.tsx:1075 | SOURCE_CANDIDATE |
| demo.adminWithdrawalsPage.adminWithdrawTotal | 0 | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-790 | release-admin-fact | frontend/src/components/admin/AdminDashboardUiKit.tsx:477; frontend/src/pages/admin/withdrawals.tsx:1075 | SOURCE_CANDIDATE |
| demo.adminWithdrawalsPage.adminWithdrawPending | 0 | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-793 | release-admin-fact | frontend/src/components/admin/AdminDashboardUiKit.tsx:477; frontend/src/pages/admin/withdrawals.tsx:1075 | SOURCE_CANDIDATE |
| demo.adminWithdrawalsPage.adminWithdrawPaid | 0 | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-796 | release-admin-fact | frontend/src/components/admin/AdminDashboardUiKit.tsx:477; frontend/src/pages/admin/withdrawals.tsx:1075 | SOURCE_CANDIDATE |
| demo.adminWithdrawalsPage.adminWithdrawRejected | 0 | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-799 | Поиск Global ID и экспорт журнала выплат | frontend/src/pages/admin/withdrawals.tsx:944 | SOURCE_CANDIDATE |
| demo.adminWithdrawalsPage.node-800 | admin-user-search-main | frontend/src/pages/admin/withdrawals.tsx:950; frontend/src/pages/admin/withdrawals.tsx:951 | SOURCE_CANDIDATE |
| demo.adminWithdrawalsPage.node-801 | Global ID | frontend/src/pages/admin/withdrawals.tsx:955 | SOURCE_CANDIDATE |
| demo.adminWithdrawalsPage.adminWithdrawGlobalIdV436 | Global ID для всего модуля Выплаты | frontend/src/components/admin/AdminPromptModal.tsx:48; frontend/src/pages/admin/withdrawals.tsx:962 | SOURCE_CANDIDATE |
| demo.adminWithdrawalsPage.node-803 | Сбросить | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-804 | Найти | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-805 | efhc-admin-withdrawals-export-v439 | frontend/src/pages/admin/withdrawals.tsx:998; frontend/src/pages/admin/withdrawals.tsx:997 | SOURCE_CANDIDATE |
| demo.adminWithdrawalsPage.node-806 | JSON | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-807 | CSV | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-808 | TXT | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-809 | XLSX | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-810 | admin-reference-section | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-811 | source-row | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.adminWithdrawRepair | Проверить консистентность | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-816 | source-segmented admin-withdraw-filter | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-817 | Все | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-818 | Pending | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-819 | Paid | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.node-820 | Rejected | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.adminWithdrawList | adminWithdrawList | frontend/src/pages/admin/withdrawals.tsx | REGION_ONLY |
| demo.adminWithdrawalsPage.adminWithdrawStatus | adminWithdrawStatus | frontend/src/components/admin/AdminWithdrawalsMobileDecisionPanel.tsx:18; frontend/src/pages/admin/withdrawals.tsx:47 | SOURCE_CANDIDATE |
| demo.adminWithdrawDecisionOverlay.adminWithdrawDecisionOverlay | adminWithdrawDecisionOverlay | — | UNRESOLVED |
| demo.adminWithdrawDecisionOverlay.node-824 | standalone-settings-dialog | — | UNRESOLVED |
| demo.adminWithdrawDecisionOverlay.node-825 | source-row | — | UNRESOLVED |
| demo.adminWithdrawDecisionOverlay.adminWithdrawDecisionTitle | Заявка на выплату | — | UNRESOLVED |
| demo.adminWithdrawDecisionOverlay.node-827 | × | — | UNRESOLVED |
| demo.adminWithdrawDecisionOverlay.adminWithdrawDecision | adminWithdrawDecision | — | UNRESOLVED |
| demo.adminAdsPage.adminAdsPage | adminAdsPage | — | UNRESOLVED |
| demo.adminAdsPage.node-830 | admin-page-nav-v133 | — | UNRESOLVED |
| demo.adminAdsPage.node-831 | ← Назад | — | UNRESOLVED |
| demo.adminAdsPage.node-832 | ☰ Меню | — | UNRESOLVED |
| demo.adminAdsPage.node-833 | admin-reference-hero | — | UNRESOLVED |
| demo.adminAdsPage.node-834 | Рекламные сервисы | — | UNRESOLVED |
| demo.adminAdsPage.node-835 | Реклама | — | UNRESOLVED |
| demo.adminAdsPage.node-836 | Состояние подключённых рекламных сервисов. | — | UNRESOLVED |
| demo.adminAdsPage.node-837 | release-admin-facts | — | UNRESOLVED |
| demo.adminAdsPage.node-838 | release-admin-fact | — | UNRESOLVED |
| demo.adminAdsPage.node-841 | release-admin-fact | — | UNRESOLVED |
| demo.adminAdsPage.node-844 | release-admin-fact | — | UNRESOLVED |
| demo.adminAdsPage.node-847 | release-admin-fact | — | UNRESOLVED |
| demo.adminAdsPage.node-850 | admin-reference-section | — | UNRESOLVED |
| demo.adminAdsPage.node-852 | standalone-admin-bars | — | UNRESOLVED |
| demo.adminAdsPage.node-861 | admin-reference-section | — | UNRESOLVED |
| demo.adminAdsPage.node-862 | source-row | — | UNRESOLVED |
| demo.adminAdsPage.node-866 | Открыть актуальный раздел | — | UNRESOLVED |
| demo.adminAdsPage.node-867 | release-admin-simple-table | — | UNRESOLVED |
| demo.adminUsersPage.adminUsersPage | adminUsersPage | frontend/src/pages/admin/users.tsx:452 | SOURCE_CANDIDATE |
| demo.adminUsersPage.node-877 | source-profile-topbar admin-users-topbar-v138 | frontend/src/pages/admin/users.tsx | REGION_ONLY |
| demo.adminUsersPage.node-878 | Назад | frontend/src/pages/admin/users.tsx | REGION_ONLY |
| demo.adminUsersPage.node-881 | ☰ Меню | frontend/src/pages/admin/users.tsx | REGION_ONLY |
| demo.adminUsersPage.adminUsersData | adminUsersData | frontend/src/pages/admin/users.tsx | REGION_ONLY |
| demo.adminShopPage.adminShopPage | adminShopPage | frontend/src/pages/admin/shop.tsx | REGION_ONLY |
| demo.adminShopPage.node-884 | source-profile-topbar | frontend/src/pages/admin/shop.tsx | REGION_ONLY |
| demo.adminShopPage.node-885 | Назад | frontend/src/pages/admin/shop.tsx | REGION_ONLY |
| demo.adminShopPage.adminShopNavTitleV387 | Магазин | frontend/src/pages/admin/shop.tsx | REGION_ONLY |
| demo.adminShopPage.node-888 | ☰ Меню | frontend/src/pages/admin/shop.tsx | REGION_ONLY |
| demo.adminShopPage.adminShopDataV150 | adminShopDataV150 | frontend/src/pages/admin/shop.tsx | REGION_ONLY |
| demo.adminBankPage.adminBankPage | adminBankPage | frontend/src/components/admin/AdminPage.tsx:63 | SOURCE_CANDIDATE |
| demo.adminBankPage.node-891 | source-profile-topbar | frontend/src/pages/admin/bank.tsx | REGION_ONLY |
| demo.adminBankPage.node-892 | Назад | frontend/src/pages/admin/bank.tsx | REGION_ONLY |
| demo.adminBankPage.node-895 | ☰ Меню | frontend/src/pages/admin/bank.tsx | REGION_ONLY |
| demo.adminBankPage.adminBankData | adminBankData | frontend/src/pages/admin/bank.tsx | REGION_ONLY |
| demo.adminBonusesPage.adminBonusesPage | adminBonusesPage | frontend/src/components/admin/AdminBonusesAnalytics.tsx:122; frontend/src/pages/admin/bonuses.tsx:290 | SOURCE_CANDIDATE |
| demo.adminBonusesPage.node-898 | source-profile-topbar | frontend/src/components/admin/AdminBonusesAnalytics.tsx; frontend/src/pages/admin/bonuses.tsx | REGION_ONLY |
| demo.adminBonusesPage.node-899 | Назад | frontend/src/components/admin/AdminBonusesAnalytics.tsx; frontend/src/pages/admin/bonuses.tsx | REGION_ONLY |
| demo.adminBonusesPage.node-902 | ☰ Меню | frontend/src/components/admin/AdminBonusesAnalytics.tsx; frontend/src/pages/admin/bonuses.tsx | REGION_ONLY |
| demo.adminBonusesPage.adminBonusesData | adminBonusesData | frontend/src/components/admin/AdminBonusesAnalytics.tsx; frontend/src/pages/admin/bonuses.tsx | REGION_ONLY |
| demo.adminDetailPage.adminDetailPage | adminDetailPage | — | UNRESOLVED |
| demo.adminDetailPage.node-905 | source-profile-topbar | — | UNRESOLVED |
| demo.adminDetailPage.node-906 | Назад | — | UNRESOLVED |
| demo.adminDetailPage.adminDetailNavTitle | Модуль | — | UNRESOLVED |
| demo.adminDetailPage.node-910 | ☰ Меню | — | UNRESOLVED |
| demo.adminDetailPage.node-911 | admin-reference-hero | — | UNRESOLVED |
| demo.adminDetailPage.node-912 | Административный раздел | — | UNRESOLVED |
| demo.adminDetailPage.adminDetailTitle | Модуль | — | UNRESOLVED |
| demo.adminDetailPage.adminDetailNote | adminDetailNote | — | UNRESOLVED |
| demo.adminDetailPage.node-915 | admin-reference-section | — | UNRESOLVED |
| demo.adminDetailPage.adminDetailBody | Просматривайте состояние раздела и выполняйте доступные действия. | — | UNRESOLVED |
| demo.adminDetailPage.node-918 | admin-module-sim-toolbar | — | UNRESOLVED |
| demo.adminDetailPage.node-919 | Обновить данные | — | UNRESOLVED |
| demo.adminDetailPage.node-920 | Выполнить все доступные действия | — | UNRESOLVED |
| demo.adminDetailPage.node-921 | Admin API Workbench | — | UNRESOLVED |
| demo.adminDetailPage.adminDetailData | adminDetailData | — | UNRESOLVED |
| demo.adminDetailPage.adminDetailActions | adminDetailActions | — | UNRESOLVED |
| demo.adminDetailPage.adminDetailResult | Данные готовы. | — | UNRESOLVED |
| demo.adminDetailPage.adminDetailStatus | Данные раздела обновляются после каждого действия. | — | UNRESOLVED |
| demo.adminApiWorkbenchPage.adminApiWorkbenchPage | adminApiWorkbenchPage | frontend/src/pages/admin/api-workbench.tsx:101 | SOURCE_CANDIDATE |
| demo.adminApiWorkbenchPage.node-927 | source-profile-topbar | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.node-928 | Назад | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.node-931 | ☰ Меню | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.adminApiWorkbench | adminApiWorkbench | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.node-933 | admin-api-workbench_head | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.adminApiCoverageBadge | 0/84 | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.node-938 | admin-api-toolbar | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.adminApiExecuteVisible | Выполнить текущий модуль | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.adminApiExecuteAll | Проверить все Admin routes | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.adminApiReset | Сбросить Admin demo-state | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.adminApiProgress | Готово к проверке. | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.adminApiGroups | adminApiGroups | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.node-944 | admin-api-result | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.node-945 | admin-api-result-head | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.adminApiLastRoute | — | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.adminApiWorkbenchPage.adminApiResult | Выберите действие. | frontend/src/pages/admin/api-workbench.tsx | REGION_ONLY |
| demo.global-shell.node-949 | efhc-game-nav | frontend/src/components/Layout.tsx:177 | SOURCE_CANDIDATE |
| demo.global-shell.node-950 | efhc-game-nav_inner | frontend/src/components/Layout.tsx:806 | SOURCE_CANDIDATE |
| demo.global-shell.bottomNav | bottomNav | frontend/src/components/Layout.tsx:282; frontend/src/components/Layout.tsx:814; frontend/src/components/Layout.tsx:815; frontend/src/components/Layout.tsx:816; frontend/src/components/Layout.tsx:817; frontend/src/components/Layout.tsx:811 | SOURCE_CANDIDATE |
| demo.global-shell.node-952 | Energy | frontend/src/components/Layout.tsx:178 | SOURCE_CANDIDATE |
| demo.global-shell.node-953 | efhc-game-nav_icon | frontend/src/components/Layout.tsx:182 | SOURCE_CANDIDATE |
| demo.global-shell.node-954 | svg | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-957 | Energy | frontend/src/components/Layout.tsx:183 | SOURCE_CANDIDATE |
| demo.global-shell.node-958 | Panels | frontend/src/components/Layout.tsx:178 | SOURCE_CANDIDATE |
| demo.global-shell.node-959 | efhc-game-nav_icon | frontend/src/components/Layout.tsx:182 | SOURCE_CANDIDATE |
| demo.global-shell.node-960 | svg | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-962 | Panels | frontend/src/components/Layout.tsx:183 | SOURCE_CANDIDATE |
| demo.global-shell.node-963 | Exchange | frontend/src/components/Layout.tsx:178 | SOURCE_CANDIDATE |
| demo.global-shell.node-964 | efhc-game-nav_icon | frontend/src/components/Layout.tsx:182 | SOURCE_CANDIDATE |
| demo.global-shell.node-965 | svg | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-968 | Exchange | frontend/src/components/Layout.tsx:183 | SOURCE_CANDIDATE |
| demo.global-shell.node-969 | Tasks | frontend/src/components/Layout.tsx:178 | SOURCE_CANDIDATE |
| demo.global-shell.node-970 | efhc-game-nav_icon | frontend/src/components/Layout.tsx:182 | SOURCE_CANDIDATE |
| demo.global-shell.node-971 | svg | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-974 | Tasks | frontend/src/components/Layout.tsx:183 | SOURCE_CANDIDATE |
| demo.global-shell.node-975 | Referrals | frontend/src/components/Layout.tsx:178 | SOURCE_CANDIDATE |
| demo.global-shell.node-976 | efhc-game-nav_icon | frontend/src/components/Layout.tsx:182 | SOURCE_CANDIDATE |
| demo.global-shell.node-977 | svg | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-981 | Referrals | frontend/src/components/Layout.tsx:183 | SOURCE_CANDIDATE |
| demo.global-shell.node-982 | Ranks | frontend/src/components/Layout.tsx:178 | SOURCE_CANDIDATE |
| demo.global-shell.node-983 | efhc-game-nav_icon | frontend/src/components/Layout.tsx:182 | SOURCE_CANDIDATE |
| demo.global-shell.node-984 | svg | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-987 | Ranks | frontend/src/components/Layout.tsx:183 | SOURCE_CANDIDATE |
| demo.global-shell.swipeDotsLayer | swipeDotsLayer | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.customizationControlDock | customizationControlDock | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.globalThemeControl | Переключить цветовую тему | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.customizeButton | Настроить оформление | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-993 | svg | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.techWorkbench | Техническая таблица вариантов | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-997 | tech-workbench_head | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-999 | Техническая рабочая область | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1000 | единый theme slot действует на все пользовательские страницы; Admin исключён. История и FAQ выбираются отдельными контролами ниже. Только st | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1002 | NOT FOR RELEASE | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1003 | Единая техническая рабочая область | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1004 | standalone-simulation-control | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.simulationControlState | DEMO ON · RUNNING · VIP | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.simulationDemoToggle | DEMO ON | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.simulationPauseToggle | Pause | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.simulationCatchUp | Offline +1h | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.simulationReset | Reset | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.balanceScaleTestButton | Проверить масштаб основного баланса | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.balanceScaleTestPx | -- | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1014 | Языки и FAQ | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1015 | standalone-status-route-control | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.workbenchUserVisibility | USER | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.workbenchAdminVisibility | ADMIN | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.workbenchAccessVisibilityMessage | USER · Admin-входы скрыты · разрывы: 0 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1022 | standalone-status-route-control | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1027 | tech-bank-integrity-stress-v180 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1028 | tech-bank-integrity-stress-v180-head | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.techBankIntegrityPreview | ✓ 100% | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1033 | Стресс режим индикатора целостности Банка | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1034 | Норма 100% | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1035 | Стресс вниз 99.9% | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1036 | Стресс вверх 100.1% | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1038 | standalone-status-route-control | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.workbenchVipRouteToggle | VIP ON | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.workbenchActivRouteToggle | Activ ON | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.workbenchStatusRouteMessage | Activ = наличие хотя бы одной активной панели. | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1046 | standalone-referral-scenarios | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1047 | source-row | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.workbenchReferralScenarioNext | Следующий | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.workbenchReferralScenarios | workbenchReferralScenarios | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.workbenchReferralScenarioMessage | Выберите сценарий. | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1054 | standalone-progression-control | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.workbenchEnergyLevels | workbenchEnergyLevels | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.workbenchReferralLevels | workbenchReferralLevels | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.workbenchProgressionMessage | Production level не записывается вручную: меняются только demo source metrics. | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1061 | standalone-individual-theme-control | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.standaloneIndividualThemeGrid | standaloneIndividualThemeGrid | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1066 | tech-page | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1067 | admin-reference-section | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1070 | admin-qa-v133 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1071 | admin-qa-v133_head | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.adminQaDatasetBadge | готов | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1076 | admin-qa-v133_stats | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1077 | admin-qa-v133_stat | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.adminQaUsers | 0 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1080 | admin-qa-v133_stat | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.adminQaTransactions | 0 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1083 | admin-qa-v133_stat | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.adminQaTypes | 11 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1086 | admin-qa-v133_stat | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.adminQaPanels | 0 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1089 | admin-qa-v133_stat | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.adminQaWithdrawals | 0 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1092 | admin-qa-v133_stat | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.adminQaDeposits | 0 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1095 | admin-qa-v133_stat | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.adminQaOrders | 0 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1098 | admin-qa-v133_stat | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.adminQaLogs | 0 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1101 | Размер набора | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1102 | 100 пользователей | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1103 | 500 пользователей | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1104 | 1000 пользователей | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1105 | Нагрузочный тест | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1106 | Smoke ×1 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1107 | Mixed ×10 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1108 | Burst ×25 | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.adminQaLoadResult | Набор будет создан при открытии Admin. Нагрузочные режимы проверяют только браузерный Admin data-engine. | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.techPageTabs | Страницы технической области | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.techVariantTables | techVariantTables | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.techCombination | techCombination | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.node-1113 | tech-actions | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.techResetDraft | Сбросить draft | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |
| demo.global-shell.techSaveDraft | Сохранить ✓ | frontend/src/components/Layout.tsx; frontend/src/components/GlobalHeader.tsx | REGION_ONLY |

## Что остаётся до точной полной матрицы

1. Реальный запуск утверждённого HTML и текущего React в сопоставимых браузерных условиях. Доступ к Test-3 из текущего browser окружения отклонён политикой URL; это не сообщение о неисправности сайта.
2. Полный перечень динамических карточек, модальных окон, состояний, шаблонов и цветовых тем.
3. Разрешение всех кандидатов до конкретных JSX/DOM и CSS cascade, измерение геометрии, цвета, типографики, изображений и поведения.
4. Таблица проверенных страниц/состояний и доказательства для каждого результата. Сейчас визуальных PASS нет, измеренный процент соответствия не вычислен.

Исходные архивы и приложение не менялись. Новый production release, push, импорт и deploy не выполнялись. Это внешний аудиторский пакет.
