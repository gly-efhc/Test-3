# EFHC Reconstruction v871 — owner-canon source migration 01

**Source physical base:** FRONTEND_RECONSTRUCTION_v870.zip.
**Immutable authority:** frozen FRONTEND_v866.html (SHA-256 9b6371f5fb62939596b78206f95031c447e9f2b375e62b30704403bb25102aef).
**Public comparison:** https://gly-efhc.github.io/Test-3/ , observed v870; 390×844.
**Status:** source migration PARTIAL; no 100% browser visual certification.

Changes:
- Source-derived CSS baseline for real React public header, energy card, progress, and bottom navigation (not an HTML imitation); only appMode=user.
- Physically embedded original WebP energy background from frozen HTML as CSS image source, replacing unrelated `/skins/1.webp` on the chosen public shell.
- Consistent Pages-only homepage seed values from frozen HTML, including level 9 and 60 panels, keeping live/prod data untouched.
- Available energy precision = 8 decimal places as frozen HTML.
- Disable overlaying onboarding exclusively for public Pages visual comparison, not general product.
- Skip manifest link on Pages because Pages safety script removes file.
- Import user-supplied element mapping unchanged for future source migration.

Unchanged: frozen v866 HTML/ZIP, production backend, authorization, real financial logic, admin UI; all protected modules outside this narrow user-shell scope.

Verification gate: frozen fixture tests + existing tests, ZIP CRC, import compatibility, GitHub build and browser visual comparison still needed on deployed v871.

Pages smoke v871 additionally gates visible canon home seed, hidden onboarding, and 6 routes: /, /panels/, /ranks/, /tasks/, /faq/, /hub/.
