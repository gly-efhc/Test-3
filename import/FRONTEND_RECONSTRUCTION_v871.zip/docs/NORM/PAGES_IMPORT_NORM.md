# Test-3 import and manual Pages publication — NORM (v870)

1. **Один вход:** `import/FRONTEND_RECONSTRUCTION_vNNN.zip`, только один ZIP одновременно. `import/README.md` неприкосновенен.
2. `efhc-import.yml` — постоянный импортёр, установленный OWNER. Проверяет ZIP/CRC/path/source и обновляет `site/frontend/`, `site/RELEASE.json`, `site/ci/pages-tools/` (4 allow-listed tools). В `.github/workflows/` не пишет.
3. В каждом ZIP хранится `ci/efhc-pages.yml` как **источник четырёх инструментов**: `prepare_pages.py`, `fix_pages_assets.py`, `verify_export.py`, `browser-smoke.mjs`. Импортёр извлекает их в `site/ci/pages-tools/` обычным коммитом. Дополнительные токены/секреты не нужны.
4. `efhc-pages.yml` остаётся постоянным ручным запускателем GitHub Pages, установленным OWNER один раз. Он загружает инструменты из `site/ci/pages-tools/`. Изменять этот файл в GitHub автоматически запрещено.
5. GitHub `GITHUB_TOKEN` не используется для изменения workflow-файлов; прежняя ошибка `refusing to allow ... workflow ... without workflows permission` исключена конструктивно.
6. Запуск Pages — только OWNER вручную после успешного импорта. Настоящая Next.js React сборка; read-only безопасность; никаких финансовых mutations.
7. В CI проверяются корректный Next static export и маршруты в headless Chrome. Для Next Pages Router корневой контейнер `#__next`, **не** `#_next`.
8. После полного успешного Pages deploy cleanup удаляет ровно совпадающий транспортный ZIP; `README.md` остаётся. При FAIL ZIP сохраняется.
9. Если в `import/` остался архив после FAIL, перед загрузкой нового ZIP нужно удалить предыдущий ZIP, оставив README: импортёр допускает только один.
10. Замороженный `FRONTEND_v866.html` — внешняя SSOT. Визуальная и runtime сертификация нового ZIP проводится отдельно; успешная сборка не равна визуальному соответствию.
