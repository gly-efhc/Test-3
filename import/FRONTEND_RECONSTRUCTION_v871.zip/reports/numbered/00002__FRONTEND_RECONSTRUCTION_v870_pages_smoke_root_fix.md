# RECONSTRUCTION REPORT 00002 — v870 GitHub Pages browser smoke selector

**Основание:** `logs_111014981676.zip` (2026-10-29, Test-3).

- GitHub `Next.js 16.4.3`, TypeScript: PASS.
- Next optimized compilation and 43 page routes, static export (44): PASS.
- `Verify actual React navigation in headless Chrome`: FAIL `REACT_MOUNT_MISSING` at `browser-smoke.mjs:47`.
- Root cause: the smoke test requested `document.querySelector('#_next')` (single `_`), while Next.js Pages Router mounts under `id="__next"` (two `_`). This is a false-negative test guard.
- Change: only `ci/efhc-pages.yml` embedded `browser-smoke.mjs`: `document.getElementById('__next')`. Keep strict checks for recursive `/Test-3/`, 404, fallback page, and the three route checks.
- No changes to actual React `.tsx`/`.css`, NEXT deps, DEV fixtures, runtime contracts, any private/production code or external frozen `FRONTEND_v866.html`.
- Updated portable governance/NORM docs to actual one-time stable YAML + 4 versioned tools from each ZIP; no attempts to update `.github/workflows/` during import.
- Evidence: archive parent CRC, canon SHA256, static selector regression and ZIP post-build checks.
- GitHub import, Pages deploy, headless React mount & no-flicker in v870: **UNVERIFIED until new run**. No 100% visual parity claim.
- Previous failed v869 ZIP must be removed from `import/` before upload of v870; retain README.
- No direct GitHub writes or deployment performed.
