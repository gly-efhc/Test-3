#!/usr/bin/env python3
"""Source-only invariant: test the React root element against Next Pages Router convention."""
import pathlib,re,sys
from zipfile import ZipFile
archive=pathlib.Path(sys.argv[1])
with ZipFile(archive) as z:
  s=z.read('ci/efhc-pages.yml').decode('utf8')
assert "document.getElementById('__next')" in s
assert "document.querySelector('#_next')" not in s
assert 'RECURSIVE_BASEPATH_OR_REDIRECT' in s
assert 'REACT_ROUTE_ERROR' in s
assert "await inspect('/faq/')" in s
assert "await inspect('/hub/')" in s
print('PAGES_SMOKE_ROOT_CONTRACT=PASS')
