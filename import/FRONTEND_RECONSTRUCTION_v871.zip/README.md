# EFHC React Reconstruction — transport ZIP

Главный FRONTEND_v866.html **НЕ в архиве**: он внешний замороженный эталон.
Этот ZIP содержит настоящий React исходник, источник Pages-tools `ci/efhc-pages.yml`,
read-only DEMO-таблицы, и переносимые правила работы с OWNER в структуре
`START_HERE.md` / `AGENTS.md` / `KERNEL.md` / `docs/AI`, `SSOT`, `NORM`.

Постоянный efhc-pages.yml запускает четыре tools, распакованные импортёром в `site/ci/pages-tools/`.
В GitHub Test-3 все изменения идут через загрузку **этого ZIP** в `import/`.
Не распаковывать вручную в `site/frontend/` и не переносить docs/backend/ENV.
Сначала прочитать `START_HERE.md`. Не утверждать визуальную готовность без
реальных браузерных измерений/OWNER acceptance.
