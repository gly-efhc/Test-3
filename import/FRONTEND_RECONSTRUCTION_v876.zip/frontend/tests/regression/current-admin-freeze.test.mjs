import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";

const frontendRoot = path.resolve(import.meta.dirname, "../..");
const root = path.resolve(frontendRoot, "..");
const manifest = JSON.parse(fs.readFileSync(path.join(import.meta.dirname, "admin-freeze-manifest.json"), "utf8"));

test("OWNER v874: React Admin reconstruction is authorized; the v866 HTML reference remains external and immutable", () => {
  // Previous hashes are retained for provenance, never used as an Admin
  // reconstruction blocker after the owner's explicit decision.
  assert.equal(manifest.schema, "EFHC_CURRENT_ADMIN_VISUAL_FREEZE_V2");
  for (const rel of Object.keys(manifest.files)) {
    assert.ok(fs.existsSync(path.join(root, rel)), `missing Admin provenance file: ${rel}`);
  }
  const proof = fs.readFileSync(path.join(frontendRoot, "src/proof/AdminVisualProofRouter.tsx"), "utf8");
  const app = fs.readFileSync(path.join(frontendRoot, "src/pages/_app.tsx"), "utf8");
  assert.match(proof, /data-efhc-admin-readonly-demo/);
  assert.match(app, /NEXT_PUBLIC_EFHC_PAGES_PREVIEW/);
  assert.match(app, /effectiveAdminVisualProofPath/);
  assert.match(app, /adminRouteBlocked/);
  assert.match(proof, /admin\/api-workbench/);
});
