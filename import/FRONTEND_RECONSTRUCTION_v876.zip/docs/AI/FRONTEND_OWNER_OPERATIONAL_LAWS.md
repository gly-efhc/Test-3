# OWNER OPERATIONAL LAWS — EFHC React Reconstruction

## 0. Authority and change control

1. Текущая прямая команда OWNER первична; менять scope нельзя.
2. Это **только рабочая ветка React frontend**, а не новый backend/production
   релиз. Единственный выбранный ZIP — переносное состояние ветки.
3. Заморозка `FRONTEND_v866.html` **абсолютна**: ни байта изменения, никакой
   подмены копией или «улучшения» эталона. Внешний SHA — SSOT.
4. Задача — **100% соответствие React утверждённому DEMO** по DOM/геометрии,
   цвету, материалам, шрифтам, логотипу, SVG, progress, интерактивности,
   responsive, всем доступным страницам, CT и Design. Полное совпадение
   подтверждается browser evidence + личным OWNER acceptance, не обещанием.
5. Визуальные элементы, которые удалены из DEMO, должны быть физически
   удалены из React, если это доказано и не уничтожает runtime contracts.

## 1. Рабочая схема с OWNER (постоянная)

1. Работать по-русски; не требовать повторного утверждения принятых правил.
2. Сразу проверять физические файлы/логи, затем действовать в разрешённом
   scope. Новые идеи не выдавать за выполненную работу.
3. Артефакт — **один новый физический ZIP** `FRONTEND_RECONSTRUCTION_vNNN.zip`;
   новая версия после предыдущей, исходный ZIP не менять.
4. В ZIP только исходники React, нужные assets, фронтенд-сборочные файлы,
   компактная документация/правила, локальные проверки и `ci/efhc-pages.yml`.
   Никаких backend/, ENV, ключей, old complete archive, historical junk.
5. OWNER загружает ZIP только в `gly-efhc/Test-3/import/`. Импортёр обновляет
   `site/frontend/` и `site/ci/pages-tools/`; постоянный `efhc-pages.yml`
   запускает обновлённые инструменты. Pages запускает вручную OWNER. После успешной публикации ZIP удаляется, README остаётся.
6. Прямые правки `site/frontend`, дополнительный импортёр, отдельные таблицы,
   новые YAML-имена или PR запрещены без прямой команды.
7. Импортёр не пишет в `.github/workflows/` и не требует дополнительных прав
   или токенов. Если изменяется структура запуска, обязательно получить OWNER
   решение на однократную ручную замену YAML.
8. Перед ссылкой на ZIP/файл физически проверить существование и SHA/CRC.
9. Отчёты — один связный immutable report на завершённый инженерный блок,
   не десяток отчётов на микроправки. Версионные/цикловые счётчики не смешивать.
10. По завершении задачи — STOP. Никогда не начинать следующий цикл автоматически.

## 2. Визуальная реконструкция

- Browser снимки React и DEMO делать с идентичным viewport, route, CT, Design,
  content, scroll/state, язык, splash state; вычислять пиксельный diff и
  computed CSS. USER лично принимает результат.
- Не синтезировать отсутствующие DEMO страницы; сначала искать вложенные.
- Не сохранять устаревшие визуальные алиасы без цели, но не удалять активные
  mapping без миграции пользовательских сохранённых ID и точной регрессии.
- Сохранять языковую карусель, музыку, 3-секундное ⚙, независимую 🌐,
  минимальные HUB 50 px; React Admin подлежит восстановлению (его визуальная заморозка отменена OWNER).
- Если React runtime временно требует фикстуры, использовать настоящие React
  компоненты и детерминированные прочитанные из v866 DEMO-данные, но не
  фальшивый standalone HTML вместо React.

## 3. Security and testing

- Публичная DEMO сборка обязана блокировать любые реальные mutations, wallet
  signing, платежи, TON RPC, выводы, личные данные и Admin полномочия.
- Тестовые Панели/Ранги/Задачи: только seed-данные из freeze DEMO, режим read-only.
- TypeScript/Next/Chromium/Pages — отдельные статусы; нельзя скрывать FAIL
  через SKIP, disable typecheck, ложные скриншоты или downgrade зависимостей.
- Следить за импортом исходников, целостностью workflow, NEXT basePath,
  root `index.html`, роутами и работой в мобильном браузере.
- Старые React элементы заменять по этапам, обеспечивая сохранение functionality.

## 4. Revisions

Эти законы меняются только после прямой OWNER-команды и входят во **все**
последующие физические ZIP. Изменение фиксировать в одном связанном отчёте,
включая изменённые/удалённые правила. Не редактировать старые отчёты задним числом.


## OWNER correction, 2026-10-30 — Admin and account links
- The only frozen visual authority is standalone `FRONTEND_v866.html` (external SHA-256 immutable). React Admin is **not** frozen; all React Admin screens must be reconstructed to match this external reference, like all user screens.
- Old byte-for-byte React Admin visual freeze regression is retired as a blocking gate; its hash manifest remains historical evidence, not active requirement.
- In public Pages DEMO, Admin preview and account-provider buttons, **especially Telegram**, must be visible and reachable through normal React UI; don't rely on undocumented query params or browser JS flags.
- Admin DEMO is read-only, with test records and no actual permissions. Provider DEMO only simulates linking status without OAuth, Global ID mutation, credentials, payments or backend writes. Production RBAC/auth/financial contracts remain secured.
- Release is only a full standalone reconstruction ZIP via the existing import workflow; no direct GitHub writes and no additional YAML manual step.

## 5. Отчёты и циклы (решение OWNER от 2026-10-30)
- `reports/` является постоянным переносимым архивом фактических работ: номерные immutable отчёты, циклы, worklogs, read-only evidence и индексы.
- В каждый новый рабочий ZIP включать все предыдущие reports/ и добавлять один консолидированный номерной отчёт на завершённый блок; не создавать репорт на микроправки.
- Цикл `RECON_CYCLE_NNNN` открывать только по прямой команде OWNER; `VERSION`, номер отчёта, номер цикла и номер основного production frontend независимы.
- Исторические этапы v867–v874 восстановлены только из ZIP и CI-log evidence; не выдавать ретроспективные summary за realtime запись.
- Доказательства всегда классифицировать как ZIP PASS, local source checks, GitHub Next build, GitHub Pages deployment, browser geometry parity, OWNER accepted.
- История проживает в физическом ZIP даже если импортёр GitHub исключает `reports/` из runtime; это нормальная часть frontend-only архитектуры.
