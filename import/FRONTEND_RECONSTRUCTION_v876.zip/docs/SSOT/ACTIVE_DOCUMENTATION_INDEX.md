# ACTIVE DOCUMENTATION INDEX — frontend-only

- `START_HERE.md` — bootstrapping и current physical authority.
- `AGENTS.md` — обязательный краткий профиль агента.
- `KERNEL.md`, `ops/operator_kernel/run.py` — read-only intake.
- `docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md` — постоянные требования OWNER.
- `docs/AI/FRONTEND_READING_ORDER.md` — последовательность чтения.
- `docs/SSOT/DEMO_FROZEN_VISUAL_SSOT.md` — внешний неизменный визуальный эталон.
- `docs/SSOT/DEMO_DATA_SSOT.md` — детерминированные DEMO-таблицы.
- `docs/SSOT/PROTECTED_RUNTIME_CONTRACTS.md` — защищённый runtime периметр.
- `docs/NORM/PAGES_IMPORT_NORM.md` — единственная схема переноса в Test-3.
- `docs/NORM/RECONSTRUCTION_RELEASE_NORM.md` — версии и проверки.
- `docs/frontend/FRONTEND_ACTIVE_MAIN_ROADMAP.md` — этапы реконструкции.
- `frontend/RECONSTRUCTION_SCHEMA.md` — рабочая схема v869.
- `frontend/RECONSTRUCTION_ROUTE_MATRIX.csv` — 43 маршрута, coverage.
- `reports/RECONSTRUCTION_REPORT_MANIFEST.json` — номера отчётов ветки.

Это отдельный профиль реконструкции; основной production SSOT остаётся
read-only reference для бизнес-логики. Следующие ZIP должны наследовать эти
файлы или делать явно санкционированное OWNER изменение.

## Отчётность v875
- `reports/README.md` — единая нормативная схема истории.
- `reports/RECONSTRUCTION_REPORT_MANIFEST.json` — номерные отчёты 00001–00004 и SHA каждого.
- `reports/cycles/RECONSTRUCTION_CYCLE_MANIFEST.json` — отдельные циклы, текущий завершённый `RECON_CYCLE_0001`.
- `reports/history/RECOVERED_WORK_HISTORY_v867_v874.md` — восстановленные первые логи и ограничения доказательств.
- `reports/logs/` — начатый журнал рабочих действий.

## Актуальный выпуск v876
- `reports/numbered/00005__RECON_CYCLE_0002_v876_css_minifier_fix.md` — текущий report.
- `reports/history/CI_LOG_EVIDENCE_2026-10-30_v875_failure.json` — подтверждённый внешний GH CSSNano fail.
- `frontend/src/reconstruction/verify-css-minifier-v876.test.mjs` — регрессия CSS.
