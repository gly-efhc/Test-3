# EFHC Reconstruction v873 — визуальный доступ к Admin и провайдерам

## Цель
Открыть визуальную проверку административных экранов и интерфейса привязки провайдеров в публичном **read-only** Pages DEMO, не предоставляя настоящих прав, не подключая OAuth к статическому сайту и не меняя v866.

## Изменения
- Для `NEXT_PUBLIC_EFHC_PAGES_PREVIEW=1` и `NEXT_PUBLIC_EFHC_ADMIN_VISUAL_PROOF=1` разрешён просмотр конкретного allowlist административных маршрутов через существующий `AdminVisualProofRouter`. Backend admin guard для production остаётся обязательным.
- Визуальный маркер «DEMO, только чтение» на администраторских экранах.
- В Web Profile добавлена **только Pages DEMO** ссылка на страницу проверки шести аккаунтов-провайдеров (Telegram, Google, Apple, Facebook, Discord, GitHub) с локальной неперсистентной симуляцией состояний. TON Connect остаётся отдельным кошельковым механизмом.
- Никакие провайдеры **не подключены** реально, привязка к Global ID **не реализована** без серверных endpoint, OAuth state/PKCE, проверки токена и защиты от связывания чужой учётной записи. Это **OPEN BLOCKER**, не готовая production функция.
- `FRONTEND_v866.html` не изменён; Admin visual canon также не меняется.

## Проверка после импорта и публикации
1. `/admin/` — раздел открывается, видна надпись DEMO, нельзя выполнять реальные действия.
2. `/admin/users/`, `/admin/panels/`, `/admin/tasks/` — отображаются React-экраны без реальных API данных.
3. `/web-profile/?section=providers` — видны шесть провайдеров, симуляция switch state; обновление страницы сбрасывает тест.
4. `/web-profile/` — ссылка только в Pages DEMO.
5. Production build без `NEXT_PUBLIC_EFHC_PAGES_PREVIEW` не открывает Admin для неподтверждённых пользователей и не показывает фальшивый провайдерский UI.
6. GitHub Pages browser smoke: проверить маршруты, прочесть DOM, зафиксировать screenshot и HTTP ошибки.

Статус: **PASS LOCAL SOURCE**, реальные GitHub Pages и визуальная приёмка **UNVERIFIED**.
