# EFHC React reconstruction — current roadmap

**Цель:** восстановить всю визуальную систему настоящего React по внешнему
неизменяемому `FRONTEND_v866.html`, а не косметически подправлять старый UI.

**P0.** Стабильные GitHub Pages: нет мигания, повторяющегося `/Test-3/`,
заставка заканчивается, навигация работает, fixtures видны в настоящем React.
Статус: в v870 исправлен ошибочный браузерный smoke-selector; повторный GitHub Pages / динамический runtime — НЕ СЕРТИФИЦИРОВАНЫ.

**P1.** Домашняя: фон, логотип, header, баланс, энерго-прогресс, HUB,
4 ссылки, bottom nav, ⚙/🌐; 320/390/desktop и CT×Design. Точный screenshot
comparison, OWNER acceptance.

**P2.** Панели/портфель, ранги, задачи: реальные компоненты + original v866
read-only tables; все карточки, сортировки, pagination, empty/loaded/error.

**P3.** Остальные user routes и 20 React paths без прямого DEMO-ID; искать
вложенные DEMO sections, не придумывать экраны.

**P4.** Admin visual lock, языковая карусель, все варианты CT/Design, адаптив,
клавиатура, доступность, музыкальное поведение. Защищённые production
функциональные контракты нельзя подменять public mock.

**P5.** Физически удалить obsolete визуальные React элементы и alias после
воспроизводимых тестов; перенести сохранённые настройки при необходимости.

**Закрытие:** full rendered parity only after exhaustive evidence + OWNER
визуальная приёмка. Нет утверждённого NEXT cycle без прямой команды OWNER.


- v871 first USER shell/energy source migration: compare visually against frozen v866 in browser, then expand to other regions; not visually certified until owner acceptance.


- v871 first USER shell/energy source migration: compare visually against frozen v866 in browser, then expand to other regions; not visually certified until owner acceptance.

- v872: migrate source-backed profile DOM first, browser proof pending; next reconcile real rendered styles, onboarding and other page components.
