# EFHC Reconstruction v874 — Owner Admin defreeze and visible provider UI

Authority: frozen standalone FRONTEND_v866.html external, checksum verified. Parent FRONTEND_RECONSTRUCTION_v873.zip.

## Changes
1. Visible `ADMIN DEMO` header button in public Test-3 even without Admin credential; normal auth remains on production.
2. Synchronous route mapping for the 21 existing Admin React routes in Pages-only proof, avoids redirect race and accidental denied-screen flash. Expanded `/admin/api-workbench/` and `/admin/emergency/`.
3. Web Profile direct `Подключить Telegram · DEMO` entry, and discoverable `Аккаунты` tab; all six provider connect/disconnect buttons visible. State changes are isolated in memory, never in storage/backend.
4. Removed outdated **React Admin** byte-hash freeze test and replaced with policy/regression guard for the current OWNER scope. Historical provenance manifest kept. The **HTML v866** remains immutable.
5. AdminHome zero-state matches source HTML admin demo. Data is not marked live and no remote fetch is performed for the public Pages DEMO; TON reconcile is simulated only.
6. AdminHome canonical CSS hook classes attached to existing React components as first migration; visual pixel parity must still be checked after published build.

## Non-goals/risks
No actual OAuth login/linking or identity proof through GitHub Pages. Backend authorization, Global ID and financial writes still require protected endpoints and are unchanged.
No claim of 100% Admin visual parity. Must inspect all admin sections after publication; many old React components remain unconverted.

## Browser checks after publish
- `/web-profile/`: immediately find `Подключить Telegram · DEMO`, click it and inspect 6 provider buttons; switch and verify states.
- `/admin/`: accessible via visible header DEMO button, no login required, visual banner and zero-state homepage appear.
- `/admin/api-workbench/`, `/admin/emergency/` and core admin routes show corresponding real React screen; no write operations.
- In actual production configuration, Admin is auth-protected, no public Pages buttons and no simulated providers.
