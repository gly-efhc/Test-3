# Release discipline — lightweight frontend reconstruction

Обязательное: current OWNER scope, один current HEAD/workspace, один read-only
startup Kernel, доказательство изменённых файлов, регрессионные тесты,
неизменность визуального canon, immutable отчет, полный frontend-only ZIP,
ZIP CRC+SHA, отсутствие дубликатов/unsafe paths, настоящий Pages run.

Версии `FRONTEND_RECONSTRUCTION_vNNN.zip` последовательны и не смешиваются
с полной production линейкой `FRONTEND_vNNN.zip`, ADMIN cycles и numbered reports.
Исправление нескольких связанных элементов — один консолидированный report,
не микрорепорт на каждое действие. Исторические отчёты нельзя переписывать.

Последовательность status: PASS LOCAL SOURCE → PASS NEXT BUILD → PASS CHROMIUM
REACT → PASS GITHUB PAGES → PASS VISUAL PARITY + OWNER acceptance.
Отсутствующий этап = UNVERIFIED, не автоматически PASS.

Нельзя загружать backend/ENV/секреты, ослаблять проверки, включать финансовые
операции в DEMO или заменять зависимость на старую ради сборки.

## v875: закон истории и независимых счётчиков
1. Отчёт №000NN в `reports/numbered/` только новый, с SHA в `RECONSTRUCTION_REPORT_MANIFEST.json`.
2. Формальный цикл `RECON_CYCLE_000N` регистрируется только по явному OWNER scope и в `reports/cycles/RECONSTRUCTION_CYCLE_MANIFEST.json`; старую работу ретроспективно не переименовывать в цикл.
3. Источники `reports/history/` содержат физические SHA/CRC, источник/время CI и статус уверенности. Не копировать потенциально чувствительные raw логи в публичный frontend ZIP.
4. Physical ZIP сохраняет reports, хотя importer намеренно не копирует reports в публичный `site/frontend`.
5. Файлы `frontend/` в v875 побайтово идентичны v874; в `ci/efhc-pages.yml` изменён только один неверный отступ внутри bundled browser smoke, блокировавший импорт ZIP. Остальной Pages YAML неизменен.
