# EFHC RECONSTRUCTION OPERATOR KERNEL — read-only intake

Этот ZIP — frontend-only, без полноценного backend, старых reports и production
Operator Kernel. Здесь находится отдельный **малый** проверяющий runner,
`ops/operator_kernel/run.py`, который только читает и сверяет структуру
реконструкции; он **не** заменяет полный production Kernel v866.

Старт: `python ops/operator_kernel/run.py --root . --json` ОДИН раз на новый
workspace. Runner не распаковывает ZIP и не выполняет изменений. FAIL-CLOSED
на отсутствующем governance, версии, React или Pages workflow.

Для новых изменений: прямой scope OWNER → матрица разрешённых файлов →
минимальная реконструкция React → node/TypeScript/Chromium проверки →
новый номерной отчёт ветки реконструкции → новый source ZIP → импорт →
реальные Pages и визуальная приёмка OWNER → STOP. Не открывать следующий
цикл без команды. Старую React-архитектуру можно заменять, но не удалять
работающие API/security/financial contracts без соответствующей замены.

Не применять `--clean-extract` к занятому workspace. Нет права мутировать
GitHub Test-3: OWNER сам загружает архив и запускает Pages.

Продолжающиеся блокеры: полное browser React↔DEMO равенство не доказано,
автоматическое обновление workflow на GitHub пока не подтверждено реальным
импортом. Не объявлять их PASS из-за локального ZIP CRC.

## Reports / Cycles v875
Перед завершением версии проверять целостность и последовательность `reports/RECONSTRUCTION_REPORT_MANIFEST.json`, SHA всех номерных отчётов, наличие cycle IDs из `reports/cycles/RECONSTRUCTION_CYCLE_MANIFEST.json`, неизменность старых reports. Восстановленные блоки v867–v874 не являются официальными задним числом открытыми циклами.
