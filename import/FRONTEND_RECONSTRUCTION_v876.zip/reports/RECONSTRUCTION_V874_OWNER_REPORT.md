# EFHC v874 — OWNER recon scope / preview access
Parent: FRONTEND_RECONSTRUCTION_v873.zip. Visual canon: frozen external FRONTEND_v866.html.
Work: real React Admin preview accessible, account providers including Telegram accessible, obsolete React Admin byte-freeze gate lifted, sample zero-state Admin Home, allowlist expanded, safe production separation.
Evidence: local source/transpile/tests and import ZIP only. Browser build/public visual comparison pending until user imports and publishes.
Not done: live OAuth account linking, production RBAC changes, 100% React–HTML visual equivalence.
