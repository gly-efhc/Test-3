# Восстановленная ранняя история EFHC React Reconstruction

> Это восстановленная хронология из **физических ZIP**, существовавших до записи данного документа, и журналов GitHub Actions. Она **не является** задним числом составленными оригинальными сообщениями разработчика. Факты исходников отделены от неподтверждённых утверждений о публикации/визуальном результате.

## Источники и статусы

- Физическая цепочка `FRONTEND_RECONSTRUCTION_v867.zip` … `v874.zip`; SHA-256 в `ARCHIVE_EVOLUTION_v867_v874.json`.
- Семь предоставленных ZIP-логов Actions; SHA-256 и вывод ошибок в `CI_LOG_EVIDENCE_2026-10-29.json`.
- Два существующих номерных отчёта №00001–00002 и четыре отдельные заметки v871–v874 (сохранены побайтово).
- Неизменяемый эталон `FRONTEND_v866.html`: `9b6371f5fb62939596b78206f95031c447e9f2b375e62b30704403bb25102aef`.

## Эволюция архивов (восстановлено проверкой файлов)

### v867

Старт отдельной frontend-only ветки. Внесены DEMO-таблицы из эталона v866: 60 активных и 60 архивных Панелей, 220 участников Рангов, 5 Задач, React-адаптеры. Старый React UI оставлен как временная основа; визуальный паритет не заявлен.

- Файл: `FRONTEND_RECONSTRUCTION_v867.zip`; SHA-256: `ea032f070fb8793302ae45b3aea898bfb53b4be0161c8b366da790ef6af36ea7`.
- Файлов добавлено: **0**, изменено: **0**, удалено: **0** (сравнение с предыдущим ZIP).
- GitHub CI / визуальное сходство: **не выводится из ZIP**.

### v868

Добавлен `ci/efhc-pages.yml`, инструменты и regression-контуры; изменены `Layout.tsx`, `_app.tsx`, `appBackNavigation.ts` для Pages/React. Наличие кода не доказывает успешный GitHub Pages deploy.

- Файл: `FRONTEND_RECONSTRUCTION_v868.zip`; SHA-256: `8e05a64881990eabff3538e576fab23d6a9fd2ac5780e4b1131b194f9b21f86c`.
- Файлов добавлено: **57**, изменено: **5**, удалено: **0** (сравнение с предыдущим ZIP).
- GitHub CI / визуальное сходство: **не выводится из ZIP**.

### v869

Созданы переносные START_HERE, AGENTS, KERNEL, `docs/AI`, `docs/SSOT`, NORM и первый номерной отчёт. Код React в этом архиве не менялся.

- Файл: `FRONTEND_RECONSTRUCTION_v869.zip`; SHA-256: `790f47830535a4ef6be4e7a741995874fb61000c0edff06bce1f23971801a634`.
- Файлов добавлено: **18**, изменено: **2**, удалено: **0** (сравнение с предыдущим ZIP).
- GitHub CI / визуальное сходство: **не выводится из ZIP**.

### v870

Исправлен ошибочный селектор root mount в браузерном smoke-тесте (`#_next` → `#__next`); визуальная верстка React не менялась.

- Файл: `FRONTEND_RECONSTRUCTION_v870.zip`; SHA-256: `449a5db3cf41479ba8eea5723a87ba7f8bc028455ec684384b77b3bf334c9b25`.
- Файлов добавлено: **2**, изменено: **9**, удалено: **0** (сравнение с предыдущим ZIP).
- GitHub CI / визуальное сходство: **не выводится из ZIP**.

### v871

Начат перенос эталонных стилей из v866 на реальную React-оболочку и карточку энергии; добавлены фон и main demo fixture, скорректирована Pages проверка. Полная визуальная приёмка не подтверждена.

- Файл: `FRONTEND_RECONSTRUCTION_v871.zip`; SHA-256: `2184496b4289293ab12ba734410206dce3fff1e20f533c4a3c386181f8c39894`.
- Файлов добавлено: **9**, изменено: **7**, удалено: **0** (сравнение с предыдущим ZIP).
- GitHub CI / визуальное сходство: **не выводится из ZIP**.

### v872

Перестроена DOM-структура верхнего профиля (отдельные узлы); изменены initial settings Pages и style bindings; добавлена регрессия. Не сертифицировано визуальное совпадение.

- Файл: `FRONTEND_RECONSTRUCTION_v872.zip`; SHA-256: `505421ee922b4bcb2f497c021006b1b82aedd40803e2597e658318969340aa67`.
- Файлов добавлено: **3**, изменено: **9**, удалено: **0** (сравнение с предыдущим ZIP).
- GitHub CI / визуальное сходство: **не выводится из ZIP**.

### v873

Включены Pages-only Admin preview и диагностический DEMO-экран провайдеров аккаунта; нет реального OAuth/Global ID мутаций.

- Файл: `FRONTEND_RECONSTRUCTION_v873.zip`; SHA-256: `8363d0ee582a27a38227c0d9875b98abfc9077cc98a6111dc2a822ff70d5368d`.
- Файлов добавлено: **4**, изменено: **5**, удалено: **0** (сравнение с предыдущим ZIP).
- GitHub CI / визуальное сходство: **не выводится из ZIP**.

### v874

По прямой поправке OWNER Admin React не заморожен: добавлены видимый переход ADMIN DEMO, Telegram DEMO, вкладка Аккаунты, безопасный Admin zero-state; устаревший хэш-блокер React Admin снят. Эталон v866 остаётся неизменным.

- Файл: `FRONTEND_RECONSTRUCTION_v874.zip`; SHA-256: `b8606bc38370d26006ba6e9e48c738e7088a214ccda8a7c8b3594c51794ae7f0`.
- Файлов добавлено: **3**, изменено: **11**, удалено: **0** (сравнение с предыдущим ZIP).
- GitHub CI / визуальное сходство: **не выводится из ZIP**.

## События GitHub Actions, подтверждённые внешними логами

| Время UTC | Источник | Подтверждённое событие |
|---|---|---|
| 2026-10-29 15:37 UTC | `logs_110876799430.zip` | INITIAL_PAGES_CONFIGURATION_FAILED: Get Pages site failed (HTTP 404): Pages not enabled/configured for GitHub Actions. |
| 2026-10-29 16:46 UTC | `logs_110908968564.zip` | REACT_SOURCE_IMPORT_ATTEMPT: Import step ran and added React source files; log itself is not proof that Pages rendered correctly. |
| 2026-10-29 16:47 UTC | `logs_110909482438.zip` | INITIAL_PAGES_CONFIGURATION_FAILED: Get Pages site failed (HTTP 404). |
| 2026-10-29 17:16 UTC | `logs_110922517973.zip` | JEKYLL_WORKFLOW_RAN: Legacy Jekyll Pages build, not a Next.js/React visual parity verification. |
| 2026-10-29 17:37 UTC | `logs_110931733311.zip` | NEXT_TYPESCRIPT_FAILED: TS2741 Layout.tsx: music_enabled missing in settings object; Next.js 16.4.3 webpack. |
| 2026-10-29 20:40 UTC | `logs_111010438275.zip` | IMPORT_PUSH_REJECTED: GitHub rejected push modifying .github/workflows/efhc-pages.yml without workflows permission. No changes pushed. |
| 2026-10-29 20:53 UTC | `logs_111014981676.zip` | CHROMIUM_SMOKE_FALSE_NEGATIVE: REACT_MOUNT_MISSING. Later source examination found #_next selector vs Next Pages Router #__next; this log alone is a failed smoke test, not proof of runtime failure. |

## Что НЕ восстановлено

- Непредоставленные разговоры и скрытые рабочие записи: недоступны, поэтому не сочинялись.
- Временные отметки создания каждого v867–v874 не подтверждены отдельным источником; версии упорядочены численно, не по несуществующим таймстампам.
- Успех конкретного GitHub Deploy/визуальная приёмка не устанавливается одной лишь успешной сборкой.
- Сведения о реальных действиях аккаунтов, финансовых событиях, секретах не извлекались и не включались.
