#!/usr/bin/env python3
"""Read-only frontend reconstruction intake. Not the full production Kernel."""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from pathlib import Path

FILES=[
 'VERSION','START_HERE.md','AGENTS.md','KERNEL.md','frontend_promt.md',
 'docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md',
 'docs/AI/FRONTEND_READING_ORDER.md',
 'docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md',
 'docs/SSOT/DEMO_FROZEN_VISUAL_SSOT.md',
 'docs/SSOT/DEMO_DATA_SSOT.md',
 'docs/NORM/PAGES_IMPORT_NORM.md',
 'docs/NORM/RECONSTRUCTION_RELEASE_NORM.md',
 'frontend/RECONSTRUCTION_SCHEMA.md',
 'frontend/RECONSTRUCTION_ROUTE_MATRIX.csv',
 'frontend/src/reconstruction/demo-tables-v866.json',
 'frontend/src/reconstruction/verify-demo-tables.test.mjs',
 'frontend/src/pages/_app.tsx',
 'frontend/package.json','frontend/package-lock.json','ci/efhc-pages.yml',
 'reports/RECONSTRUCTION_REPORT_MANIFEST.json',
]
EXPECTED='9b6371f5fb62939596b78206f95031c447e9f2b375e62b30704403bb25102aef'
p=argparse.ArgumentParser()
p.add_argument('--root',default='.')
p.add_argument('--json',action='store_true')
p.add_argument('--frozen-demo',default=None,help='Optional external original FRONTEND_v866.html')
a=p.parse_args()
root=Path(a.root).resolve()
missing=[x for x in FILES if not (root/x).is_file()]
checks={'required_governance_files':not missing}
try:
 v=(root/'VERSION').read_text(encoding='utf-8').strip()
 checks['version_valid']=bool(re.fullmatch(r'FRONTEND_v\d+',v))
except Exception:
 v='MISSING';checks['version_valid']=False
try:
 c=json.loads((root/'frontend/src/reconstruction/demo-tables-v866.json').read_text(encoding='utf-8'))
 checks['frozen_fixture_provenance']=c['source_sha256']==EXPECTED
 checks['demo_table_counts']=(len(c['panels']['active'])==60 and len(c['panels']['archive'])==60 and len(c['ranks']['users'])==220 and len(c['tasks']['catalog'])==5)
except Exception:
 checks['frozen_fixture_provenance']=False;checks['demo_table_counts']=False
try:
 c=json.loads((root/'reports/RECONSTRUCTION_REPORT_MANIFEST.json').read_text(encoding='utf-8'))
 checks['report_manifest_valid']=c['report_count'] == len(c['reports']) and c['next_number']==c['report_count']+1
except Exception:checks['report_manifest_valid']=False
if a.frozen_demo:
 f=Path(a.frozen_demo)
 checks['external_frozen_demo_hash']=f.is_file() and hashlib.sha256(f.read_bytes()).hexdigest()==EXPECTED
status='PASS' if all(checks.values()) else 'FAIL-CLOSED'
result={'status':status,'profile':'EFHC_RECONSTRUCTION_FRONTEND_ONLY','physical_version':v,'checks':checks,'missing':missing,'mutations':0,'next':'STOP until OWNER scope'}
print(json.dumps(result,ensure_ascii=False,indent=2) if a.json else str(result))
sys.exit(0 if status=='PASS' else 1)
