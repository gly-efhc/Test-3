# EFHC React Reconstruction — frontend-only governed source (v869)

## Immutable visual authority
`FRONTEND_v866.html` is held **outside** this import ZIP. Its SHA-256 is
`9b6371f5fb62939596b78206f95031c447e9f2b375e62b30704403bb25102aef`.
Do not modify it or reproduce its HTML as a substitute for production React.
This ZIP preserves source React and introduces the first data-coverage layer.
**Full visual parity is NOT complete.**

## Existing React surfaces and read-only demo tables
- Panels: 60 active + 60 archived; 20-row pages; `PNL-` identifiers and
  generation parameters from standalone v866, `PanelItemResponse` format.
- Ranks: 220 seeded users + the DEMO player; exact deterministic energy
  generator, deliberate tie, dense rank, 100-item first page.
- Tasks: five original v866 seed records and exact template metadata;
  completion and rewards remain disabled without real Global ID.
- The fixtures are used by original React queries/components only when both
  the Pages `NEXT_PUBLIC_EFHC_E2E_TONCONNECT_MOCK=1` build flag and the
  runtime safety flag `window.__EFHC_DEMO_READ_ONLY__=true` are present.
- No fake auth, wallet, ledger or network mutations. The user's canonical
  API routes and business logic remain unchanged.

## Implementation boundary
`src/reconstruction/demo-tables-v866.json` and `demoTables.ts` retain
provenance and transform seed data into the existing React contract.
`useFrozenDemoTables.ts` is a gated adapter; query files have narrowly bounded
read-only selection for data preview. **No visual React rebuild is certified.**

## Next work before any 100% claim
Fix Pages recursive routing and viewport first; prove each real React route.
Replace remaining visual components by comparing frozen DEMO 320/390/desktop,
all CT/theme variants, states, text, DOM geometry and component behavior.
OWNER must visually accept every completed block. Never edit the frozen DEMO.

## React-only reconstruction architecture

    Frozen v866 DEMO (immutable outside importer)
                 |
                 v
    Geometry / colors / content / interaction evidence
                 |
                 v
    React presentation reconstruction by route and component
                 |
                 v
    Protected domain contracts: query hooks / services / types
                 |
                 v
    Browser read-only Pages fixtures (only if explicitly activated)

The original `frontend/src/pages`, `features`, and `components` are retained
as a **temporary compatibility baseline** in this current archive. They are NOT
accepted as the final appearance. Delete obsolete visual implementation only
after verifying each equivalent feature/state in the frozen DEMO. This avoids
accidentally removing contracts while replacing visual structure.

## Route reconstruction coverage
The complete read-only mapping lives at `frontend/RECONSTRUCTION_ROUTE_MATRIX.csv`.
It has 43 React routes; 23 have a direct DEMO route identity and 20 need
nested-section identification. The route matrix tracks `NOT_VERIFIED` rather
than claiming visual similarity. Admin display is protected and its real
permissions cannot be activated by a public demo. Browser Shop operations
remain mock/read-only, never connected to payment execution.

## Prioritized implementation sequence
1. Fix repeated Next basePath routing and prove stable navigation and splash.
2. Compare home/header/background/logo/progress with the 390×844 DEMO; then 320.
3. Rebuild Panels, Portfolio, Ranks and Tasks using the original dataset and
   real React component contracts, with screenshot/DOM/geometry evidence.
4. Reconstruct other user routes in the 43-route matrix; inspect nested DEMO.
5. Independently audit 10 CT × active design configurations and media widths.
6. Eliminate demonstrably unused React visual elements/aliases with exact
   browser regression for affected states. Preserve all non-visual services.
7. Obtain OWNER visual acceptance, then certify routes/state combinations.

## Validation statuses for this import
- Exact frozen source SHA: PASS.
- Extracted task seed: PASS (the five original records and template objects).
- Generated panel/rank seed formulas: PASS local invariant tests.
- Read-only hooks routed to original React components: implemented.
- Import compatibility with unchanged Test-3 importer: PASS local.
- TypeScript syntax parse: PASS; full TS typecheck / Next build: UNVERIFIED.
- Published mobile E2E and visual parity: UNVERIFIED, not 100%.

## Archive import
Put this SINGLE ZIP into `import/`, leaving `import/README.md` intact.
`efhc-import.yml` updates `site/frontend` from `frontend/src` and
`frontend/public`, then commit. Run `efhc-pages.yml` manually to publish.
The frozen canonical v866 HTML is not inside the ZIP and must remain unchanged.

## v868 Pages self-updating import rule
- The archive carries exactly one authorized deployment workflow in `ci/efhc-pages.yml`.
- The bootstrap importer (one-time installation) stages React into `site/frontend/` and
  copies `ci/efhc-pages.yml` to `.github/workflows/efhc-pages.yml` in the **same commit**.
- Subsequent source ZIPs always update both React and Pages workflow automatically;
  a separate manual YAML upload is not part of the normal process.
- The importer never writes any other workflow or copies backend, env, docs, reports.
- Immutable visual authority remains the external `FRONTEND_v866.html`.
- Next.js Pages Preview bypasses production native App Back guard *only* with
  `NEXT_PUBLIC_EFHC_PAGES_PREVIEW=1` at compile time; the private runtime is unchanged.
- Browser smoke checks are required in the Pages workflow before publication.
- New actions use native Node.js 24 runtime; this does not prove a successful CI run.

## v869 portable project governance (new)
- OWNER interaction laws copied in structure from the full v866 archive: `START_HERE.md`, `AGENTS.md`, `KERNEL.md`, `frontend_promt.md`, `docs/AI`, `docs/SSOT`, `docs/NORM`, roadmap and immutable numbered reports.
- These are **adapted** to frontend-only scope, not the old production Kernel or backend.
- Original v866 DEMO is external immutable visual canon; never import its HTML into runtime.
- `docs/**`, `ops/**` are shipped in this physical ZIP; current importer intentionally excludes them from the GitHub runtime checkout. Recopy them into every subsequent working ZIP.
- No claim of Next build, Pages stability, or 100% visual parity in this governance-only iteration.
