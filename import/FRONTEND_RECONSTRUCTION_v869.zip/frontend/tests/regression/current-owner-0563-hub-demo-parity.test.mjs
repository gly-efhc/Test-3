import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
const root=resolve(import.meta.dirname,'../../..');
const read=(p)=>readFileSync(resolve(root,p),'utf8');
const react=read('frontend/src/features/hub/HubPage.tsx');
const app=read('frontend/src/pages/_app.tsx');
const css=read('frontend/src/styles/hub-demo-react-parity.css').trimEnd();
const htmlFiles=readdirSync(root).filter(f=>/^FRONTEND_v\d+\.html$/.test(f));
assert.equal(htmlFiles.length,1,'unique current standalone');
const html=read(htmlFiles[0]);

test('HUB styling uses one canonical file in React and standalone byte-exactly',()=>{
  assert.match(app,/import "\.\.\/styles\/hub-demo-react-parity\.css"/);
  const marker='<style id="hub-demo-react-parity">\n'+css+'\n</style>';
  assert.equal(html.split('<style id="hub-demo-react-parity">').length,2);
  assert.ok(html.includes(marker),'standalone CSS must be generated, never patched independently');
});

test('DEMO-approved HUB is compact, two-column even under 350px',()=>{
  assert.match(css,/min-height:50px!important/);
  assert.match(css,/height:50px!important/);
  assert.match(css,/max-height:50px!important/);
  assert.match(css,/box-sizing:border-box!important/);
  assert.match(css,/grid-template-columns:repeat\(2,minmax\(0,1fr\)\)!important/);
  assert.match(css,/gap:\.52rem!important/);
  assert.match(css,/padding:\.35rem \.62rem!important/);
  assert.match(css,/-webkit-line-clamp:2!important/);
  assert.match(css,/overflow:hidden!important/);
  assert.match(css,/border-radius:\.85rem!important/);
  assert.match(css,/text-align:left!important/);
  assert.match(css,/font-size:\.67rem!important/);
  assert.match(css,/--efhc-ct-accent-rgb/);
  assert.ok(!css.includes('profile-language'),'approved language carousel must be untouched');
});

test('React HUB removes unapproved large icons, retains 4 fixed link names and behavior',()=>{
  assert.doesNotMatch(react,/efhc-hub-choice_icon|<VipCollectionIcon|<GenericHubIcon|<EfhcCoinIcon/);
  assert.match(react,/className="efhc-hub-choice"/);
  assert.match(react,/const fixed = \["efhc_buy", "vip_getgems", "efhc_ceo", "efhc_admin"\]/);
  assert.match(react,/link\.is_active/);
  assert.match(react,/shopLauncher\.mutateAsync\(\)/);
  assert.match(react,/openTelegramLink\(link\.url\)/);
  assert.match(html,/class="release-route-card" data-hub-dynamic-link-v251=/);
});

test('Shared HUB scope is limited to USER HU-01, not Admin, Profile or other variants',()=>{
  assert.match(css,/\.efhc-hub-page\[data-hu="HU-01"\]/);
  assert.match(css,/#hubPage\[data-hu="HU-01"\]/);
  assert.doesNotMatch(css,/adminPage|profilePage|CompactLanguagePicker|data-hu="HU-02"/);
});
