import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '../../..');
const read = name => readFileSync(resolve(root, name), 'utf8');
const registry = read('frontend/src/lib/interfaceVariantRegistry.ts');
const css = read('frontend/src/styles/owner-0550-faq-withdraw-ct.css');
const app = read('frontend/src/pages/_app.tsx');
const withdraw = read('frontend/src/pages/withdraw.tsx');
const version = read('VERSION').trim();
const html = read(`${version}.html`);

const runtimeIds = { faq: 'FQ-13', withdraw: 'WD-13' };

test('0550 requires resolved style IDs rather than logical selection IDs', () => {
  assert.match(registry, /"FQ-06":"FQ-13"/);
  assert.match(registry, /"WD-05":"WD-13"/);
  assert.ok(css.includes(`data-fq="${runtimeIds.faq}"`));
  assert.ok(css.includes(`data-wd="${runtimeIds.withdraw}"`));
  assert.doesNotMatch(css, /data-fq="FQ-06"|data-wd="WD-05"/);
});

test('0550 CSS loaded in React and byte-identically embedded in standalone', () => {
  assert.match(app, /import "\.\.\/styles\/owner-0550-faq-withdraw-ct\.css";/);
  const anchor = '<style id="owner-0550-faq-withdraw-ct">\n';
  assert.equal(html.split(anchor).length, 2);
  assert.ok(html.includes(anchor + css + '</style>'));
  assert.match(html, /<\/body>\s*<\/html>\s*$/);
});

test('0550 FAQ physical FQ-13 covers question, subsection, section, search and answer borders', () => {
  for (const token of [
    '.efhc-faq-section-node', '.efhc-faq-subsection-node', '.efhc-faq-question-node',
    '.release-faq-item', '.release-faq-subsection', '.release-faq-question',
    '.efhc-faq-search-zone', '.standalone-faq-index-row', '.efhc-faq-answer-block',
  ]) assert.ok(css.includes(token), token);
  assert.match(css, /--fq-edge:rgba\(var\(--efhc-ct-accent-rgb\),\.32\)/);
  assert.match(css, /border-color:var\(--fq-edge\)!important/);
});

test('0550 Withdraw WD-13 preserves semantic money/status while CT owns decorative surfaces', () => {
  for (const token of [
    '.efhc-withdraw-summary-row', '.standalone-withdraw-summary-row',
    '.efhc-history-filter--active', '.efhc-history-filter',
    '.efhc-withdraw-hero', '.standalone-withdraw-hero',
  ]) assert.ok(css.includes(token), token);
  assert.match(css, /--efhc-theme-edge:rgba\(var\(--efhc-ct-accent-rgb\),\.29\)/);
  assert.doesNotMatch(css, /efhc-financial-number|withdrawStatusLabel|amount_invalid_range|status_pending/);
  assert.doesNotMatch(css, /\.efhc-admin|\[data-interface-app-mode="admin"\]/);
});

test('0550 removes Withdraw arrow and corner flare without affecting other hero icons', () => {
  assert.doesNotMatch(withdraw, /icon="↓"/);
  assert.doesNotMatch(html, /standalone-withdraw-hero[^\n]*<div class="source-hero-icon">↓<\/div>/);
  assert.match(css, /\.efhc-withdraw-shell \.efhc-withdraw-hero \.efhc-game-hero_glow/);
  assert.match(css, /background-image:none!important/);
  assert.match(css, /content:none!important/);
  assert.match(html, /<div class="source-hero-icon">文<\/div>/); // Other page icon remains.
});

test('0550 shared USER navigation inherits CT without BN redesign', () => {
  assert.match(css, /\.efhc-game-nav_grid/);
  assert.match(css, /\.efhc-game-nav_item\[data-active="true"\]/);
  assert.match(css, /border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.30\)!important/);
  assert.doesNotMatch(css, /border-radius:|min-height:|grid-template-columns:|box-shadow:/);
});
