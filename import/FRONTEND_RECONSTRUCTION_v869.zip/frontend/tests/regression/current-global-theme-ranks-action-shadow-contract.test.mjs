import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const css = fs.readFileSync(new URL("../../src/styles/global-theme-ranks-action-shadow-contract.css", import.meta.url), "utf8");
const contract = JSON.parse(fs.readFileSync(new URL("../../src/design-system/global-theme-ranks-action-shadow-contract.json", import.meta.url), "utf8"));
const app = fs.readFileSync(new URL("../../src/pages/_app.tsx", import.meta.url), "utf8");
const version = fs.readFileSync(new URL("../../../VERSION", import.meta.url), "utf8").trim();
const html = fs.readFileSync(new URL(`../../../${version}.html`, import.meta.url), "utf8");

test("Ranks action shadow contract uses Theme04 computed shadow as the single reference", () => {
  assert.equal(contract.reference.themeId, "04");
  assert.equal(contract.reference.computedBoxShadow, "none");
  assert.equal(contract.token, "--efhc-ranks-action-shadow");
  assert.equal(contract.value, "none");
  assert.deepEqual(contract.scope.themes, ["01","02","03","04","05","06","07","08","09","10","11","12","13"]);
});

test("Refresh and Find Me share one cross-theme shadow owner in production and standalone", () => {
  assert.match(css, /--efhc-ranks-action-shadow:none/);
  for (const selector of [".efhc-btn-secondary", ".efhc-ranks-find-me", ".source-button.secondary", "#rankRefresh", "#findMyRank"]) assert.ok(css.includes(selector), selector);
  assert.match(css, /box-shadow:var\(--efhc-ranks-action-shadow\) !important/);
});

test("The cross-theme contract changes only shadow ownership, not theme colour material", () => {
  assert.doesNotMatch(css, /background(?:-color)?\s*:/);
  assert.doesNotMatch(css, /border(?:-color)?\s*:/);
  assert.doesNotMatch(css, /color\s*:/);
});


test("the global shadow contract stays in React and standalone with no special CT03 perimeter", () => {
  assert.match(app, /global-theme-ranks-action-shadow-contract\.css/);
  assert.doesNotMatch(app, /theme03-protection-perimeter\.css/);
  assert.ok(html.includes("OWNER Global Theme Ranks action shadow contract"));
  assert.ok(html.includes("--efhc-ranks-action-shadow:none"));
  assert.ok(!html.includes('id="theme03ProtectionPerimeter"'));
});
