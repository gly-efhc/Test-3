import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '../../..');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');
const source = read('frontend/src/lib/interfaceVariantRegistry.ts');
const composition = read('frontend/src/lib/headerThemeComposition.ts');
const css = read('frontend/src/styles/global-theme-owner-0544.css');
const htmlFiles = fs.readdirSync(root).filter((name) => /^FRONTEND_v\d+\.html$/.test(name));
assert.equal(htmlFiles.length, 1, 'exactly one root FRONTEND release HTML');
const standalone = read(htmlFiles[0]);
const kept = ['HS-03','HS-06','HS-07','HS-10','HS-11','HS-13'];
const removed = ['HS-01','HS-02','HS-04','HS-05','HS-08','HS-09','HS-12'];

test('Header catalog is six physically numbered templates, default HS-03', () => {
  assert.match(source,/HS: numbered\("HS", 6\)/);
  assert.match(source,/"HS-01":"HS-03"/);
  assert.match(source, /HS:\s*"HS-01"/);
  assert.match(composition, /DEFAULT_HEADER_THEME_COMPOSITION[\s\S]*?shell: "HS-03"/);
  assert.match(standalone, /data-header-theme-catalog="HS-01,HS-02,HS-03,HS-04,HS-05,HS-06"/);
  for (const id of kept) assert.match(composition, new RegExp(`"${id}":`));
  for (const id of removed) assert.doesNotMatch(composition, new RegExp(`"${id}":`));
});

test('Referrals hero arrow is removed from only the main route in both renderers', () => {
  assert.doesNotMatch(read('frontend/src/pages/referrals.tsx'), /icon="↗"/);
  assert.match(standalone, /id="referralsPage"/);
  assert.doesNotMatch(standalone, /<div class="source-hero-icon">↗<\/div>/);
  assert.match(standalone, /id="referralsMyPage"/);
});

test('FQ02/03/04 have a shared CT border contract and independent geometric variants', () => {
  for (const id of ['FQ-02','FQ-03','FQ-04']) {
    assert.match(css, new RegExp(`data-fq="${id}"`));
    assert.match(standalone, new RegExp(`data-fq="${id}"`));
  }
  assert.match(css, /border-color:var\(--fq-edge\)!important/);
  assert.match(css, /--efhc-ct-accent-rgb/);
  assert.match(standalone, /#faqPage:data-never-match|#faqPage:is\(/);
  assert.match(css, /efhc-faq-question-node/);
});

test('Decorative hero glow is isolated from finance, status and Admin owners', () => {
  assert.match(css, /\.efhc-game-hero_glow\{display:none!important\}/);
  assert.match(css, /\.efhc-tasks-shell\[data-tg="TG-03"\]/);
  assert.doesNotMatch(css.slice(css.lastIndexOf('OWNER 0545:')), /\.efhc-admin|\.efhc-task-card button/);
});
