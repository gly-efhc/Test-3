import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../..");
const read = (name) => fs.readFileSync(path.join(root, name), "utf8");
const html = read(`${read("VERSION").trim()}.html`);
const editor = read("frontend/src/components/profile/AvatarPreferenceEditor.tsx");
const ph = read("frontend/src/styles/panels-ph12-chroma-contract.css");
const app = read("frontend/src/pages/_app.tsx");
const locales = ["da", "de", "en", "es", "fr", "hi", "id", "it", "ja", "ko", "pl", "pt", "ru", "sw", "tr", "uk"];

test("One EI picker chooses both primary profile icon and image fallback", () => {
  assert.match(editor, /function chooseIcon\(icon: AvatarIcon\)/);
  assert.match(editor, /selection: \{ kind: "icon" \}, fallbackIcon: icon/);
  assert.equal((editor.match(/efhc-profile-avatar-preset-grid/g) || []).length, 1);
  assert.doesNotMatch(editor, /chooseIcon\(icon, true\)|avatar_fallback.*<\/div>/);
  assert.match(html, /id="standaloneAvatarPresets"/);
  assert.doesNotMatch(html, /id="standaloneAvatarFallbackPresets"|data-avatar-fallback=/);
  assert.match(html, /standaloneAvatar\.fallbackIcon=standaloneAvatar\.energyVariant/);
  assert.match(html, /standaloneAvatar\.source='energy';standaloneAvatar\.energyVariant=energyAvatar\.dataset\.avatarEnergy;standaloneAvatar\.fallbackIcon=standaloneAvatar\.energyVariant/);
});

test("Settings removes decorative heading fill and redundant technical copy, not input/actions", () => {
  assert.match(html, /#profileSettingsOverlay \.standalone-settings-dialog > \.source-row:first-child\{\s*background-color:transparent!important;background-image:none!important/);
  assert.doesNotMatch(html, /id="standaloneAvatarLocalNote"|Загрузка файлов отключена\.<\/div>/);
  assert.match(html, /id="standaloneAvatarCheckUrl"/);
  assert.match(html, /id="standaloneAvatarSaveUrl"/);
  assert.match(html, /id="standaloneAvatarClearUrl"/);
});

test("PH-12 is the last active Panels hero, chroma is CT owned and geometry remains authored", () => {
  const registry = read("frontend/src/lib/interfaceVariantRegistry.ts");
  assert.match(registry, /PH: numbered\("PH", 6\)/);
  assert.match(app, /panels-ph12-chroma-contract\.css/);
  assert.match(ph, /--efhc-ct-accent-rgb/);
  assert.match(ph, /data-ph="PH-12"/);
  assert.match(ph, /\[data-color-theme-id\]/);
  assert.doesNotMatch(ph, /border-radius\s*:|grid-template|padding\s*:|font-size\s*:/);
  assert.match(html, /id="efhc-owner-0542-visual-owner"/);
  assert.match(html, /rgba\(var\(--efhc-ct-accent-rgb\),\.18\)/);
});

test("Admin is not selected and CT03 is included in the ten-theme PH-12 color owner", () => {
  assert.match(ph, /data-interface-app-mode="user"/);
  assert.match(ph, /data-color-theme-id\]/);
  assert.doesNotMatch(ph, /data-interface-app-mode="admin"/);
  assert.doesNotMatch(ph, /data-global-theme-id="03"/);
});

test("All 16 locales present a single human-facing avatar icon selector", () => {
  for (const lang of locales) {
    const dict = JSON.parse(read(`frontend/public/locale/${lang}.json`));
    assert.ok(dict["profile.avatar_energy_presets"], `${lang} icon label`);
    assert.ok(dict["profile.avatar_source_note"], `${lang} short instruction`);
    assert.doesNotMatch(dict["profile.avatar_source_note"], /загрузка файлов отключена|file uploads are disabled/i);
  }
});
