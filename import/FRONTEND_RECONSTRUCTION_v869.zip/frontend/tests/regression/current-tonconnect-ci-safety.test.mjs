import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";

const repoRoot = path.resolve(import.meta.dirname, "../../..");
const read = (relativePath) => fs.readFileSync(path.join(repoRoot, relativePath), "utf8");
const exists = (relativePath) => fs.existsSync(path.join(repoRoot, relativePath));
const workflow = read(".github/workflows/tonconnect-sdk-auto-update.yml");
const packageJson = JSON.parse(read("frontend/package.json"));

function order(...needles) {
  const positions = needles.map((needle) => workflow.indexOf(needle));
  for (const [index, position] of positions.entries()) {
    assert.ok(position >= 0, `missing workflow token: ${needles[index]}`);
  }
  for (let index = 1; index < positions.length; index += 1) {
    assert.ok(
      positions[index - 1] < positions[index],
      `${needles[index - 1]} must precede ${needles[index]}`,
    );
  }
}

test("Current installs its auto-update workflow in canonical GitHub Actions path", () => {
  assert.equal(exists(".github/workflows/tonconnect-sdk-auto-update.yml"), true);
  assert.match(workflow, /name:\s*tonconnect-sdk-auto-update/);
});

test("Current auto-update workflow has daily plus manual trigger and serialized execution", () => {
  assert.match(workflow, /schedule:/);
  assert.match(workflow, /cron:\s*"17 4 \* \* \*"/);
  assert.match(workflow, /workflow_dispatch:/);
  assert.match(workflow, /group:\s*tonconnect-sdk-auto-update/);
  assert.match(workflow, /cancel-in-progress:\s*false/);
});

test("Current update acceptance is isolated and install scripts are disabled", () => {
  assert.match(workflow, /Prepare isolated exact-pin candidate/);
  assert.match(workflow, /Build isolated acceptance worktree/);
  assert.match(workflow, /--ignore-scripts/);
  assert.match(workflow, /npm ci/);
  assert.match(workflow, /https:\/\/config\.ton\.org\/wallets-v2\.json/);
  assert.doesNotMatch(workflow, /@latest/);
});

test("Current uses a bounded current TON Connect acceptance suite", () => {
  assert.equal(
    packageJson.scripts["check:tonconnect-update-acceptance"],
    "npm run test:tonconnect-update-acceptance",
  );
  const suite = packageJson.scripts["test:tonconnect-update-acceptance"];
  for (const guard of [
    "current-tonconnect-wallet-source.test.mjs",
    "current-tonconnect-sdk-engine.test.mjs",
    "current-tonconnect-ci-safety.test.mjs",
    "current-tonconnect-least-privilege.test.mjs",
  ]) {
    assert.match(suite, new RegExp(guard.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
  }
  assert.match(workflow, /npm run check:tonconnect-update-acceptance/);
  assert.doesNotMatch(workflow, /npm run check:frontend-regression/);
});

test("Current requires acceptance type build and candidate-bound evidence before promotion", () => {
  order(
    "Run update-engine unit regressions",
    "Run current TON Connect acceptance guards",
    "Run TypeScript acceptance",
    "Verify checked-in release assets",
    "Run production build acceptance",
    "Bind PASS evidence to exact candidate hashes",
    "Promote accepted candidate in read-only runner checkout",
  );
  assert.match(workflow, /"candidate": state\["candidate"\]/);
  assert.match(workflow, /"tonconnect_acceptance": "PASS"/);
  assert.match(workflow, /--guard-evidence/);
  assert.doesNotMatch(workflow, /continue-on-error:/);
});

test("Current permits only package promotion and never auto-merges default branch", () => {
  order(
    "Promote accepted candidate in read-only runner checkout",
    "Enforce package-only promotion delta",
    "Create or refresh review-only update PR",
  );
  assert.match(workflow, /test "\$\{#changed\[@\]\}" -eq 2/);
  assert.match(workflow, /frontend\/package-lock\.json/);
  assert.match(workflow, /frontend\/package\.json/);
  assert.match(workflow, /gh pr create/);
  assert.doesNotMatch(workflow, /gh pr merge/);
  assert.doesNotMatch(workflow, /git push[^\n]*HEAD:\$BASE_BRANCH/);
});
