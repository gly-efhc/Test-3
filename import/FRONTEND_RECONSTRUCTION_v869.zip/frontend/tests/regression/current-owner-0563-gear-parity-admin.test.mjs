import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'../../..');
const read=(f)=>fs.readFileSync(path.join(root,f),'utf8');
const provider=read('frontend/src/components/interface-settings/InterfaceCustomizationProvider.tsx');
const html=read('FRONTEND_v866.html');
const css=read('frontend/src/styles/referrals-social-brand-contract.css');
test('OWNER 0563: settings GEAR alone hides after 3 seconds in both React and DEMO',()=>{
  assert.match(provider,/hideTimerRef\.current = window\.setTimeout\([\s\S]*?setButtonVisible\(false\);[\s\S]*?\}, 3_000\);/);
  assert.match(html,/customizeHideTimer=setTimeout\(\(\)=>setCustomizeButtonVisible\(false\),3000\);/);
  assert.doesNotMatch(html,/customizeHideTimer=setTimeout\(\(\)=>setCustomizeButtonVisible\(false\),5000\);/);
  assert.match(html,/const start=performance\.now\(\);const duration=5000;/); // splash stays 5s
  assert.match(html,/efhc:demo-splash-dismissed/); // gear appears after splash
});
test('OWNER 0563: no CT10 selector behavior or active theme catalog mutates',()=>{
  assert.match(html,/html\[data-customization-mode="editing"\] \.interface-customization-button/);
  assert.match(html,/\.global-theme-control\[hidden\]\{display:none!important\}/);
  assert.match(read('frontend/src/components/Layout.tsx'),/\{!isAdminRoute \? <GlobalThemeControl \/> : null\}/);
});
test('OWNER 0563: Admin distinct theme canon and low-risk obsolete HUB cleanup',()=>{
  assert.match(read('frontend/src/styles/admin-theme03-canon.css'),/--efhc-admin-canon-accent/);
  assert.ok(fs.existsSync(path.join(root,'frontend/src/design-system/admin-theme03-canon.json')));
  for(let i=2;i<=9;i++) assert.doesNotMatch(css,new RegExp('\\.efhc-hub-page\\[data-hu="HU-'+String(i).padStart(2,'0')+'"\\]'));
  assert.match(read('frontend/src/styles/hub-demo-react-parity.css'),/height:50px!important/);
});
test('OWNER 0563: 96 active mappings and route gaps remain tracked, not falsely erased',()=>{
 const catalog=read('frontend/src/lib/interfaceVariantRegistry.ts');
 assert.match(catalog,/"RP":\{"RP-01":"PB-01"/);
 const audit=read('docs/frontend/FRONTEND_REACT_DEMO_PARITY_CYCLE0563.md');
 assert.match(audit,/\*\*96\*\*/);
 assert.match(audit,/React routes: \*\*43\*\*/);
 assert.match(audit,/route-ID matches: \*\*23\*\*/);
});
