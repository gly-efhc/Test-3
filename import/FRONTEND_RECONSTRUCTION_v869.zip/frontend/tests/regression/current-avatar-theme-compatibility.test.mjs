// Current contract recovery — OWNER Cycle0467. Restores independently useful
// active cases from former one-cycle suites as one maintained regression suite.
// Superseded expectations are identified by full regression, never silently passed.
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

// Recovered coverage from current-cycle0452-energy-progress-theme-contract.test.mjs
{





const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../../..");
const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");
const json = (rel) => JSON.parse(read(rel));

const contract = json("frontend/src/design-system/global-theme-energy-progress-contract.json");
const colorCanon = json("frontend/src/design-system/global-theme-color-canon.json");
const css = read("frontend/src/styles/global-theme-energy-progress-contract.css");
const provider = read("frontend/src/components/interface-settings/InterfaceCustomizationProvider.tsx");
const globalRegistry = read("frontend/src/lib/globalThemeRegistry.ts");
const colorRegistry = read("frontend/src/lib/colorThemeRegistry.ts");
const variantRegistry = read("frontend/src/lib/interfaceVariantRegistry.ts");
const theme01 = read("frontend/src/styles/theme01-bounded-chroma-corrections.css");
const theme02 = read("frontend/src/styles/theme02-bounded-chroma-corrections.css");
const dots = read("frontend/src/components/interface-settings/InterfaceVariantDotsLayer.tsx");
const compact = read("frontend/src/components/profile/CompactThemeCarousel.tsx");
const energy = read("frontend/src/pages/index.tsx");
const globals = read("frontend/src/styles/globals.css");
const app = read("frontend/src/pages/_app.tsx");
const version = read("VERSION").trim();
const standalone = read(`${version}.html`);

const expectedMap = Object.freeze({
  "01":"PB-01", "02":"PB-28", "03":"PB-22", "04":"PB-23",
  "05":"PB-24", "06":"PB-25", "07":"PB-29", "08":"PB-30",
  "09":"PB-26", "10":"PB-27", "11":"PB-32", "12":"PB-33",
});

const expectedAccent = Object.freeze({
  "01":"#6EA8FF", "02":"#73AEFC", "03":"#A78BFA", "04":"#229ED9",
  "05":"#E5BF58", "06":"#94A3B8", "07":"#7FB4FF", "08":"#8F86FF",
  "09":"#58C7B4", "10":"#94A3B8", "11":"#A78BFA", "12":"#A78BFA",
  "13":"#C5A15A",
});

test("Cycle0452 library/boundary survives Cycle0455 COLOR != DESIGN supersession", () => {
  assert.equal(contract.schema, "EFHC_COLOR_THEME_ENERGY_REFERRALS_PROGRESS_CONTRACT_V5");
  assert.match(contract.ownership_model, /TARGET_COLOR_THEME_OWNS_CHROMA__CURRENT_RECOVERY_PRESERVES_AUTHORED_V684_VISUALS/);
  assert.match(contract.progress_library.fill_boundary, /strictly inside/i);
  assert.equal(contract.progress_library.energy_PB_slots, 33);
  assert.equal(contract.progress_library.referrals_RP_slots, 33);
  assert.equal(contract.common_initial_baseline.EI, "EI-07");
  assert.equal(contract.common_initial_baseline.PB, "PB-01");
  assert.equal(contract.common_initial_baseline.RP, "PB-01");
});

test("Active Global01..12 retain distinct PB provenance; CT10 uses PB29 and legacy13 is retired", () => {
  assert.equal(new Set(Object.values(expectedMap)).size, 12);
  for (const [id, pb] of Object.entries(expectedMap)) {
    assert.match(globalRegistry, new RegExp(`"${id}"\\s*:\\s*"${pb}"`));
  }
  assert.match(colorRegistry, /"CT-10":\s*"PB-27"/);
  assert.doesNotMatch(globalRegistry, /"13":\s*"PB-29"/);
  assert.doesNotMatch(provider, /EI:\s*"EI-01"/);
  assert.doesNotMatch(provider, /PB:\s*getGlobalThemeEnergyProgressBase\(theme\.id\)/);
  assert.match(provider, /color_theme_id:\s*nextColorThemeId/);
  // Superseded by direct OWNER Cycle0464/08: PB/RP reset on an actual CT switch;
  // every unrelated independent design variant still persists as before.
  assert.match(provider, /interface_variants:\s*nextVariants/);
  assert.match(provider, /COLOR_THEME_PROGRESS_STARTER\[nextColorThemeId\]/);
  assert.doesNotMatch(globalRegistry, /GLOBAL_THEME_GROUPS[\s\S]{0,250}["'](?:PB|EI)["']/);
});

test("Cycle0452 PB library remains addressable while Cycle0455 expands Referrals RP to PB-01..PB-35", () => {
  assert.match(variantRegistry, /PB:\s*numbered\("PB",\s*33\)/);
  assert.match(variantRegistry, /RP:\s*numbered\("RP",\s*33\)/);
  for (let n = 2; n <= 23; n += 1) {
    if ([8,17].includes(n)) continue;
    const id = String(n).padStart(2, "0");
    assert.match(globals, new RegExp(`data-pb="PB-${id}"`), `missing authored/physical PB-${id}`);
  }
  const physicalStyles = Object.fromEntries(Array.from({length:35},(_,i)=>i+1).filter(n=>![8,17].includes(n)).map((old,i)=>[`PB-${String(i+1).padStart(2,'0')}`,`PB-${String(old).padStart(2,'0')}`]));
  for (const pb of Object.values(expectedMap)) {
    const physical=physicalStyles[pb];
    assert.match(globals+css, new RegExp(`data-pb="${physical}"`), `missing rendered physical style ${physical} for ${pb}`);
  }
});

test("Cycle0452 strict frame boundary survives Cycle0455 visual recovery without reintroducing the rejected broad repaint", () => {
  assert.match(css, /efhc-energy-progress-track\[data-pb\][\s\S]{0,180}overflow:hidden !important/);
  assert.match(css, /efhc-energy-progress-fill[\s\S]{0,180}max-width:100% !important/);
  // The v684 authored Energy baseline is intentionally restored while the failed
  // Cycle0455 broad COLOR layer is quarantined. Legacy starting-PB chroma/provenance
  // may remain here until a later narrow rendered-qualified decoupling step.
  assert.doesNotMatch(app, /color-theme-shared-contract\.css/);
  assert.doesNotMatch(css, /--tg-bg\s*:/);
  assert.doesNotMatch(css, /data-hs=|data-eg=|data-bn=|data-xh=|data-hi=/);
  assert.doesNotMatch(theme01, /data-global-theme-id="01"[^\n{]*[\s\S]{0,180}\.efhc-energy-progress-fill\s*\{/);
  assert.doesNotMatch(theme02, /data-global-theme-id="02"[^\n{]*[\s\S]{0,180}\.efhc-energy-progress-fill\s*\{/);
});

test("Theme09 owner correction restores Modular Teal #58C7B4", () => {
  const t09 = colorCanon.themes.find((row) => row.id === "09");
  assert.equal(t09.accent, "#58C7B4");
  assert.equal(t09.accentRgb, "88,199,180");
  assert.match(t09.note, /Emerald Green #22C55E rejected/i);
  assert.match(contract.theme09, /#58C7B4/);
});

test("EI-07 remains the initial Energy icon ID while manual EI stays independent of color changes", () => {
  assert.equal(contract.energy_icon.initial, "EI-07");
  assert.match(provider, /const selectIndividualVariant = useCallback/);
  assert.match(provider, /\[group\]: normalizedValue/);
  assert.doesNotMatch(globalRegistry, /GLOBAL_THEME_GROUPS[\s\S]{0,250}["']EI["']/);
});


test("Standalone carries shared 35/35 PB/RP libraries, legacy provenance, no color-change reset and strict clipping", () => {
  const cssImport = app.indexOf('global-theme-energy-progress-contract.css');
  const adminImport = app.indexOf('admin-theme03-canon.css');
  assert.ok(cssImport > 0 && adminImport > cssImport);
  assert.match(standalone, /id="globalThemeEnergyProgressContract"/);
  assert.match(standalone, /"PB":\["PB-01"[\s\S]*?"PB-33"\],"RP":\["RP-01"[\s\S]*?"RP-33"\]/);
  for (const [id, pb] of Object.entries(expectedMap)) {
    assert.match(standalone, new RegExp(`"${id}"\\s*:\\s*"${pb}"`));
  }
  assert.doesNotMatch(standalone, /draft\.EI='EI-07';draft\.PB=basePb/);
  assert.doesNotMatch(standalone, /savedVariants\.EI='EI-07';savedVariants\.PB=basePb/);
  assert.match(standalone, /EFHC_THEME_STATE_V1/);
  assert.match(standalone, /color_theme_id/);
  assert.match(standalone, /overflow:hidden !important/);
  assert.match(standalone, /data-progress-library="PB-01\.\.PB-33" data-progress-selection-scope="energy-independent"/);
  const match = /const SOURCE_STYLE = Object\.freeze\((\{[^\n]*\})\);/.exec(standalone);
  assert.ok(match, 'standalone must retain explicit physical-style mapping');
  const selected=JSON.parse(match[1]);
  const physical=Array.from({length:35},(_,i)=>i+1).filter(n=>n!==8&&n!==17);
  for (let n=1;n<=33;n++) {
    const slot=`${String(n).padStart(2,'0')}`;
    const old=`PB-${String(physical[n-1]).padStart(2,'0')}`;
    assert.equal(selected.PB[`PB-${slot}`] || `PB-${slot}`,old);
    assert.equal(selected.RP[`RP-${slot}`] || `RP-${slot}`,old);
  }
  assert.match(standalone, /data-progress-library="PB-01\.\.PB-33" data-progress-selection-scope="referrals-independent"/);
});

test("Cycle0464/06 PB01..PB35 keep bounded fill geometry on both USER routes", () => {
  assert.match(css, /:is\(\.efhc-energy-stage,\.efhc-referrals-shell\) \.efhc-energy-progress-track\[data-pb\]\{/);
  assert.match(css, /:is\(\.efhc-energy-stage,\.efhc-referrals-shell\) \.efhc-energy-progress-track\[data-pb\] > \.efhc-energy-progress-fill\{/);
  assert.match(css, /overflow:hidden!important/);
  assert.match(css, /\.efhc-referrals-shell \.efhc-energy-progress-track:is\([\s\S]{0,400}\[data-pb="PB-35"\]\s*\)/);
  assert.match(standalone, /Cycle0464\/06 — PB\/RP selected variants share the same bounded viewport/);
  assert.match(standalone, /height:auto!important;/);
  assert.match(standalone, /max-width:calc\(100% - 4px\)!important/);
  assert.match(standalone, /#referralsPage \.efhc-energy-progress-track:is\([\s\S]{0,400}\[data-pb="PB-35"\]/);
});

}

// Recovered coverage from current-cycle0453-color-design-decoupling-ssot.test.mjs
{




const root = path.resolve(import.meta.dirname, "../../..");
const readJson = (p) => JSON.parse(fs.readFileSync(path.join(root, p), "utf8"));
const readText = (p) => fs.readFileSync(path.join(root, p), "utf8");

const colors = readJson("frontend/src/design-system/color-theme-registry.json");
const designs = readJson("frontend/src/design-system/universal-design-registry.json");
const legacy = readJson("frontend/src/design-system/legacy-global-theme-decoupling-map.json");
const ownership = readJson("frontend/src/design-system/theme-ownership-classification.json");
const ssot = readJson("docs/SSOT/COLOR_DESIGN_DECOUPLING_SSOT.json");
const globalThemeSource = readText("frontend/src/lib/globalThemeRegistry.ts");
const variantSource = readText("frontend/src/lib/interfaceVariantRegistry.ts");

const expectedColors = [
  ["CT-01", "Blue", "#6EA8FF", ["01"]],
  ["CT-02", "Light Blue", "#73AEFC", ["02"]],
  ["CT-03", "Violet", "#A78BFA", ["03", "11", "12"]],
  ["CT-04", "Azure", "#229ED9", ["04"]],
  ["CT-05", "Gold", "#E5BF58", ["05"]],
  ["CT-06", "Fuchsia", "#D946EF", ["06", "10"]],
  ["CT-07", "Sky Blue", "#7FB4FF", ["07"]],
  ["CT-08", "Indigo", "#8F86FF", ["08"]],
  ["CT-09", "Teal", "#58C7B4", ["09"]],
  ["CT-10", "Muted Gold", "#C5A15A", ["13"]],
];

const globalFamilies = [
  "HS", "EG", "BN", "PH", "PT", "PC", "PA", "XH", "XC",
  "TG", "RG", "KG", "WG", "HU", "FQ", "PM", "HI", "WD",
  "AD", "BS", "ER",
];

test("Cycle0453 canonical target has exactly 10 color-only themes", () => {
  assert.equal(colors.color_theme_count, 10);
  assert.equal(colors.themes.length, 10);
  assert.equal(new Set(colors.themes.map((x) => x.accent.toUpperCase())).size, 10);
  assert.deepEqual(
    colors.themes.map((x) => [x.id, x.name, x.accent.toUpperCase(), x.legacy_theme_ids]),
    expectedColors,
  );
  assert.equal(colors.owner_law.color_theme_changes, "CHROMA_ONLY");
  assert.equal(colors.owner_law.selected_designs_survive_color_change, true);
  assert.match(colors.owner_law.new_color_expansion, /entire universal design library/i);
});

test("legacy 13 themes map losslessly to 10 colors and retain 21-design sets", () => {
  assert.equal(legacy.mappings.length, 13);
  assert.deepEqual(legacy.mappings.map((x) => x.legacy_theme_id), [
    "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13",
  ]);
  for (const row of legacy.mappings) {
    assert.equal(row.design_set_size, 21, row.legacy_theme_id);
    assert.deepEqual(Object.keys(row.design_set), globalFamilies, row.legacy_theme_id);
    for (const [group, variant] of Object.entries(row.design_set)) {
      assert.equal(variant, `${group}-${row.legacy_theme_id}`, `${row.legacy_theme_id}/${group}`);
    }
  }
  assert.equal(legacy.mappings.find((x) => x.legacy_theme_id === "03").color_theme_id, "CT-03");
  assert.equal(legacy.mappings.find((x) => x.legacy_theme_id === "11").color_theme_id, "CT-03");
  assert.equal(legacy.mappings.find((x) => x.legacy_theme_id === "12").color_theme_id, "CT-03");
  assert.equal(legacy.mappings.find((x) => x.legacy_theme_id === "06").color_theme_id, "CT-06");
  assert.equal(legacy.mappings.find((x) => x.legacy_theme_id === "10").color_theme_id, "CT-06");
});

test("Theme03 design set is the common default only, not a color binding", () => {
  assert.equal(Object.keys(designs.theme03_common_default_set).length, 21);
  for (const group of globalFamilies) {
    assert.equal(designs.theme03_common_default_set[group], group === "PA" ? "PA-02" : group === "EG" ? "EG-01" : group === "WG" ? "WG-01" : group === "XH" ? "XH-01" : group === "XC" ? "XC-01" : `${group}-03`);
  }
  assert.equal(designs.laws.theme03_common_default_is_default_only, true);
  assert.equal(designs.laws.color_is_not_design_identity, true);
});

test("physical variant census is complete and preserves all current IDs", () => {
  assert.equal(designs.counts.registry_groups_total, 29);
  assert.equal(designs.counts.registry_variant_tokens_total, 236); // OWNER 0562: exact current selection inventory; CSS authored styles remain protected
  assert.equal(designs.counts.protected_admin_variants, 12);
  assert.equal(designs.counts.semantic_variant_tokens_SC, 4);
  assert.equal(designs.counts.design_owned_non_admin_variants, 220);
  assert.equal(designs.counts.legacy_global_theme_design_families, 21);
  assert.equal(designs.counts.legacy_global_theme_hard_bindings, 273);
  assert.equal(designs.counts.design_owned_outside_legacy_global_matrix, 59);
  assert.equal(designs.counts.theme03_common_default_bindings, 21);
  assert.equal(designs.counts.hard_binding_reduction_factor_when_decoupled, 13);

  const groups = new Map(designs.groups.map((g) => [g.group, g]));
  assert.equal(groups.size, 29);
  assert.equal(groups.get("PB").variant_count, 33);
  assert.equal(groups.get("RP").variant_count, 33);
  assert.equal(groups.get("EI").variant_count, 1);
  assert.equal(groups.get("AM").migration_disposition, "EXCLUDED_PROTECTED");
  assert.equal(groups.get("SC").ownership_class, "SEMANTIC");
  for (const g of globalFamilies) {
    assert.equal(groups.get(g).legacy_theme_slots["03"], g === "WG" ? "WG-01" : `${g}-03`, g);
    assert.equal(Object.keys(groups.get(g).legacy_theme_slots).length, 13, g);
  }
});

test("ownership is exhaustively partitioned into COLOR DESIGN SEMANTIC BRAND", () => {
  assert.deepEqual(Object.keys(ownership.classes), ["COLOR", "DESIGN", "SEMANTIC", "BRAND"]);
  assert.equal(ownership.unknown_decorative_owner_count, 0);
  assert.deepEqual(ownership.unclassified_owner_classes, []);
  assert.equal(ownership.hardcoded_theme_chroma_census.declarations_with_literal_color, 2077);
  assert.equal(ownership.hardcoded_theme_chroma_census.unique_literal_tokens, 615);
  assert.ok(ownership.hardcoded_theme_chroma_census.source_files["frontend/src/styles/globals.css"] > 1000);
});


}

// Recovered coverage from current-cycle0454-color-design-state-split.test.mjs
{





const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../../..");
const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");
const json = (rel) => JSON.parse(read(rel));

const colorRegistry = read("frontend/src/lib/colorThemeRegistry.ts");
const settings = read("frontend/src/lib/settings.ts");
const provider = read("frontend/src/components/interface-settings/InterfaceCustomizationProvider.tsx");
const layout = read("frontend/src/components/Layout.tsx");
const shopLayout = read("frontend/src/components/ShopLayout.tsx");
const persistent = json("frontend/src/design-system/color-design-persistent-state-contract.json");
const legacyMap = json("frontend/src/design-system/legacy-global-theme-decoupling-map.json");
const version = read("VERSION").trim();
const standalone = read(`${version}.html`);

const expectedLegacyToColor = Object.freeze({
  "01":"CT-01", "02":"CT-02", "03":"CT-03", "04":"CT-04", "05":"CT-05",
  "06":"CT-06", "07":"CT-07", "08":"CT-08", "09":"CT-09", "10":"CT-06",
  "11":"CT-03", "12":"CT-03", "13":"CT-10",
});

test("Clean startup schema preserves Color Theme / independent Design Theme separation", () => {
  assert.equal(persistent.schema, "EFHC_COLOR_DESIGN_PERSISTENT_STATE_CONTRACT_V1_CLEAN_START");
  assert.equal(persistent.interface_settings_version, 1);
  assert.match(persistent.canonical_state.color_theme_id, /color authority only/i);
  assert.match(persistent.canonical_state.interface_variants, /independent complete design/i);
  assert.match(persistent.color_change_law.must_not_change.join(" "), /interface_variants/i);
  assert.match(persistent.color_change_law.must_not_change.join(" "), /PB form ID/i);
  assert.match(persistent.color_change_law.must_not_change.join(" "), /EI form ID/i);
  assert.equal(persistent.migration.legacy_versions, "not read or imported");
});

test("Color registry contains exactly 10 canonical colors and deterministic 13→10 mapping", () => {
  const ids = [...colorRegistry.matchAll(/\{ id: "(CT-\d{2})", slot:/g)].map((m) => m[1]);
  assert.deepEqual(ids, Array.from({length:10}, (_,i)=>`CT-${String(i+1).padStart(2,"0")}`));
  for (const [legacy, color] of Object.entries(expectedLegacyToColor)) {
    assert.match(colorRegistry, new RegExp(`"${legacy}"\\s*:\\s*"${color}"`));
  }
  assert.match(colorRegistry, /"CT-03":\s*"03"/);
  assert.match(colorRegistry, /"CT-06":\s*"06"/);
  assert.match(colorRegistry, /"CT-10":\s*"10"/);
});

test("Duplicate legacy color families collapse only in color identity, not design provenance", () => {
  assert.equal(expectedLegacyToColor["03"], expectedLegacyToColor["11"]);
  assert.equal(expectedLegacyToColor["03"], expectedLegacyToColor["12"]);
  assert.equal(expectedLegacyToColor["06"], expectedLegacyToColor["10"]);
  const serialized = JSON.stringify(legacyMap);
  for (const id of ["03","06","10","11","12"]) assert.match(serialized, new RegExp(`"${id}"`));
});

test("Settings starts at V1 and preserves complete independent design defaults", () => {
  assert.match(settings, /const KEY = "EFHC_USER_SETTINGS_V1"/);
  assert.match(settings, /const CLOUD_KEY = "ui_settings_v1"/);
  assert.match(settings, /DEFAULT_INTERFACE_VARIANTS/);
  assert.match(settings, /!\[1, 2, 3, 4\]\.includes\(parsed\.interface_settings_version\)/);
  assert.match(settings, /const resetRetiredSelections = parsed\.interface_settings_version === 1/);
  assert.match(settings, /const effectiveVariants = resetRetiredSelections/);
  assert.match(settings, /global_theme_id: globalThemeId/);
  assert.match(settings, /interface_variants: effectiveVariants/);
  assert.doesNotMatch(settings, /migrateSettingsSourceV17|migrateKgChoiceV19|LEGACY_LOCAL_KEYS|LEGACY_CLOUD_KEYS/);
  assert.doesNotMatch(settings, /Object\.assign\(source,/);
});


test("Clean-start settings save only one V1 format locally and in Telegram Cloud", () => {
  assert.match(settings, /window\.localStorage\.setItem\(KEY, JSON\.stringify/);
  assert.match(settings, /telegramCloudStorageSet\(\s*CLOUD_KEY,/);
  assert.doesNotMatch(settings, /ROLLBACK_LOCAL_KEY|ROLLBACK_CLOUD_KEY|rollbackKg\(|LEGACY_KG_TO_NUMBERED/);
  assert.doesNotMatch(settings, /EFHC_USER_SETTINGS_V16|EFHC_USER_SETTINGS_V17|ui_settings_v16|ui_settings_v17/);
  assert.doesNotMatch(standalone, /const rollbackVariants=|const rollbackOverrides=/);
});

test("Standalone V1 persists independent design selections without old storage reads", () => {
  assert.match(standalone, /const STORAGE_KEY = 'EFHC_THEME_STATE_V1'/);
  assert.match(standalone, /!\[2,3,4\]\.includes\(raw\.interface_settings_version\)/);
  assert.match(standalone, /const interface_variants=normalizeVariants\(raw\.interface_variants\)/);
  assert.match(standalone, /savedColorThemeId=saved\.color_theme_id/);
  assert.match(standalone, /savedColorThemeId=colorId/);
  assert.doesNotMatch(standalone, /const LEGACY_KG_TO_NUMBERED =|const rollbackVariants=|EFHC_THEME_STATE_V040/);
  assert.doesNotMatch(standalone, /draft\.EI='EI-07';draft\.PB=|savedVariants\.EI='EI-07';savedVariants\.PB=/);
});


}

// Recovered coverage from current-cycle0459-theme-indicator-colors.test.mjs
{





const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../../..");
const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");

const colors = read("frontend/src/lib/colorThemeRegistry.ts");
const compact = read("frontend/src/components/profile/CompactThemeCarousel.tsx");
const energy = read("frontend/src/pages/index.tsx");
const css = read("frontend/src/styles/globals.css");

const accents = ["#6EA8FF","#73AEFC","#A78BFA","#229ED9","#E5BF58","#D946EF","#7FB4FF","#8F86FF","#58C7B4","#C5A15A"];

test("Cycle0459 every canonical indicator color comes directly from Color Theme registry", () => {
  for (const accent of accents) assert.match(colors, new RegExp(accent.replace("#", "#"), "i"));
  assert.match(compact, /--efhc-indicator-color": theme\.accent/);
  assert.match(energy, /--efhc-indicator-color": theme\.accent/);
});

test("Cycle0459 compact indicators have fixed equal geometry and ten aligned columns", () => {
  const marker = css.indexOf("FRONTEND_ADMIN_CYCLE_0459 — Color Theme indicators");
  assert.ok(marker >= 0);
  const layer = css.slice(marker);
  assert.match(layer, /grid-template-columns:repeat\(10,5px\)/);
  assert.match(layer, /\.efhc-compact-theme-dots>span\{[\s\S]*?width:5px;[\s\S]*?height:5px;/);
  assert.match(layer, /\.efhc-compact-theme-dots>span\[data-active="true"\]\{[\s\S]*?width:5px;[\s\S]*?height:5px;/);
  assert.match(layer, /\.efhc-compact-theme-dots>span\{[\s\S]*?background:#94a3b8;/);
  assert.match(layer, /\.efhc-compact-theme-dots>span\[data-active="true"\]\{[\s\S]*?background:var\(--efhc-indicator-color\);/);
});

test("Cycle0459 Energy Color Theme indicator row has exactly ten equal slots", () => {
  const marker = css.indexOf("FRONTEND_ADMIN_CYCLE_0459 — Color Theme indicators");
  const layer = css.slice(marker);
  assert.match(layer, /\.efhc-energy-frame-theme-slots\{[\s\S]*?grid-template-columns:repeat\(10,minmax\(0,1fr\)\)/);
  assert.match(layer, /\.efhc-energy-frame-theme-slots>span\{[\s\S]*?--efhc-indicator-color/);
});

test("Cycle0459 design-dot active marker is neutral rather than Color Theme swatch", () => {
  const marker = css.indexOf("FRONTEND_ADMIN_CYCLE_0459 — Color Theme indicators");
  const layer = css.slice(marker);
  assert.match(layer, /\.efhc-interface-variant-dots span\[data-active="true"\]\{\s*background:#f8fafc;/);
});

}

// Recovered coverage from current-cycle0459-visible-10-color-selector.test.mjs
{





const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../../..");
const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");
const json = (rel) => JSON.parse(read(rel));

const colors = read("frontend/src/lib/colorThemeRegistry.ts");
const provider = read("frontend/src/components/interface-settings/InterfaceCustomizationProvider.tsx");
const settings = read("frontend/src/lib/settings.ts");
const compact = read("frontend/src/components/profile/CompactThemeCarousel.tsx");
const dots = read("frontend/src/components/interface-settings/InterfaceVariantDotsLayer.tsx");
const energy = read("frontend/src/pages/index.tsx");
const registry = json("frontend/src/design-system/color-theme-registry.json");

const expected = [
  ["CT-01", "#6EA8FF"], ["CT-02", "#73AEFC"], ["CT-03", "#A78BFA"],
  ["CT-04", "#229ED9"], ["CT-05", "#E5BF58"], ["CT-06", "#D946EF"],
  ["CT-07", "#7FB4FF"], ["CT-08", "#8F86FF"], ["CT-09", "#58C7B4"],
  ["CT-10", "#C5A15A"],
];

test("Cycle0459 visible Color Theme catalog has exactly ten canonical choices", () => {
  const rows = [...colors.matchAll(/\{ id: "(CT-\d{2})", slot: "\d{2}", name: "[^"]+", nameRu: "[^"]+", accent: "(#[0-9A-F]{6})" \}/g)]
    .map((m) => [m[1], m[2]]);
  assert.deepEqual(rows, expected);
  assert.equal(registry.color_theme_count, 10);
  assert.equal(registry.current_runtime_boundary.visible_color_theme_count, 10);
  assert.equal(registry.current_runtime_boundary.legacy_source_theme_input_count, 13);
});

test("Cycle0459 user color cycling is 10-color authority while legacy id is projection only", () => {
  assert.match(provider, /cycleColorThemeRecord\(draftColorThemeId, 1\)/);
  assert.match(provider, /cycleColorThemeRecord\(draftColorThemeId, -1\)/);
  assert.match(provider, /runtimeLegacyThemeIdForColorTheme\(nextTheme\.id\)/);
  assert.doesNotMatch(provider, /cycleGlobalThemeRecord/);
  assert.match(settings, /const globalThemeId = runtimeLegacyThemeIdForColorTheme\(colorThemeId\)/);
  assert.doesNotMatch(settings, /normalizeRuntimeLegacyThemeForColor/);
  // Superseded by direct OWNER Cycle0464/08: PB/RP reset on an actual CT switch;
  // every unrelated independent design variant still persists as before.
  assert.match(provider, /interface_variants:\s*nextVariants/);
  assert.match(provider, /COLOR_THEME_PROGRESS_STARTER\[nextColorThemeId\]/);
});

test("Cycle0459 theme indicators are ten Color Theme points, not legacy design slots", () => {
  assert.match(compact, /COLOR_THEME_CATALOG\.map/);
  assert.match(compact, /data-color-theme-dots=\{COLOR_THEME_CATALOG\.length\}/);
  assert.match(compact, /--efhc-indicator-color": theme\.accent/);
  assert.match(energy, /data-color-theme-indicators=\{COLOR_THEME_CATALOG\.length\}/);
  assert.match(energy, /customization\.colorThemeId === theme\.id/);
  assert.match(energy, /--efhc-indicator-color": theme\.accent/);
});

test("Cycle0459 local design dots use actual family inventory and are independent of Color Theme count", () => {
  assert.match(dots, /const slotCount = getInterfaceVariantAuthoredSlotCount\(surface\.group\)/);
  assert.doesNotMatch(dots, /GLOBAL_THEME_CATALOG\.length/);
  assert.doesNotMatch(dots, /GLOBAL_THEME_GROUPS\.includes/);
});

test("Cycle0459 deterministic duplicate legacy colors collapse to canonical projections", () => {
  assert.match(colors, /"10": "CT-06"/);
  assert.match(colors, /"11": "CT-03"/);
  assert.match(colors, /"12": "CT-03"/);
  assert.match(colors, /"CT-03": "03"/);
  assert.match(colors, /"CT-06": "06"/);
  assert.match(colors, /"CT-10": "10"/);
});

}

// Recovered coverage from current-cycle0460-full-matrix-frame-ownership.test.mjs
{





const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../../..");
const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");
const json = (rel) => JSON.parse(read(rel));

const catalog = json("frontend/src/design-system/universal-design-catalog.json");
const ssot = json("docs/SSOT/COLOR_DESIGN_DECOUPLING_SSOT.json");
const adapter = read("frontend/src/styles/referrals-social-brand-contract.css");
const colors = ["CT-01","CT-02","CT-03","CT-04","CT-05","CT-06","CT-07","CT-08","CT-09","CT-10"];

function rules(text) {
  return [...text.matchAll(/([^{}]+)\{([^{}]*)\}/gs)].map((m) => ({selector:m[1].replace(/\s+/g," ").trim(), body:m[2]}));
}
function declarations(body) {
  return body.split(";").map((row) => row.trim()).filter(Boolean).map((row) => {
    const i=row.indexOf(":"); return i < 0 ? [row,""] : [row.slice(0,i).trim(),row.slice(i+1).trim()];
  });
}

test("Cycle0460 current catalog declares the full 10 x universal-design availability cross-product", () => {
  assert.equal(catalog.counts.color_theme_applicable_design_variants, 207);
  assert.equal(catalog.counts.color_theme_count, 10);
  assert.equal(catalog.counts.qualified_color_design_cells, 0);
  assert.equal(ssot.color_theme_applicable_design_variants, 241);
  assert.equal(ssot.qualified_color_design_cells, 2410);
});

test("Cycle0460 every Color-applicable design variant is available in every canonical CT", () => {
  let variants=0;
  for (const group of catalog.groups) {
    if (!Array.isArray(group.color_theme_availability)) continue;
    assert.deepEqual(group.color_theme_availability, colors, group.group);
    for (const variant of group.variants) {
      assert.deepEqual(variant.available_in_color_themes, colors, variant.id);
      variants += 1;
    }
  }
  assert.equal(variants, 207);
});

test("Cycle0460 Color Theme CSS does not own frame geometry", () => {
  const forbidden = new Set([
    "border","border-width","border-style","border-radius",
    "padding","padding-inline","padding-block","margin",
    "width","height","min-width","max-width","min-height","max-height",
    "position","inset","top","right","bottom","left","gap","transform"
  ]);
  const violations=[];
  for (const rule of rules(adapter)) {
    if (!rule.selector.includes("data-color-theme-id")) continue;
    for (const [prop] of declarations(rule.body)) if (forbidden.has(prop)) violations.push(`${rule.selector} -> ${prop}`);
  }
  assert.deepEqual(violations, []);
});

test("Cycle0460 frame chroma has a narrow CT authority while active compatibility remains explicit", () => {
  assert.match(adapter, /--efhc-ct-border:color-mix\(in srgb,var\(--efhc-ct-accent\) 24%,transparent\)/);
  assert.match(adapter, /--efhc-ct-border-strong:color-mix\(in srgb,var\(--efhc-ct-accent\) 42%,transparent\)/);
  assert.match(adapter, /--efhc-route-border:var\(--efhc-ct-border\)/);
  assert.match(adapter, /--efhc-color-border:var\(--efhc-ct-border\)/);
  assert.match(adapter, /--efhc-theme-edge:var\(--efhc-ct-border\)/);
  assert.match(ssot.frame_ownership.status, /AUDIT_CORRECTED|DECOUPLED_AND_MACHINE_GUARDED/);
});

test("Cycle0460 independent frame selector is not silently invented by the migration cycle", () => {
  assert.match(ssot.frame_ownership.independent_frame_selector, /NOT_ASSIGNED|NOT_INTRODUCED/);
  assert.match(ssot.next_cycle, /0464 OWNER CORRECTION RESERVED \/ UNASSIGNED \/ STOP/);
});

}

// Recovered coverage from current-cycle0461-external-audit-frame-owner-recovery.test.mjs
{





const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../../..");
const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");
const json = (rel) => JSON.parse(read(rel));

const adapter = read("frontend/src/styles/referrals-social-brand-contract.css");
const material = read("frontend/src/styles/universal-frame-material-contract.css");
const exchangePage = read("frontend/src/pages/exchange.tsx");
const exchangePanel = read("frontend/src/components/ExchangePanel.tsx");
const ssot = json("docs/SSOT/COLOR_DESIGN_DECOUPLING_SSOT.json");
const standalone = read(`${read("VERSION").trim()}.html`);

function rules(text) {
  return [...text.matchAll(/([^{}]+)\{([^{}]*)\}/gs)].map((m) => ({
    selector: m[1].replace(/\/\*[\s\S]*?\*\//g, " ").replace(/\s+/g, " ").trim(),
    body: m[2],
  }));
}
function declarations(body) {
  return body.split(";").map((row) => row.trim()).filter(Boolean).map((row) => {
    const i = row.indexOf(":");
    return i < 0 ? [row, ""] : [row.slice(0, i).trim(), row.slice(i + 1).trim()];
  });
}

test("Cycle0461 CT adapter no longer owns frame/shadow structural declarations caught by the external audit", () => {
  const forbidden = new Set([
    "border", "border-width", "border-style", "border-radius",
    "outline", "outline-width", "outline-style", "outline-offset",
    "box-shadow", "background",
    "padding", "padding-inline", "padding-block", "margin",
    "width", "height", "min-width", "max-width", "min-height", "max-height",
    "position", "inset", "top", "right", "bottom", "left", "gap", "transform",
  ]);
  const violations = [];
  let backgroundImageDebt = 0;
  for (const rule of rules(adapter)) {
    if (!rule.selector.includes("data-color-theme-id")) continue;
    for (const [prop] of declarations(rule.body)) {
      if (forbidden.has(prop)) violations.push(`${rule.selector} -> ${prop}`);
      if (prop === "background-image") backgroundImageDebt += 1;
    }
  }
  assert.deepEqual(violations, []);
  // External audit counted 406 CT-owned background-image declarations before this cycle.
  // Cycle0461 removes the audited RG-03 evidence sites; remaining topology is explicit debt,
  // not silently certified as fully decoupled.
  assert.ok(backgroundImageDebt <= 403, `unexpected CT background-image debt increase: ${backgroundImageDebt}`);
});

test("Cycle0461 copy-link geometry is DESIGN/state-owned while CT supplies chroma only", () => {
  const copySlice = adapter.slice(
    adapter.indexOf("OWNER-reported v687 issue: Copy Link"),
    adapter.indexOf("Cycle0456 Batch H foundation"),
  );
  assert.match(copySlice, /background-color:color-mix/);
  assert.match(copySlice, /outline-color:var\(--efhc-ct-focus\)/);
  assert.doesNotMatch(copySlice, /\bbox-shadow\s*:/);
  assert.doesNotMatch(copySlice, /\boutline\s*:/);
  assert.doesNotMatch(copySlice, /\boutline-offset\s*:/);
  assert.doesNotMatch(copySlice, /\bbackground\s*:/);

  assert.match(material, /outline-width:2px/);
  assert.match(material, /outline-style:solid/);
  assert.match(material, /outline-offset:3px/);
  assert.match(material, /box-shadow:none!important/);
  assert.doesNotMatch(material.replace(/\/\*[\s\S]*?\*\//g, ""), /data-color-theme-id/);
});

test("Cycle0461 audited RG-03 material topology is DESIGN-owned", () => {
  const rg03Adapter = rules(adapter).filter((rule) => rule.selector.includes('data-rg="RG-03"'));
  for (const rule of rg03Adapter) {
    const props = declarations(rule.body).map(([prop]) => prop);
    assert.ok(!props.includes("box-shadow"), rule.selector);
    assert.ok(!props.includes("background-image"), rule.selector);
  }
  assert.match(material, /data-rg="RG-03"[\s\S]*background-image:radial-gradient/);
  assert.match(material, /data-rg="RG-03"[\s\S]*box-shadow:rgba\(var\(--efhc-ct-accent-rgb\)/);
});

test("Cycle0461 Exchange XS XC XA variants attach to their actual production owners", () => {
  assert.match(exchangePage, /useInterfaceVariantSurface<HTMLDivElement>\("XS", \{ registerDots: false, interactive: false \}\)/);
  assert.match(exchangePage, /className="efhc-exchange-stats-surface"[\s\S]*data-xs=\{statsSurface\.variant\}/);
  assert.doesNotMatch(exchangePage, /data-xc=\{bodySurface\.variant\}/);

  assert.match(exchangePanel, /useInterfaceVariantSurface<HTMLDivElement>\("XC", \{ registerDots: false, interactive: false \}\)/);
  assert.match(exchangePanel, /className="efhc-exchange-card-variant"[\s\S]*data-xc=\{cardSurface\.variant\}/);
  assert.match(exchangePanel, /useInterfaceVariantSurface<HTMLDivElement>\("XA", \{ registerDots: false, interactive: false \}\)/);
  assert.match(exchangePanel, /className="efhc-exchange-action-surface"[\s\S]*data-xa=\{actionSurface\.variant\}/);
});

test("Cycle0461 standalone exposes direct XS XC XA owners while preserving only explicit XC compatibility projection", () => {
  assert.match(standalone, /id="exchangeStatsSurface"/);
  assert.doesNotMatch(standalone, /id="exchangeStatsSurface"[^>]*data-swipe-group="XS"/);
  assert.match(standalone, /id="exchangeCard"/);
  assert.doesNotMatch(standalone, /id="exchangeCard"[^>]*data-swipe-group="XC"/);
  assert.match(standalone, /id="exchangeActionSurface"/);
  assert.doesNotMatch(standalone, /id="exchangeActionSurface"[^>]*data-swipe-group="XA"/);
  assert.match(standalone, /exchangeStatsSurface\.dataset\.xs=styleOf\('XS',v\.XS\)/);
  assert.match(standalone, /exchangeCard\.dataset\.xc=styleOf\('XC',v\.XC\)/);
  assert.match(standalone, /exchangeActionSurface\.dataset\.xa=styleOf\('XA',v\.XA\)/);
  assert.match(standalone, /Compatibility projection for historical standalone XC selectors/);
});

test("Cycle0461 SSOT distinguishes catalog availability from full rendered certification", () => {
  assert.equal(ssot.color_theme_applicable_design_variants, 241);
  assert.equal(ssot.qualified_color_design_cells, 2410);
  assert.equal(ssot.qualified_color_design_cells_scope, "CATALOG_AVAILABILITY_ONLY");
  assert.equal(ssot.full_rendered_cross_product_certified, false);
  assert.equal(ssot.frame_ownership.ct_background_image_declarations_remaining, 403);
});

}

// Recovered coverage from current-cycle0463-owner-i18n-theme-corrections.test.mjs
{





const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../../..");
const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");
const json = (rel) => JSON.parse(read(rel));
const locales = Object.fromEntries(fs.readdirSync(path.join(root, "frontend/public/locale")).filter((x)=>x.endsWith(".json")).map((x)=>[x.slice(0,-5),json(`frontend/public/locale/${x}`)]));

const walletExpected = {ru:"Кошелёк",en:"Wallet",uk:"Гаманець",de:"Geldbörse",fr:"Portefeuille",es:"Billetera",it:"Portafoglio",tr:"Cüzdan",pl:"Portfel",da:"Tegnebog",hi:"बटुआ",id:"Dompet",sw:"Pochi",pt:"Carteira",ko:"지갑",ja:"ウォレット"};

test("Cycle0463 Wallet and direct deposit are real 16-language keys", () => {
  assert.equal(Object.keys(locales).length,16);
  for (const [lang, value] of Object.entries(walletExpected)) assert.equal(locales[lang]["wallet.title"],value,lang);
  for (const [lang, data] of Object.entries(locales)) {
    assert.match(data["deposit.direct_title"], /EFHC$/u, lang);
    assert.ok(data["deposit.amount_label"].trim(),lang);
    assert.ok(data["deposit.direct_send_efhc"].trim(),lang);
    assert.ok(data["common.cancel"].trim(),lang);
  }
  assert.equal(locales.ja["nav.ranks"],"ランク");
  assert.equal(locales.ja["ranks.title"],"ランク");
});

test("Cycle0463 production Ranks Wallet and direct deposit use i18n keys", () => {
  const layout=read("frontend/src/components/Layout.tsx");
  const header=read("frontend/src/components/GlobalHeader.tsx");
  const profile=read("frontend/src/components/ProfileModal.tsx");
  const deposit=read("frontend/src/components/DepositModal.tsx");
  // OWNER 2026-10-20: all six Bottom Nav labels remain English; other Ranks UI localizes.
  assert.match(layout,/visualLabel: "Ranks"/);
  assert.doesNotMatch(layout,/visualLabel: t\("nav\.ranks"\)/);
  assert.match(header,/aria-label=\{t\("wallet\.title"\)\}/);
  assert.match(header,/<span>\{t\("wallet\.title"\)\}<\/span>/);
  assert.doesNotMatch(header,/data-i18n-fixed-token="Wallet"/);
  assert.equal((profile.match(/title=\{t\("wallet\.title"\)\}/g)||[]).length,2);
  assert.match(deposit,/title=\{t\("deposit\.direct_title"\)\}/);
});

test("Cycle0463 standalone Ranks Wallet and direct deposit are explicitly keyed", () => {
  const html=read(`${read("VERSION").trim()}.html`);
  assert.match(html,/data-i18n-aria-key="wallet\.title"/);
  assert.match(html,/data-i18n-key="wallet\.title"/);
  assert.match(html,/data-route="\/ranks" title="Ranks"/);
  assert.match(html,/efhc-game-nav_label">Ranks<\/span>/);
  assert.doesNotMatch(html,/data-i18n-aria-key="nav\.ranks"/);
  assert.doesNotMatch(html,/data-i18n-key="nav\.ranks"/);
  for (const key of ["deposit.direct_title","deposit.amount_label","deposit.direct_send_efhc","common.cancel"]) assert.match(html,new RegExp(`data-i18n-(?:key|aria-key)="${key.replaceAll(".","\\.")}"`));
  assert.match(html,/data-i18n-key="exchange\.receive_label">Вы получите<\/span>:/);
});

test("Cycle0463 CT06 is Fuchsia and inactive gray cannot be an active theme accent", () => {
  const registry=json("frontend/src/design-system/color-theme-registry.json");
  const ct6=registry.themes.find((x)=>x.id==="CT-06");
  const ct10=registry.themes.find((x)=>x.id==="CT-10");
  assert.equal(ct6.name,"Fuchsia"); assert.equal(ct6.accent,"#D946EF");
  assert.equal(ct10.name,"Muted Gold"); assert.equal(ct10.accent,"#C5A15A");
  assert.equal(registry.owner_law.inactive_disabled_indicator_gray,"#94A3B8");
  assert.equal(registry.themes.some((x)=>x.accent.toUpperCase()==="#94A3B8"),false);
  assert.equal(new Set(registry.themes.map((x)=>x.accent.toUpperCase())).size,10);
});

test("Cycle0463 CT10 uses standard theme selector material and inactive indicators are gray", () => {
  const css=read("frontend/src/styles/globals.css");
  const ct=read("frontend/src/styles/referrals-social-brand-contract.css");
  assert.doesNotMatch(css,/data-color-theme-id="CT-10"\] \.efhc-compact-theme-carousel_swatch/);
  assert.match(ct,/data-color-theme-id="CT-06"\]\{\s*--efhc-ct-accent:#d946ef;--efhc-ct-accent-rgb:217,70,239;/);
  const marker=css.indexOf("FRONTEND_ADMIN_CYCLE_0459 — Color Theme indicators");
  assert.ok(marker>=0);
  const layer=css.slice(marker);
  assert.match(layer,/\.efhc-compact-theme-dots>span\{[\s\S]*?background:#94a3b8;/);
  assert.match(layer,/\.efhc-compact-theme-dots>span\[data-active="true"\]\{[\s\S]*?background:var\(--efhc-indicator-color\);/);
  assert.match(layer,/\.efhc-energy-frame-theme-slots>span\{[\s\S]*?background:color-mix\(in srgb,#94a3b8 68%,transparent\)/);
  assert.match(layer,/\.efhc-energy-frame-theme-slots>span\[data-active="true"\]\{[\s\S]*?background:var\(--efhc-indicator-color\);/);
});

}

// Recovered coverage from current-cycle0464-ct10-runtime-retirement.test.mjs
{





const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const read = name => fs.readFileSync(path.join(root,name),'utf8');
const color = read('frontend/src/lib/colorThemeRegistry.ts');
const global = read('frontend/src/lib/globalThemeRegistry.ts');
const settings = read('frontend/src/lib/settings.ts');
const provider = read('frontend/src/components/interface-settings/InterfaceCustomizationProvider.tsx');
const html = read(`${read('VERSION').trim()}.html`);
const styles = read('frontend/src/styles/globals.css');

test('Active Global Theme13 is retired, preserving old 13 only as migration input', () => {
  const catalog = global.split('export const GLOBAL_THEME_CATALOG',2)[1].split('] as const',1)[0];
  assert.doesNotMatch(catalog,/id: "13"/);
  const slots = global.split('const SLOT_MATRIX:',2)[1].split('export const GLOBAL_THEME_SLOT_MATRIX',1)[0];
  assert.doesNotMatch(slots,/"13": Object\.freeze/);
  assert.match(color,/"13": "CT-10"/); // historical import only
  assert.match(color,/"CT-10": "10"/); // active projection only
  assert.match(html,/const GLOBAL_THEME_IDS = Object\.freeze\(\["01","02","03","04","05","06","07","08","09","10","11","12"\]\)/);
  assert.doesNotMatch(html,/const COLOR_TO_RUNTIME_LEGACY_THEME = Object\.freeze\([^\n]*"CT-10":"13"/);
});

test('Clean settings never import retired Theme13 persisted identities', () => {
  assert.doesNotMatch(settings, /rawLegacyThemeId === "13"|wasRetiredTheme13|historicalTheme13|persistedCT10/);
  assert.doesNotMatch(settings, /migrateSettingsSourceV17|migrateKgChoiceV19/);
  assert.match(settings, /runtimeLegacyThemeIdForColorTheme\(colorThemeId\)/);
  assert.match(html, /COLOR_TO_RUNTIME_LEGACY_THEME/);
  assert.match(html, /!\[2,3,4\]\.includes\(raw\.interface_settings_version\)/);
  assert.doesNotMatch(html, /historicalThemeId==='13'\?normalizeVariants/);
});

test('All user-facing theme selection projects CT10 to Global10 without changing other colors', () => {
  assert.match(provider,/runtimeLegacyThemeIdForColorTheme\(\s*nextColorThemeId/);
  assert.match(html,/"CT-10":"10"/);
  for (let n=1; n<=9; n++) {
    const id=String(n).padStart(2,'0');
    assert.match(color,new RegExp(`"CT-${id}": "${id}"`));
  }
});

test('Profile/Wallet/Balance changes do not replace geometry, shadows or financial semantics', () => {
  const marker='/* Cycle0464 OWNER correction: USER Profile, Wallet, Balance ONLY.';
  assert.ok(styles.includes(marker));
  const css=styles.slice(styles.indexOf(marker), styles.indexOf("/* Cycle0467 OWNER:", styles.indexOf(marker)));
  assert.doesNotMatch(css,/border-radius\s*:|box-shadow\s*:|backdrop-filter\s*:/);
  assert.doesNotMatch(css,/data-status-kind|data-operation-tone|\.efhc-profile-status-window/);
  assert.match(html,/const COLOR_THEME_CATALOG = Object\.freeze/);
  assert.doesNotMatch(global,/"13": "PB-29"/);
});

}

// Recovered coverage from current-cycle0464-direct-deposit-owner-final.test.mjs
{





const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../..");
const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");
const html = read(`${read("VERSION").trim()}.html`);
const react = read("frontend/src/components/DepositModal.tsx");
const css = read("frontend/src/styles/referrals-social-brand-contract.css");
const block = css.slice(css.indexOf("/* Cycle0464/07 — final OWNER-approved Direct Deposit CT material."));
const standalone = html.slice(html.indexOf("/* Cycle0464/07 — final OWNER Direct Deposit"), html.indexOf("/* Cycle0464/06 — PB/RP selected variants"));

test("Cycle0464 OWNER final: deposit preview reuses an existing label across 16 locales", () => {
  assert.match(react, /\{t\("exchange\.receive_label"\)\}:/);
  assert.doesNotMatch(react, /<small>EFHC Jetton → EFHCm<\/small>/);
  assert.match(html, /data-i18n-key="exchange\.receive_label">Вы получите<\/span>:/);
  for (const file of fs.readdirSync(path.join(root, "frontend/public/locale")).filter(x=>x.endsWith(".json"))) {
    const locale = JSON.parse(read(`frontend/public/locale/${file}`));
    assert.ok(locale["exchange.receive_label"], file);
  }
});

test("Cycle0464 OWNER final: quiet primary with white text; thin themed cancel, no amount focus highlight", () => {
  assert.match(block, /background-color:rgba\(var\(--efhc-ct-accent-rgb\),\.055\)!important/);
  assert.match(block, /color:#f8fafc!important/);
  assert.match(block, /\.efhc-btn-secondary[\s\S]*?border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.22\)!important/);
  assert.match(block, /\.efhc-direct-deposit_amount-control:focus-within[\s\S]*?border-color:rgba/);
  assert.doesNotMatch(block, /box-shadow:|outline:/);
  assert.match(read("frontend/src/styles/globals.css"), /\.efhc-direct-deposit_amount-control:focus-within \{[\s\S]*?outline: none;/);
  assert.match(standalone, /background:rgba\(var\(--efhc-ct-accent-rgb\),\.055\)!important/);
  assert.match(html, /#standaloneDirectDepositV218 input:focus-visible\{outline:none!important;box-shadow:none!important\}/);
  assert.doesNotMatch(standalone, /outline:0!important|box-shadow:none!important/);
  assert.doesNotMatch(standalone, /EFHC Jetton → EFHCm/);
});

}

// Recovered coverage from current-cycle0464-owner-acceptance-v704.test.mjs
{





const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const get = file => fs.readFileSync(path.join(root, file), 'utf8');
const coverage = get('frontend/src/styles/global-theme-owner-coverage.css');
const globals = get('frontend/src/styles/globals.css');
const html = get(`FRONTEND_${get('VERSION').trim().split('_')[1]}.html`);
const tokens = JSON.parse(get('frontend/src/design-system/color-theme-registry.json'));

test('OWNER earnings captions are white in every Color Theme, including CT03', () => {
  const part = coverage.slice(coverage.indexOf('OWNER Cycle0464 continuation: two earnings labels'));
  assert.match(part, /data-color-theme-id\]\s*:is\(\.efhc-tasks-shell,#tasksPage\)/);
  assert.match(part, /\.efhc-bonus-earnings-row>span,\.standalone-bonus-earnings-strip span/);
  assert.match(part, /color:#ffffff!important/);
  assert.doesNotMatch(part.slice(0, part.indexOf('Energy name:')), /not\(\[data-color-theme-id="CT-03"\]\)/);
});
test('Energy name hue belongs to Color Theme, never EG-06 violet', () => {
  assert.doesNotMatch(globals, /data-global-theme-id="06"\] \.efhc-energy-stage\[data-eg="EG-06"\] \.efhc-energy-stage_eyebrow\{/);
  assert.match(coverage, /\.efhc-energy-stage\[data-eg\] \.efhc-energy-stage_eyebrow/);
  assert.match(coverage, /color:var\(--efhc-ct-accent\)!important/);
  assert.match(html, /cycle0464-owner-color-coverage/);
});
test('My Panels and Ranks load more use transparent 3-percent CT backgrounds', () => {
  assert.match(coverage, /\.efhc-panels-shell \.efhc-panels-portfolio-entry/);
  assert.match(coverage, /#ranksPage\[data-kg\] #loadMoreRanks/);
  assert.match(coverage, /background:color-mix\(in srgb,var\(--efhc-ct-accent\) 3%,transparent\)!important/);
  assert.match(coverage, /color:#ffffff!important/);
  assert.match(get('frontend/src/pages/ranks.tsx'), /data-ranks-load-more="true"/);
});
test('CT10 current color registry is muted gold and differs from both CT05 and historical Theme13',()=>{
  const g= tokens.themes.find(x=>x.id==='CT-10');
  assert.equal(g.name,'Muted Gold');
  assert.equal(g.accent,'#C5A15A');
  assert.notEqual(g.accent,tokens.themes.find(x=>x.id==='CT-05').accent);
  assert.match(get('frontend/src/lib/colorThemeRegistry.ts'),/CT-10.*Muted Gold.*#C5A15A/);
  assert.match(html, /"id":"CT-10","name":"Приглушённое золото","accent":"#C5A15A"/);
  assert.doesNotMatch(html,/--efhc-ct-accent:#ffd400/);
  assert.match(get('frontend/src/design-system/global-theme-color-canon.json'),/historical provenance only/);
});

}

// Recovered coverage from current-cycle0464-owner-color-coverage.test.mjs
{





const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../..");
const read = (rel) => fs.readFileSync(path.join(root,rel),"utf8");
const css = read("frontend/src/styles/global-theme-owner-coverage.css");
const app = read("frontend/src/pages/_app.tsx");
const html = read(`${read("VERSION").trim()}.html`);
const registry = JSON.parse(read("frontend/src/design-system/color-theme-registry.json"));

test("Cycle0468 user color-theme consumers include all CT01–CT10 equally",()=>{
  assert.match(css,/data-interface-app-mode="user"/);
  assert.match(css,/data-color-theme-id\]/);
  assert.doesNotMatch(css,/data-global-theme-id="03"/);
  assert.doesNotMatch(css,/data-interface-app-mode="admin"|data-shop-theme|shop-landing/);
  assert.match(app,/import "\.\.\/styles\/global-theme-owner-coverage\.css";/);
});

test("Cycle0464 all agreed controls share a CT-owned neutral-intensity visual contract",()=>{
  for(const token of ["efhc-energy-chip","efhc-energy-mini-card","efhc-panels-portfolio-entry","data-panels-portfolio-entrypoint","efhc-referrals-my-entry","data-referrals-my-entrypoint","data-history-export","efhc-task-card_bottom","source-task-card","efhc-bonus-earnings-strip","standalone-bonus-earnings-strip","efhc-panels-sort-direction","panels-sort-button","efhc-panel-activ-status","efhc-interface-customization-button","efhc-global-theme-control","interface-customization-button","global-theme-control"]){assert.ok(css.includes(token),token);}
  assert.match(css,/--efhc-owner-coverage-surface:color-mix\(in srgb,var\(--efhc-ct-accent\) 3%,transparent\)/);
  assert.match(css,/\.efhc-energy-mini-card_value[\s\S]*?color:#f8fafc!important/);
});

test("Cycle0464 active badge is CT-toned, disabled badge is neutral gray",()=>{
  assert.match(css,/data-status="activ"\]\[data-active="true"\][\s\S]*?--efhc-owner-coverage-action-edge/);
  assert.match(css,/data-status="activ"\]\[data-active="false"\][\s\S]*?color:#94a3b8!important/);
  assert.equal(registry.themes.some(t=>t.accent.toUpperCase()==="#94A3B8"),false);
});

test("Cycle0464 canonical CT-06 and CT-10 hues remain unique; CT-10 has subdued UI rather than opaque gold",()=>{
  const ct6=registry.themes.find(t=>t.id==="CT-06");const ct10=registry.themes.find(t=>t.id==="CT-10");
  assert.equal(ct6.accent,"#D946EF");assert.equal(ct10.accent,"#C5A15A");
  assert.equal(new Set(registry.themes.map(t=>t.accent)).size,10);
  assert.match(css,/data-color-theme-id="CT-10"/);
  assert.match(css,/\.efhc-panels-activate/);
  assert.doesNotMatch(css,/background-color:(?:#ffd400|#FFD400)|background:(?:#ffd400|#FFD400)/);
});

test("Cycle0468 standalone uses the same universal style contract and latest physical version",()=>{
  assert.match(read("VERSION").trim(),/^FRONTEND_v\d+$/);
  const begin=html.indexOf('<style id="cycle0464-owner-color-coverage">');
  const end=html.indexOf("</style>",begin);
  assert.ok(begin>=0&&end>begin);
  const block=html.slice(begin,end);
  assert.match(block,/efhc-energy-chip/);
  assert.match(block,/panels-sort-button/);
  assert.match(block,/standalone-withdraw-history-export-actions/);
  assert.match(html,/id="withdrawExportCsv"/);
  assert.match(html,/id="withdrawExportXlsx"/);
  assert.match(block,/standalone-bonus-earnings-strip/);
  assert.match(block,/global-theme-control/);
  assert.match(block,/data-color-theme-id\]/);
});

}

// Recovered coverage from current-cycle0464-owner-progress-theme-and-strips.test.mjs
{





const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const html=()=>read(`${read('VERSION').trim()}.html`);
const starts=['PB-01','PB-28','PB-22','PB-23','PB-24','PB-25','PB-29','PB-30','PB-26','PB-27'];

test('OWNER Cycle0464: ten themes have ten distinct PB and RP starting identities',()=>{
 const colors=read('frontend/src/lib/colorThemeRegistry.ts');
 const contract=JSON.parse(read('frontend/src/design-system/global-theme-energy-progress-contract.json'));
 for(let i=1;i<=10;i++){
  const ct=`CT-${String(i).padStart(2,'0')}`;
  assert.equal(contract.owner_cycle0464_08_progress_selection.map[ct],starts[i-1]);
  assert.match(colors,new RegExp(`"${ct}": "${starts[i-1]}"`));
 }
 assert.equal(new Set(starts).size,10);
});

test('OWNER Cycle0464: actual CT change resets only PB/RP, independent manual selection remains available',()=>{
 const provider=read('frontend/src/components/interface-settings/InterfaceCustomizationProvider.tsx');
 assert.match(provider,/nextColorThemeId === currentColorId \? sourceVariants/);
 assert.match(provider,/\.\.\.sourceVariants,\s*PB: COLOR_THEME_PROGRESS_STARTER\[nextColorThemeId\],\s*RP: COLOR_THEME_PROGRESS_STARTER\[nextColorThemeId\]/);
 assert.match(provider,/const selectIndividualVariant = useCallback/);
 assert.match(provider,/\[group\]: normalizedValue/);
 const standalone=html();
 assert.match(standalone,/const CT_PROGRESS_STARTER=Object\.freeze/);
 assert.match(standalone,/if\(colorId!==draftColorThemeId\)draft=\{\.\.\.draft,PB:CT_PROGRESS_STARTER\[colorId\],RP:CT_PROGRESS_STARTER\[colorId\]\}/);
 assert.match(standalone,/if\(colorId!==savedColorThemeId\)savedVariants=\{\.\.\.savedVariants,PB:CT_PROGRESS_STARTER\[colorId\],RP:CT_PROGRESS_STARTER\[colorId\]\}/);
});

test('OWNER Cycle0464: only Direct Deposit decorative header/action backgrounds removed',()=>{
 const css=read('frontend/src/styles/referrals-social-brand-contract.css');
 assert.match(css,/\.efhc-user-direct-deposit-portal\[data-interface-app-mode="user"\] \.efhc-modal-header,/);
 assert.match(css,/\.efhc-user-direct-deposit-portal\[data-interface-app-mode="user"\] \.efhc-direct-deposit_actions\{\s*background-color:transparent!important;\s*background-image:none!important;/);
 assert.match(html(),/#standaloneDirectDepositV218 \.standalone-settings-dialog > \.source-row\{background-color:transparent!important;background-image:none!important;/);
 assert.match(html(),/standalone-direct-deposit-v218_summary\{[^}]*border-top/);
});

test('OWNER Cycle0464: updated amount label available in all 16 locales and standalone',()=>{
 const files=fs.readdirSync(path.join(root,'frontend/public/locale')).filter(x=>x.endsWith('.json'));
 assert.equal(files.length,16);
 for(const file of files){const j=JSON.parse(read(`frontend/public/locale/${file}`)); assert.ok(j['deposit.amount_label'].length>=15,file);assert.doesNotMatch(j['deposit.amount_label'],/jetton/i,file);}
 assert.equal(JSON.parse(read('frontend/public/locale/ru.json'))['deposit.amount_label'],'Введите количество EFHC монет для пополнения');
 assert.match(html(),/data-i18n-key="deposit.amount_label">Введите количество EFHC монет для пополнения/);
});

test('OWNER Cycle0464: former gray progress bars are themed without deleting saved IDs',()=>{
 const css=read('frontend/src/styles/global-theme-energy-progress-contract.css');
 for(const id of ['PB-27','PB-33'])assert.match(css,new RegExp(`data-pb="${id}"`));
 assert.doesNotMatch(css,/#64748b,#94a3b8/);
 const standalone=html();
 assert.match(standalone,/data-color-theme-id="CT-06"[^\n]*data-pb="PB-27"/);
 assert.match(standalone,/data-color-theme-id="CT-10"[^\n]*data-pb="PB-29"/);
});

}

// Recovered coverage from current-cycle0464-user-balance-clean-surfaces.test.mjs
{





const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const read=(p)=>fs.readFileSync(path.join(root,p),'utf8');
const style=read('frontend/src/styles/globals.css');
const standalone=read(`${read('VERSION').trim()}.html`);
const begin='/* Cycle0464 / OWNER Balance: original v712 frame geometry, CT01–CT10 chroma.';
const contract=style.slice(style.indexOf(begin), style.indexOf("/* Cycle0467 OWNER:", style.indexOf(begin)));

test('Cycle0464 user Balance: standalone/React use one scoped surface contract',()=>{
  assert.ok(contract.startsWith(begin));
  assert.match(standalone,/<!-- CYCLE0464_USER_BALANCE_SURFACE_BEGIN -->/);
  assert.ok(standalone.includes(contract.trim()));
  assert.match(contract,/data-interface-app-mode="user"/);
  assert.match(contract,/data-profile-active-tab="history"/);
  assert.doesNotMatch(contract,/data-interface-app-mode="admin"|#adminUsersPage|#browserShopPage/);
});

test('Cycle0464 user Balance: preserve original dated groups, split three balances into OWNER-approved cards',()=>{
  for(const selector of ['.efhc-history-balance-stack','.efhc-history-section-head','.efhc-history-bank-nav','.efhc-history-bank-day-title']){
    assert.ok(contract.includes(selector),selector);
  }
  assert.match(contract,/\.efhc-history-bank-day\s*\{\s*border:1px solid rgba\(var\(--efhc-ct-accent-rgb\),\.30\)/);
  assert.match(contract,/\.efhc-history-bank-day \.efhc-history-bank-operation\s*\{\s*border:0;/);
  assert.match(contract,/\.efhc-history-balance-stack\s*\{\s*display:grid;[\s\S]*?border:0;/);
  assert.match(contract,/\.efhc-history-balance-row\s*\{\s*border:1px solid rgba\(var\(--efhc-ct-accent-rgb\),\.30\)/);
  assert.match(contract,/\.efhc-history-balance-row\+\.efhc-history-balance-row\s*\{\s*border-top:1px solid rgba\(var\(--efhc-ct-accent-rgb\),\.30\)/);
  assert.match(contract,/\.efhc-history-bank-operation\+\.efhc-history-bank-operation\s*\{\s*border-top:1px solid rgba\(var\(--efhc-ct-accent-rgb\),\.15\)/);
  assert.match(contract,/\.source-profile-name/);
});

test('Cycle0464 user Balance: Color Theme controls only decorative chroma, semantic finance protected',()=>{
  assert.match(contract,/var\(--efhc-ct-accent-rgb\)/);
  assert.match(contract,/var\(--efhc-ct-accent\)/);
  const semantic=read('docs/frontend/FRONTEND_BALANCE_SEMANTIC_COLOR_CANON.md');
  assert.match(semantic,/OWNER-PROTECTED/);
  assert.doesNotMatch(contract,/data-operation-tone|data-status-kind|data-balance-tone="(main|bonus)"/);
  const feed=read('frontend/src/components/profile/history/HistoryOperationFeed.tsx');
  assert.match(feed,/data-operation-tone=\{item\.tone\}/);
  assert.match(feed,/data-status-kind=\{item\.statusKind\}/);
});

}

// Recovered coverage from current-cycle0465-profile-wallet-balance-surfaces.test.mjs
{





const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const read = (relative) => fs.readFileSync(path.join(root, relative), 'utf8');
const style = read('frontend/src/styles/globals.css');
const standalone = read(`${read('VERSION').trim()}.html`);
const marker = '/* Cycle0465 OWNER: clean only the three USER account views across CT01–CT10.';
const contract = style.slice(style.indexOf(marker), style.indexOf('/* Cycle0464 / OWNER Balance:', style.indexOf(marker))).trim();

test('Cycle0465: React and standalone share one account-only CSS correction', () => {
  assert.ok(contract.startsWith(marker));
  assert.ok(standalone.includes(`<style id="cycle0465-user-profile-wallet-balance">\n${contract}\n</style>`));
  assert.match(contract, /data-interface-app-mode="user"/);
  assert.match(contract, /\[data-color-theme-id\]/);
  assert.match(contract, /\[data-global-theme-id\]\[data-theme-chroma-canon\]/);
  assert.doesNotMatch(contract, /#admin|data-interface-app-mode="admin"|#browserShopPage|\.efhc-game-header|\.efhc-energy-frame-theme-slots/);
});

test('Cycle0465: remove only root/sheet/username/ledger structural backing', () => {
  for (const name of [
    '.efhc-profile-page', '#profilePage',
    '.source-profile-content[data-profile-content="profile"]',
    '.source-profile-content[data-profile-content="wallet"]',
    '.standalone-history-sheet[data-profile-content="history"]',
    '.source-profile-identity > .source-row:first-child',
    '.source-profile-name', '.efhc-profile-name-row',
    '.efhc-history-balance-header', '.efhc-history-section-head',
    '.efhc-history-bank-feed', '.standalone-history-filters',
  ]) assert.ok(contract.includes(name), name);
  assert.match(contract, /background-color:transparent!important/);
  assert.match(contract, /background-image:none!important/);
  assert.doesNotMatch(contract, /\.standalone-wallet-card\s*[,\{]|\.source-stat\s*[,\{]|\.efhc-history-balance-row\s*[,\{]|\.efhc-history-bank-day\s*[,\{]/);
});

test('Cycle0465: preserve finance, wallet, theme-switch and statuses', () => {
  assert.doesNotMatch(contract, /data-operation-tone|data-status-kind|data-balance-tone|primary-status|data-profile-status|efhc-profile-avatar|efhc-profile-badges|efhc-profile-tab--active|interface-swipe-dots/);
  const source = read('frontend/src/features/profile/WebProfilePage.tsx');
  assert.match(source, /data-profile-active-tab=\{activeTab\}/);
  assert.match(source, /useWalletsMe\(\)/);
  const balance = read('frontend/src/components/profile/ProfileHistorySection.tsx');
  assert.match(balance, /totalBalance/);
  assert.match(balance, /bonusBalance/);
});

}

// Recovered coverage from current-cycle0466-iteration02-profile-balance-simplification.test.mjs
{




const root=path.resolve(import.meta.dirname,"../../..");
const read=(p)=>fs.readFileSync(path.join(root,p),"utf8");
const json=(p)=>JSON.parse(read(p));
const hiKeep=["HI-01","HI-02","HI-03"];
const hiSelections=["HI-01","HI-02","HI-03"];
const hiRemove=["HI-02","HI-05","HI-09","HI-10","HI-11","HI-12"];
test("OWNER HI catalog drops exactly six designs and never renumbers survivor slots",()=>{
 const src=read("frontend/src/lib/interfaceVariantRegistry.ts");
 assert.match(src,/HI: numbered\("HI", 3\)/);
 assert.ok(src.includes('"HI-02":"HI-03"') && src.includes('"HI-03":"HI-04"'));
 assert.match(src,/toPhysicalSlots\(variants\)/);
 for(const rel of ["frontend/src/design-system/universal-design-registry.json","frontend/src/design-system/universal-design-catalog.json"]){
  const g=json(rel).groups.find(g=>g.group==="HI");assert.equal(g.variant_count,3);assert.deepEqual(g.variants.map(v=>v.id),hiKeep);
  for(const old of hiRemove)assert.equal(g.legacy_theme_slots[old.slice(-2)],"HI-01");
 }
 for(const old of hiRemove)assert.doesNotMatch(src,new RegExp(`"${old}":\\s*"HI-01"`));
});
test("OWNER Profile single WG01 design, full legacy migration, current catalog counts",()=>{
 const src=read("frontend/src/lib/interfaceVariantRegistry.ts");assert.match(src,/WG: numbered\("WG", 1\)/);
 assert.doesNotMatch(src,/OWNER_RETIRED_VARIANT_ALIASES/);
 for(const rel of ["frontend/src/design-system/universal-design-registry.json","frontend/src/design-system/universal-design-catalog.json"]){
  const g=json(rel).groups.find(g=>g.group==="WG");assert.equal(g.variant_count,1);assert.equal(g.variants[0].id,"WG-01");
 }
 const d=json("frontend/src/design-system/universal-design-catalog.json");assert.equal(d.theme03_common_default_set.WG,"WG-01");assert.equal(d.counts.color_theme_applicable_design_variants,207);assert.equal(d.counts.catalog_available_color_design_cells,2070);
});
test("OWNER Profile chroma CT-owned, 12px radius, neutral inactive status, 21pct frames",()=>{
 const css=read("frontend/src/styles/globals.css");
 assert.match(css,/--wg-accent:var\(--efhc-ct-accent\)/);
 assert.match(css,/--wg-radius:12px/);
 assert.match(css,/border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.21\)/);
 assert.match(css,/\.efhc-profile-status--off\{[\s\S]*?color:#94a3b8/);
 assert.match(css,/\.efhc-profile-action-card\)\{[\s\S]*?background-color:transparent!important/);
});
test("OWNER only Profile visible language label removed; ARIA maintained in production and standalone",()=>{
 const component=read("frontend/src/components/profile/CompactLanguagePicker.tsx");
 const page=read("frontend/src/features/profile/WebProfilePage.tsx");
 const html=read(`${read("VERSION").trim()}.html`);
 assert.match(component,/showLabel\?: boolean/);assert.match(component,/aria-label=\{props.label\}/);
 assert.match(page,/showLabel=\{false\}/);
 assert.doesNotMatch(html,/<span class="source-label" data-i18n-key="profile.language">Язык<\/span>/);
 assert.match(html,/data-i18n-aria-key="profile.language"/);
 assert.match(html,/"WG":\["WG-01"\]/);
 assert.ok(html.includes(`"HI":[${hiSelections.map(x=>`"${x}"`).join(",")}]`));
 assert.doesNotMatch(html,/OWNER_RETIRED_VARIANT_ALIASES/);
});

}

// Recovered coverage from current-cycle0466-iteration03-balance-profile-owner.test.mjs
{




const root=path.resolve(import.meta.dirname,"../../..");
const read=(rel)=>fs.readFileSync(path.join(root,rel),"utf8");
const json=(rel)=>JSON.parse(read(rel));
const ids=["HI-01","HI-02","HI-03"];
const selectedHi=["HI-01","HI-02","HI-03"];
const removed={"HI-07":"HI-01","HI-08":"HI-03","HI-13":"HI-04"};

test("Cycle0466 iteration03: three trailing HI copies retired, fourth unique design retained",()=>{
 const source=read("frontend/src/lib/interfaceVariantRegistry.ts");
 assert.match(source,/HI: numbered\("HI", 3\)/);
 assert.ok(source.includes('"HI-02":"HI-03"'));
 for (const old of Object.keys(removed))assert.doesNotMatch(source,new RegExp(`"${old}":\\s*"HI-`));
 for(const file of ["frontend/src/design-system/universal-design-registry.json","frontend/src/design-system/universal-design-catalog.json"]){
  const g=json(file).groups.find(g=>g.group==="HI");assert.equal(g.variant_count,3);assert.deepEqual(g.variants.map(v=>v.id),ids);
  for(const [old,canonical] of Object.entries(removed))assert.equal(g.legacy_theme_slots[old.slice(3)],canonical);
 }
});

test("Cycle0466 iteration03: HI dots consecutive in React and standalone without dangerous ID renumbering",()=>{
 const react=read("frontend/src/components/interface-settings/InterfaceVariantDotsLayer.tsx");
 assert.match(react,/const compact = surface\.group === "HI" \|\| surface\.group === "XH"/);
 assert.match(react,/INTERFACE_VARIANT_REGISTRY\[surface\.group\]/);
 assert.match(react,/const displayCount = compact[\s\S]*?INTERFACE_VARIANT_REGISTRY\[surface\.group\]\.length/);
 const html=read(`${read("VERSION").trim()}.html`);
 assert.ok(html.includes(`"HI":[${selectedHi.map(x=>`"${x}"`).join(",")}]`));
 assert.match(html,/const slotCount=compact\?variants\.length/);
 assert.match(html,/compact\?index\+1/);
 assert.doesNotMatch(html,/const OWNER_RETIRED_VARIANT_ALIASES/);
});

test("Cycle0466 iteration03: precise CT03 and CT04 child-row underlay and carousel correction",()=>{
 const css=read("frontend/src/styles/globals.css");
 const html=read(`${read("VERSION").trim()}.html`);
 assert.match(css,/Cycle0466 iteration03: restore spacious Interface frame/);
 assert.match(css,/min-height:138px/);
 assert.match(css,/\.efhc-compact-language-picker[\s\S]*?background-color:transparent!important/);
 assert.match(html,/cycle0466Iteration03ProfileBalance/);
 assert.match(html,/\.source-profile-settings-card > \.source-row\s*\{[\s\S]*?background-color:transparent!important/);
 assert.match(html,/\.source-profile-compact-control\s*\{[\s\S]*?background-color:transparent!important/);
});

test("Cycle0466 iteration03: canonical counts, no CT palette or wallet semantics changes",()=>{
 const catalog=json("frontend/src/design-system/universal-design-catalog.json");
 const ssot=json("docs/SSOT/COLOR_DESIGN_DECOUPLING_SSOT.json");
 assert.equal(catalog.counts.color_theme_applicable_design_variants,207);
 assert.equal(catalog.counts.catalog_available_color_design_cells,2070);
 assert.equal(ssot.color_theme_applicable_design_variants,241);
 assert.equal(ssot.qualified_color_design_cells,2410);
 assert.equal(catalog.groups.find(g=>g.group==="WG").variant_count,1);
 assert.equal(catalog.counts.color_theme_count,10);
});

}

// Recovered coverage from current-cycle0466-iteration04-owner-corrections.test.mjs
{




const root=path.resolve(import.meta.dirname,"../../..");
const read=(name)=>fs.readFileSync(path.join(root,name),"utf8");
const current=()=>read(`${read("VERSION").trim()}.html`);
const css=read("frontend/src/styles/globals.css");
const registry=read("frontend/src/lib/interfaceVariantRegistry.ts");
const json=(p)=>JSON.parse(read(p));

test("Cycle0466 iteration04: report parser accepts only optional historical final dot, not missing cycle header",()=>{
 const parser=read("ops/reports/check_numbered_reports.py");
 assert.match(parser,/cycle_re = re\.compile\(r"\^- Цикл: `\(\[\^`\]\+\)`\\\.\?\$"/);
 assert.match(read("reports/numbered/00676__reports_FRONTEND_ADMIN_CYCLE_0464_iteration_13_FRONTEND_v717_CT10_active_theme13_retirement_and_profile_surfaces.md"),/^- Цикл: `FRONTEND_ADMIN_CYCLE_0464`\.$/m);
});
test("Cycle0466 iteration04: three HI templates, legacy selection migration and exact catalog counts",()=>{
 assert.match(registry,/HI: numbered\("HI", 3\)/);
 assert.doesNotMatch(registry,/"HI-06": "HI-01"/);
 for(const file of ["frontend/src/design-system/universal-design-registry.json","frontend/src/design-system/universal-design-catalog.json"]){
  const group=json(file).groups.find(x=>x.group==="HI");
  assert.equal(group.variant_count,3);
  assert.deepEqual(group.variants.map(x=>x.id),["HI-01","HI-02","HI-03"]);
  assert.equal(group.legacy_theme_slots["06"],"HI-01");
 }
 const design=json("frontend/src/design-system/universal-design-catalog.json");
 assert.equal(design.counts.color_theme_applicable_design_variants,207);
 assert.equal(design.counts.catalog_available_color_design_cells,2070);
 const html=current();assert.match(html,/"HI":\["HI-01","HI-02","HI-03"\]/);assert.doesNotMatch(html,/"HI-06":"HI-01"/);
});
test("Cycle0466 iteration04: Wallet Connect color depends on linked-account state, not connected session",()=>{
 const banner=read("frontend/src/components/profile/wallet/WalletConnectBanner.tsx");
 const section=read("frontend/src/components/profile/ProfileWalletSection.tsx");
 assert.match(section,/hasLinkedWallet=\{serverBoundWallets\.length > 0\}/);
 assert.match(banner,/data-linked-wallets=\{props\.hasLinkedWallet \? "present" : "empty"\}/);
 assert.match(css,/\.efhc-wallet-connect-cta\[data-linked-wallets="empty"\]/);
 assert.match(css,/\.efhc-wallet-connect-cta\[data-linked-wallets="present"\]/);
 assert.match(current(),/connectButton\.dataset\.linkedWallets=active\.length>0\?"present":"empty"/);
});
test("Cycle0466 iteration04: Profile surfaces keep CT geometry while lowering carousel and badges",()=>{
 assert.match(css,/\.efhc-profile-third-row\{margin-top:6px;\}/);
 assert.match(css,/\.efhc-profile-compact-controls\{margin-top:8px;\}/);
 assert.match(css,/\.efhc-profile-topbar_actions\s*> button\{background:transparent!important/);
 assert.match(current(),/#profilePage \.source-profile-compact-control\{margin-top:8px;\}/);
});
test("Cycle0466 iteration04: Direct Deposit portal retains all ten canonical CT accents and themed cancel",()=>{
 const theme=json("frontend/src/design-system/color-theme-registry.json").themes;
 for(const {id,accent} of theme){
  assert.ok(css.includes(`.efhc-user-direct-deposit-portal[data-color-theme-id="${id}"]{--efhc-ct-accent:${accent}`),id);
 }
 const modal=read("frontend/src/components/ui/Modal.tsx");
 const deposit=read("frontend/src/components/DepositModal.tsx");
 assert.match(modal,/data-color-theme-id=\{props\.portalColorThemeId\}/);
 assert.match(deposit,/data-direct-deposit-action="cancel"/);
 assert.match(css,/data-direct-deposit-action="cancel"\]\{background:transparent!important/);
});
test("Cycle0466 iteration04: Panels activation underlay and portfolio-entry button scoped to CT",()=>{
 assert.match(css,/\.efhc-panels-activation-card > \.grid > \.grid/);
 assert.match(css,/\.efhc-panels-shell \.efhc-panels-portfolio-entry\{background:transparent!important/);
 assert.match(css,/\.efhc-panels-dashboard-runtime__panel-card :is\(/);
});
test("Cycle0466 iteration04: Referrals no nested Card for tabs and preserves status routes",()=>{
 const my=read("frontend/src/pages/referrals/my.tsx");
 const list=read("frontend/src/components/referrals/ReferralListPage.tsx");
 assert.match(my,/<div data-referrals-segments="active-inactive"/);
 assert.doesNotMatch(my,/<Card data-referrals-segments=/);
 assert.match(my,/selectTab\("active"\)/);
 assert.match(my,/selectTab\("inactive"\)/);
 assert.match(list,/onClick=\{\(\) => openTab\("active"\)\}/);
 assert.match(list,/onClick=\{\(\) => openTab\("inactive"\)\}/);
 assert.match(css,/\.efhc-referrals-segment-surface > \.efhc-btn-primary/);
 assert.match(css,/\.efhc-referrals-segment-surface > \.efhc-segmented > \.efhc-btn-primary/);
 assert.match(current(),/id="referralTabs"/);
});
test("Cycle0466 iteration04: CT06 Fuchsia and CT10 muted gold remain palette-owned",()=>{
 const catalog=json("frontend/src/design-system/color-theme-registry.json").themes;
 assert.equal(catalog.find(x=>x.id==="CT-06").accent.toLowerCase(),"#d946ef");
 assert.equal(catalog.find(x=>x.id==="CT-10").accent.toLowerCase(),"#c5a15a");
 assert.doesNotMatch(css.slice(css.indexOf("/* Cycle0466 iteration04"),css.indexOf("/* Cycle0466 iteration03")),/data-status-kind|data-operation-tone/);
});

}

// Recovered coverage from current-cycle0466-profile-variant-dedupe.test.mjs
{




const root=path.resolve(import.meta.dirname,"../../..");
const read=(p)=>fs.readFileSync(path.join(root,p),"utf8");
const parse=(p)=>JSON.parse(read(p));
const canonical=Object.fromEntries(Array.from({length:12},(_,i)=>[`WG-${String(i+2).padStart(2,"0")}`,"WG-01"]));
const selected=["WG-01"];
test("Cycle0466 WG selector leaves only WG01 and stable numbered slots",()=>{
 const src=read("frontend/src/lib/interfaceVariantRegistry.ts");
 assert.match(src,/WG: numbered\("WG", 1\)/);
 assert.doesNotMatch(src,/OWNER_RETIRED_VARIANT_ALIASES/);
 assert.match(src,/toPhysicalSlots\(variants\)/);
});
test("Cycle0466 universal registries show sole WG01 with migration slots",()=>{
 for(const rel of ["frontend/src/design-system/universal-design-catalog.json","frontend/src/design-system/universal-design-registry.json"]){
  const d=parse(rel),g=d.groups.find(x=>x.group==="WG");
  assert.equal(g.variant_count,1);
  assert.deepEqual(g.variants.map(v=>v.id),selected);
  for(const [gone,to] of Object.entries(canonical))assert.equal(g.legacy_theme_slots[gone.slice(-2)],to);
 }
 const cat=parse("frontend/src/design-system/universal-design-catalog.json");
 assert.equal(cat.counts.color_theme_applicable_design_variants,207);
 assert.equal(cat.counts.catalog_available_color_design_cells,2070);
});
test("Cycle0466 standalone retains WG-01 and unrelated design registries under clean initial state",()=>{
 const html=read(`${read("VERSION").trim()}.html`);
 assert.ok(html.includes(`"WG":[${selected.map(v=>`"${v}"`).join(",")}]`));
 assert.doesNotMatch(html,/const OWNER_RETIRED_VARIANT_ALIASES/);
 assert.match(html,/const normalizeVariants\s*=\s*input/);
 assert.match(html,/const interface_variants=normalizeVariants\(raw\.interface_variants\)/);
 for(const g of ["PM","HI","WD"])assert.ok(html.includes(`"${g}":[`));
});

}

// Recovered coverage from current-cycle0467-exchange-design-cleanup.test.mjs
{




const root=path.resolve(import.meta.dirname,'../../..');
const read=(f)=>fs.readFileSync(path.join(root,f),'utf8');
const json=(f)=>JSON.parse(read(f));
const registry=read('frontend/src/lib/interfaceVariantRegistry.ts');
const dots=read('frontend/src/components/interface-settings/InterfaceVariantDotsLayer.tsx');
const css=read('frontend/src/styles/globals.css');
const production=read('frontend/src/pages/exchange.tsx');
const panel=read('frontend/src/components/ExchangePanel.tsx');
const current=()=>read(`${read('VERSION').trim()}.html`);
const XH=['XH-01','XH-02','XH-03','XH-04','XH-05','XH-06'];

test('Cycle0467 upper Exchange selector contains only six OWNER-retained designs, no XH09',()=>{
  assert.match(registry,/XH: numbered\("XH", 6\)/);
  assert.doesNotMatch(registry,/XH: Object.freeze\(\[\.\.\.numbered/);
  assert.match(dots,/surface\.group === "HI" \|\| surface\.group === "XH"/);
  assert.match(dots,/displayCount = compact/);
  assert.match(current(),/const compact=group==='HI'\|\|group==='XH'/);
  const active=JSON.parse(current().match(/const REGISTRY = Object\.freeze\((\{[^\n]+\})\);/)[1]);
  assert.deepEqual(active.XH,["XH-01","XH-02","XH-03","XH-04","XH-05","XH-06"]);
});

test('Cycle0467 internal Exchange selectors are singletons and disabled on React and standalone',()=>{
 for(const g of ['XS','XC','XA']){
  assert.match(registry,new RegExp(`${g}: numbered\\("${g}", 1\\)`));
  assert.ok(current().includes(`"${g}":["${g}-01"]`));
 }
 assert.match(production,/"XS", \{ registerDots: false, interactive: false \}/);
 assert.match(panel,/"XC", \{ registerDots: false, interactive: false \}/);
 assert.match(panel,/"XA", \{ registerDots: false, interactive: false \}/);
 assert.doesNotMatch(current(),/data-swipe-group="(?:XS|XC|XA)"/);
});

test('Cycle0546 retired Exchange aliases are removed; selections reset without old-ID redirects',()=>{
  assert.doesNotMatch(registry,/OWNER_RETIRED_VARIANT_ALIASES/);
  assert.doesNotMatch(current(),/OWNER_RETIRED_VARIANT_ALIASES/);
  assert.match(registry,/XH: numbered\("XH", 6\)/);
  assert.match(current(),/"XH":\["XH-01","XH-02","XH-03","XH-04","XH-05","XH-06"\]/);
});

test('Cycle0467 active catalogs and defaults reconcile with 10 CT and preserve legacy records',()=>{
 for(const file of ['frontend/src/design-system/universal-design-catalog.json','frontend/src/design-system/universal-design-registry.json']){
  const d=json(file),groups=new Map(d.groups.map(g=>[g.group,g]));
  assert.deepEqual(groups.get('XH').variants.map(v=>v.id),XH);
  for(const g of ['XS','XC','XA'])assert.deepEqual(groups.get(g).variants.map(v=>v.id),[`${g}-01`]);
  assert.equal(d.theme03_common_default_set.XH,'XH-01');
  assert.equal(d.theme03_common_default_set.XC,'XC-01');
  assert.equal(groups.get('XH').legacy_theme_slots['03'],'XH-03');
  assert.equal(groups.get('XC').legacy_theme_slots['03'],'XC-03');
  if (d.counts.color_theme_applicable_design_variants != null) assert.equal(d.counts.color_theme_applicable_design_variants,207);
  if (d.counts.catalog_available_color_design_cells != null) assert.equal(d.counts.catalog_available_color_design_cells,2070);
 }
 const d=json('frontend/src/design-system/universal-design-catalog.json');
 assert.equal(d.common_initial_defaults.XH,'XH-01');
 assert.equal(d.common_initial_defaults.XC,'XC-01');
});

test('Cycle0467 direct deposit button uses 8% CT tint, 30% outline and light label',()=>{
 assert.match(css,/\.efhc-user-direct-deposit-portal\[data-color-theme-id\] \.efhc-direct-deposit_actions \[data-direct-deposit-action="send-efhc-jetton"\] \{/);
 assert.match(css,/background:rgba\(var\(--efhc-ct-accent-rgb\),\.08\)!important/);
 assert.match(css,/border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.30\)!important/);
 assert.match(css,/color:#f8fafc!important/);
 assert.match(current(),/\[data-direct-deposit-send-v218\]/);
});

test('Cycle0467 Exchange history uses light foreground and CT background without altering flow',()=>{
 assert.match(production,/className="efhc-exchange-history-hint"/);
 assert.match(production,/className="efhc-exchange-history-link"/);
 assert.match(production,/t\("exchange\.history_profile_note"\)/);
 assert.match(production,/t\("exchange\.open_history"\)/);
 assert.match(css,/\.efhc-exchange-history-hint\s*\{\s*color:#e5e7eb!important/);
 assert.match(css,/\.efhc-exchange-history-link\s*\{[\s\S]*?background:rgba\(var\(--efhc-ct-accent-rgb\),\.08\)!important/);
 assert.match(current(),/id="cycle0467-owner-exchange-css"/);
});

test('Cycle0467 critical energy and exchange business contracts remain present',()=>{
 assert.match(production,/cmp8\(amount, maxExchangeableKwh\) > 0/);
 assert.match(production,/newIdempotencyKey\(\)/);
 assert.match(production,/exchangeMutation\.mutateAsync\(/);
 assert.match(production,/formatFixedDown\(availableKwh, 2\)/);
 assert.match(production,/1 kWh = 1 EFHCm/);
 assert.match(panel,/maxKwh/);
});

}

// Cycle0467 current USER UI contracts — durable after the 32-suite cleanup.
{
 const root=path.resolve(import.meta.dirname,'../../..');
 const read=(f)=>fs.readFileSync(path.join(root,f),'utf8');
 const css=read('frontend/src/styles/globals.css');
 const avatar=read('frontend/src/components/profile/ProfileAvatarVisual.tsx');
 const wallet=read('frontend/src/components/profile/ProfileWalletSection.tsx');
 const exchange=read('frontend/src/components/ExchangePanel.tsx');
 const html=()=>read(`${read('VERSION').trim()}.html`);
 test('Active Profile frame uses 40-percent CT border and 0.8px thickness; inactive frame is subtly CT-owned',()=>{
  assert.match(css,/\.efhc-profile-tab--active\s*\{[\s\S]*?box-shadow:inset 0 0 0 \.8px rgba\(var\(--efhc-ct-accent-rgb\),\.40\)!important/);
  assert.match(css,/\.efhc-profile-tab:not\(\.efhc-profile-tab--active\)\s*\{[\s\S]*?border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.14\)!important/);
  assert.match(html(),/\.source-profile-tabs button\[data-active="true"\]\s*\{[\s\S]*?box-shadow:inset 0 0 0 \.8px rgba\(var\(--efhc-ct-accent-rgb\),\.40\)!important/);
 });
 test('Exchange MAX receives same themed outline as Withdraw MAX; input and rates untouched',()=>{
  assert.match(exchange,/data-exchange-max-action="true"/);
  assert.match(css,/\.efhc-exchange-panel \[data-exchange-max-action="true"\]\s*\{[\s\S]*?border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.45\)!important/);
  assert.match(html(),/#exchangePage #exchangeMaxButton\s*\{[\s\S]*?border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.45\)!important/);
 });
 test('Wallet action outlines are themed, disabled remain gray, no styling changes to geometry',()=>{
  assert.match(wallet,/serverBoundWallets\.length > 0/);
  assert.match(css,/\.efhc-wallet-trust-section :is\(\s*\.efhc-wallet-entry,\.efhc-wallet-card/);
  assert.match(css,/\.efhc-wallet-trust-section :is\(button:disabled,\[aria-disabled="true"\]\)/);
  assert.match(html(),/source-profile-content\[data-profile-content="wallet"\]/);
 });
 test('Avatar uses source-aware photo and symbol fit while preserving Energy avatar',()=>{
  const unified=read('frontend/src/components/profile/UnifiedAvatar.tsx');
  const resolver=read('frontend/src/lib/avatarPreference.ts');
  assert.match(avatar,/useAvatarPreference\(\)/);
  assert.match(unified,/data-avatar-fit=\{fit\}/);
  assert.match(unified,/objectFit: fit === "symbol" \? "contain" : "cover"/);
  assert.match(unified,/objectPosition: fit === "symbol" \? "center" : "50% 38%"/);
  assert.match(unified,/onError=\{\(\) => setState\("error"\)\}/);
  assert.match(resolver,/selected\.kind === "provider"/);
  assert.match(resolver,/selected\.kind === "url"/);
  assert.match(resolver,/kind: "icon", icon: pref\.fallbackIcon/);
  assert.match(css,/\.efhc-profile-avatar-image\[data-avatar-fit="photo"\]/);
  assert.match(css,/object-position:50% 38%/);
  assert.match(css,/\.efhc-profile-avatar-image\[data-avatar-fit="symbol"\]/);
  assert.match(css,/object-fit:contain;object-position:center;padding:12%/);
  assert.match(unified,/<EnergyVariantIcon variant=\{variant\}/);
 });
 test('Profile language row maintains balanced inset and all locales, standalone unchanged function',()=>{
  assert.match(css,/\.efhc-profile-action-card:has\(\.efhc-profile-card-heading\)\s*\{\s*padding:16px!important/);
  assert.match(html(),/\.source-profile-settings-card\{padding:14px!important/);
  assert.match(html(),/source-profile-settings-card \.source-profile-compact-control/);
  assert.match(read('frontend/src/components/profile/CompactLanguagePicker.tsx'),/SUPPORTED_LANGS\.map/);
  assert.match(html(),/id="profileLanguageMenu" role="listbox"/);
 });
 test('10 CT palette remains data-driven, singleton Profile WG and protected Theme03 unchanged',()=>{
  const reg=JSON.parse(read('frontend/src/design-system/color-theme-registry.json'));
  assert.equal(reg.themes.length,10);
  const variants=read('frontend/src/lib/interfaceVariantRegistry.ts');
  assert.match(variants,/WG: numbered\("WG", 1\)/);
  assert.doesNotMatch(read('frontend/src/styles/global-theme-owner-coverage.css'),/:not\(\[data-color-theme-id="CT-03"\]\)/);
 });
}

// Current KG recovery regression. These assertions execute the actual isolated
// migration function rather than matching a passing source token.
test("Ten KG designs retain original CSS mapping while clean startup rejects old schemas", () => {
  const root = path.resolve(import.meta.dirname, "../../..");
  const read = (p) => fs.readFileSync(path.join(root,p),"utf8");
  const registry = read("frontend/src/lib/interfaceVariantRegistry.ts");
  const settings = read("frontend/src/lib/settings.ts");
  const currentHtml = read(`${read("VERSION").trim()}.html`);
  const oldStyleIds = ["01","02","04","06","07","08","09","10","11","12"];
  oldStyleIds.forEach((original, index) => {
    const current = `KG-${String(index + 1).padStart(2, "0")}`;
    const style = `KG-${original}`;
    assert.match(registry, new RegExp(`"${current}":\\s*"${style}"`));
    assert.ok(currentHtml.includes(`"${current}":"${style}"`), `${current} retains ${style}`);
  });
  assert.match(settings, /interface_settings_version: 4/);
  assert.doesNotMatch(settings, /LEGACY_KG_TO_NUMBERED|migrateKgChoiceV19|NUMBERED_KG_TO_LEGACY/);
  assert.doesNotMatch(currentHtml, /const LEGACY_KG_TO_NUMBERED =/);
});

// Cycle0471 OWNER recovery: only approved v727 physical IDs remain selectable.
// Keep this contract in the maintained evergreen suite, not in one-off cycle files.
{
const root=path.resolve(import.meta.dirname,"../../..");
const read=(p)=>fs.readFileSync(path.join(root,p),"utf8");
const json=(p)=>JSON.parse(read(p));
const retained={
  EG:["EG-01"], BN:["BN-01","BN-02","BN-03","BN-04","BN-05"],
  TG:["TG-01","TG-02","TG-03","TG-04"],
  PH:["PH-01","PH-02","PH-03","PH-04","PH-05","PH-06"],
  PT:["PT-01","PT-02","PT-03","PT-04","PT-05"],
  PC:["PC-01","PC-02","PC-03","PC-04","PC-05","PC-06","PC-07","PC-08","PC-09"],
  PA:["PA-01","PA-02","PA-03","PA-04","PA-05","PA-06"],
  KG:Array.from({length:10},(_,i)=>`KG-${String(i+1).padStart(2,"0")}`),
};
test("OWNER Cycle0471 exact catalogs protect pruned choices in both current authorities",()=>{
 const catalog=json("frontend/src/design-system/universal-design-catalog.json");
 const registry=json("frontend/src/design-system/universal-design-registry.json");
 for(const doc of [catalog,registry]){
   const groups=Object.fromEntries(doc.groups.map(g=>[g.group,g]));
   assert.equal(doc.counts.registry_variant_tokens_total,236);
   assert.equal(doc.counts.design_owned_non_admin_variants,220);
   for(const [group,ids] of Object.entries(retained)){
     assert.deepEqual(groups[group].variants.map(v=>v.id),ids,group);
     assert.equal(groups[group].variant_count,ids.length);
   }
   assert.deepEqual(groups.RP.variants.map(v=>v.id.slice(-2)),groups.PB.variants.map(v=>v.id.slice(-2)));
   assert.equal(groups.RP.variant_count,33);
   assert.equal(groups.PB.variant_count,33);
 }
 assert.equal(catalog.counts.color_theme_applicable_design_variants,207);
 assert.equal(catalog.counts.catalog_available_color_design_cells,2070);
 assert.deepEqual(catalog.theme03_common_default_set.EG,"EG-01");
 assert.equal(json("docs/SSOT/COLOR_DESIGN_DECOUPLING_SSOT.json").color_theme_applicable_design_variants,241);
});
test("OWNER Cycle0471 standalone technical theme matrix cannot select retired physical IDs",()=>{
 const html=read(`${read("VERSION").trim()}.html`);
 const found=html.match(/const REGISTRY = Object\.freeze\((\{[^\n]+\})\);/);
 assert.ok(found,"standalone registry present");
 const runtime=JSON.parse(found[1]);
 const authorizedCurrent={
  ...retained,
  BN:["BN-01","BN-02","BN-03","BN-04","BN-05"],
  TG:["TG-01","TG-02","TG-03","TG-04"],
  PH:["PH-01","PH-02","PH-03","PH-04","PH-05","PH-06"],
  PA:["PA-01","PA-02","PA-03","PA-04","PA-05","PA-06"],
  PT:["PT-01","PT-02","PT-03","PT-04","PT-05"],
  PC:["PC-01","PC-02","PC-03","PC-04","PC-05","PC-06","PC-07","PC-08","PC-09"],
  WD:["WD-01","WD-02","WD-03","WD-04","WD-05"],
 };
 for(const [group,ids] of Object.entries(authorizedCurrent))assert.deepEqual(runtime[group],ids);
 assert.match(html,/const REGISTRY = Object\.freeze/);
 assert.match(html,/const SOURCE_STYLE = Object\.freeze/);
 // The historical 01..13 physical theme projection is provenance, not a selector.
 assert.match(html,/THEME_SLOT_MATRIX/);
 assert.doesNotMatch(html,/Material Capsule|Minimal Tab Bar/);
});
}
