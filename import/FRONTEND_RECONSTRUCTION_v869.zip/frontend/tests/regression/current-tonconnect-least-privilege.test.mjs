import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";

const repoRoot = path.resolve(import.meta.dirname, "../../..");
const workflow = fs.readFileSync(
  path.join(repoRoot, ".github/workflows/tonconnect-sdk-auto-update.yml"),
  "utf8",
);

function section(startToken, endToken = null) {
  const start = workflow.indexOf(startToken);
  assert.ok(start >= 0, `missing workflow token: ${startToken}`);
  const end = endToken ? workflow.indexOf(endToken, start + startToken.length) : -1;
  if (endToken) {
    assert.ok(end > start, `missing workflow end token: ${endToken}`);
  }
  return workflow.slice(start, end >= 0 ? end : undefined);
}

test("Current correction keeps candidate acceptance read-only and credential-free", () => {
  assert.match(workflow, /permissions:\n  contents: read/);
  const accept = section("  accept:\n", "  propose:\n");
  assert.match(accept, /permissions:\n      contents: read/);
  assert.match(accept, /persist-credentials: false/);
  assert.doesNotMatch(accept, /contents: write/);
  assert.doesNotMatch(accept, /pull-requests: write/);
  assert.doesNotMatch(accept, /git push/);
  assert.doesNotMatch(accept, /gh pr create/);
});

test("Current correction isolates write permissions in post-acceptance proposal job", () => {
  const propose = section("  propose:\n");
  assert.match(propose, /needs: accept/);
  assert.match(propose, /contents: write/);
  assert.match(propose, /pull-requests: write/);
  assert.match(propose, /if: needs\.accept\.outputs\.status == 'UPDATE_AVAILABLE'/);
  assert.doesNotMatch(propose, /npm ci/);
  assert.doesNotMatch(propose, /npm run /);
});

test("Current correction transfers only hash-bound accepted package state", () => {
  assert.match(workflow, /Build hash-bound proposal artifact/);
  assert.match(workflow, /Upload accepted proposal artifact/);
  assert.match(workflow, /Download accepted proposal artifact/);
  assert.match(workflow, /Verify downloaded proposal hashes and exact SDK target/);
  assert.match(workflow, /package_json_sha256/);
  assert.match(workflow, /package_lock_sha256/);
  assert.match(workflow, /package\.json is not bound to guard evidence/);
  assert.match(workflow, /package-lock is not bound to guard evidence/);
});

test("Current correction pins third-party actions to immutable commit SHAs", () => {
  for (const sha of [
    "d23441a48e516b6c34aea4fa41551a30e30af803",
    "ece7cb06caefa5fff74198d8649806c4678c61a1",
    "249970729cb0ef3589644e2896645e5dc5ba9c38",
    "043fb46d1a93c77aae656e7c1c64a875d1fc6a0a",
    "3e5f45b2cfb9172054b4087a40e8e0b5a5461e7c",
  ]) {
    assert.match(workflow, new RegExp(`@${sha}`));
  }
  assert.doesNotMatch(workflow, /uses:\s*actions\/[\w-]+@v\d+/);
});

test("Current correction remains review-only after least-privilege split", () => {
  const propose = section("  propose:\n");
  assert.match(propose, /git push --force origin "HEAD:\$\{branch\}"/);
  assert.match(propose, /gh pr create/);
  assert.doesNotMatch(propose, /gh pr merge/);
  assert.doesNotMatch(propose, /git push[^\n]*HEAD:\$BASE_BRANCH/);
});
