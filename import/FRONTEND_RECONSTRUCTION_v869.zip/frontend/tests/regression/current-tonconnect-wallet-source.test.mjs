import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';
import { Buffer } from 'node:buffer';

const here = path.dirname(fileURLToPath(import.meta.url));
const frontendRoot = path.resolve(here, '../..');
const root = path.resolve(frontendRoot, '..');
const read = (relative) => fs.readFileSync(path.join(root, relative), 'utf8');
const version = read('VERSION').trim();

const primary = read('frontend/src/components/profile/wallet/WalletPrimaryCard.tsx');
const item = read('frontend/src/components/profile/wallet/WalletListItem.tsx');
const profile = read('frontend/src/components/ProfileModal.tsx');
const profileService = read('frontend/src/services/profile.service.ts');
const chooser = read('frontend/src/components/wallet/TonConnectWalletChooser.tsx');
const tonconnect = read('frontend/src/lib/tonconnect.ts');
const routing = read('frontend/src/lib/wallet-provider/primaryWalletRouting.ts');
const standalone = read(`${version}.html`);

test('Current bound-wallet UI is address-centric and never renders wallet_app as identity', () => {
  assert.doesNotMatch(primary, /wallet\.wallet_app/);
  assert.match(primary, /wallet\.primary_badge/);
  assert.match(primary, /WalletAddressVerification address=\{wallet\.wallet_address\}/);
  assert.doesNotMatch(item, /wallet\.wallet_app/);
  assert.match(item, /WalletAddressVerification address=\{wallet\.wallet_address\}/);
  assert.doesNotMatch(profile, /connectedWallet\.wallet_app/);
  assert.match(profile, /connectedWallet\.is_primary[\s\S]*wallet\.primary_wallet[\s\S]*wallet\.additional_wallet/);

  const rendererStart = standalone.indexOf('function renderStandaloneWallets()');
  const rendererEnd = standalone.indexOf('const standaloneHistoryT=', rendererStart);
  assert.ok(rendererStart >= 0 && rendererEnd > rendererStart);
  const renderer = standalone.slice(rendererStart, rendererEnd);
  assert.doesNotMatch(renderer, /wallet\.wallet_app/);
  assert.match(renderer, /data-wallet-badge="primary"/);
  assert.match(renderer, /data-wallet-copy-address/);
});

test('Current wallet_app is internal transport metadata, not public branding authority', () => {
  assert.match(profileService, /Internal transport\/history metadata only/);
  assert.doesNotMatch(profileService, /My Wallet|MyTonWallet/);
  assert.match(tonconnect, /wallet_app: walletTransportAppName\(wallet\)/);
  assert.match(tonconnect, /wallet\?\.device\?\.appName, wallet\?\.appName/);
  assert.doesNotMatch(tonconnect, /wallet\?\.name,[\s\S]*walletTransportAppName/);
  assert.match(tonconnect, /return "mytonwallet"/);
  assert.match(routing, /normalized === "mytonwallet" \|\| normalized === "mywallet"/);
  assert.match(routing, /return "mytonwallet"/);
});

test('Current production chooser uses SDK wallet list as sole branding/link source', () => {
  assert.equal(fs.existsSync(path.join(root, 'frontend/src/lib/wallet-provider/tonConnectFirstBindRegistry.ts')), false);
  assert.match(chooser, /data-tonconnect-registry-source="@tonconnect\/sdk\.getWallets"/);
  assert.doesNotMatch(chooser, /fetch\(|config\.ton\.org\/wallets-v2\.json|TON_CONNECT_FIRST_BIND_FALLBACK/);
  assert.match(chooser, /TON_CONNECT_PREFERRED_TECHNICAL_IDS/);
  assert.match(chooser, /"mytonwallet"/);
  assert.match(chooser, /"tonkeeper"/);
  assert.match(chooser, /<span>\{wallet\.name\}<\/span>/);
  assert.match(chooser, /src=\{wallet\.imageUrl \|\| fallbackLogo\(wallet\.name\)\}/);
  assert.match(chooser, /props\.onSelect\(wallet\)/);
  assert.doesNotMatch(chooser, /Tonkeeper|Keeper|My Wallet|MyTonWallet/);
});

test('Current standalone chooser has live official registry and no branded fallback catalog', () => {
  const match = standalone.match(/STANDALONE_OWNER_TONCONNECT_HTML_V247=decodeTonConnectUtf8Base64V246\('([^']+)'\)/);
  assert.ok(match);
  const html = Buffer.from(match[1], 'base64').toString('utf8');
  assert.match(html, /data-tonconnect-registry-source="config\.ton\.org\/wallets-v2\.json-live"/);
  assert.match(html, /fetch\('https:\/\/config\.ton\.org\/wallets-v2\.json', \{cache:'no-store'\}\)/);
  assert.match(html, /PREFERRED_TECHNICAL_IDS = \['mytonwallet','tonkeeper','tonhub','bitgetTonWallet'\]/);
  assert.doesNotMatch(html, /const FALLBACK|label:'Tonkeeper'|label:'My Wallet'/);
  assert.match(html, /<span>\$\{esc\(w\.name \|\| w\.app_name\)\}<\/span>/);
  assert.match(html, /wallets = \[\];/);

  assert.match(standalone, /wallet_app:'tonkeeper'/);
  assert.match(standalone, /wallet_app:'mytonwallet'/);
  assert.doesNotMatch(standalone, /data-direct-deposit-wallet-v239="Tonkeeper"|data-direct-deposit-wallet-v239="My Wallet"/);
});

test('Current keeps TON Connect chooser keyboard/accessibility behavior', () => {
  assert.match(chooser, /const viewAllRef = useRef<HTMLButtonElement \| null>\(null\)/);
  assert.match(chooser, /const searchRef = useRef<HTMLInputElement \| null>\(null\)/);
  assert.match(chooser, /if \(view === "all"\) \{[\s\S]*searchRef\.current\?\.focus\(\)/);
  assert.match(chooser, /restoreViewAllFocusRef\.current = true;[\s\S]*setView\("main"\)/);
  assert.match(chooser, /if \(event\.key !== "Escape"\) return;/);
  assert.match(chooser, /aria-pressed=\{filter === value\}/);
  assert.match(chooser, /data-tonconnect-qr-preserved="approved-ui-no-separate-runtime-yet"/);
});
