import assert from "node:assert/strict";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";

const frontendRoot = path.resolve(import.meta.dirname, "../..");
const root = path.resolve(frontendRoot, "..");
const manifest = JSON.parse(fs.readFileSync(path.join(import.meta.dirname, "admin-freeze-manifest.json"), "utf8"));
const sha = (p) => crypto.createHash("sha256").update(fs.readFileSync(p)).digest("hex");

test("OWNER Admin visual components remain byte-exact; technical fixes are allowed", () => {
  assert.equal(manifest.schema, "EFHC_CURRENT_ADMIN_VISUAL_FREEZE_V2");
  assert.ok(Object.keys(manifest.files).length > 0, "Admin source provenance must remain");
  assert.equal(manifest.visual_files.length, 5);
  for (const rel of Object.keys(manifest.files)) {
    assert.ok(fs.existsSync(path.join(root, rel)), `missing Admin file: ${rel}`);
  }
  for (const rel of manifest.visual_files) {
    assert.ok(Object.hasOwn(manifest.files, rel), `missing approved visual hash: ${rel}`);
    assert.equal(sha(path.join(root, rel)), manifest.files[rel], `Admin visual freeze violation: ${rel}`);
  }
});
