import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";

const frontendRoot = path.resolve(import.meta.dirname, "../..");
const root = path.resolve(frontendRoot, "..");
const read = (relative) => fs.readFileSync(path.join(root, relative), "utf8");
const version = read("VERSION").trim();

const navigation = read("frontend/src/hooks/faq/useFaqNavigation.ts");
const page = read("frontend/src/pages/faq.tsx");
const tree = read("frontend/src/components/faq/FaqVerticalTree.tsx");
const accordion = read("frontend/src/components/faq/FaqAccordionList.tsx");
const standalone = read(`${version}.html`);
const faqSsot = read("docs/SSOT/FAQ_SSOT.md");

test("Current production FAQ owns a page-local additive open-question Set", () => {
  assert.match(navigation, /useState<Set<string>>/);
  assert.match(navigation, /const next = new Set\(current\)/);
  assert.match(navigation, /if \(next\.has\(itemId\)\) next\.delete\(itemId\)/);
  assert.match(navigation, /else next\.add\(itemId\)/);
  assert.doesNotMatch(page, /isOpen=\{nav\.openItemId === item\.id\}/);
  assert.match(page, /isOpen=\{nav\.openItemIds\.has\(item\.id\)\}/);
});

test("Current production tree and search results share the same multi-open state", () => {
  assert.match(tree, /openItemIds\?: ReadonlySet<string>/);
  assert.match(tree, /props\.openItemIds\?\.has\(itemId\)/);
  assert.match(tree, /props\.onToggleQuestion\(itemId\)/);
  assert.match(page, /open=\{nav\.openItemIds\.has\(hit\.item\.id\)\}/);
  assert.match(page, /nav\.toggleQuestion\(hit\.item\.id\)/);
  assert.match(accordion, /openItemIds: ReadonlySet<string>/);
  assert.match(accordion, /isOpen=\{props\.openItemIds\.has\(item\.id\)\}/);
});

test("Current production URL item remains compatible without becoming singleton ownership", () => {
  assert.match(navigation, /if \(openItemId\) \{[\s\S]*next\.add\(openItemId\)/);
  assert.match(navigation, /openItemId: isOpen && state\.openItemId === itemId/);
  assert.match(navigation, /: isOpen[\s\S]*\? state\.openItemId[\s\S]*: itemId/);
});

test("Current standalone FAQ preserves multiple open questions across rerender/search/language", () => {
  assert.match(standalone, /const faqOpenQuestionIds=new Set\(\)/);
  assert.match(standalone, /faqOpenQuestionIds\.has\(String\(itemId\)\)/);
  assert.match(standalone, /isFaqQuestionOpen\(item\.id\)\?'open':''/);
  assert.match(standalone, /isFaqQuestionOpen\(hit\.item\.id\)\?'open':''/);
  assert.match(standalone, /if\(details\.open\)faqOpenQuestionIds\.delete\(itemId\);else faqOpenQuestionIds\.add\(itemId\)/);
});

test("Current standalone FAQ resets open state only when the FAQ page is left", () => {
  assert.match(
    standalone,
    /page\?\.id==='faqPage'&&page\.hidden\)\{faqOpenQuestionIds\.clear\(\);faqSection='';faqSubsection='';\}/,
  );
  assert.match(standalone, /if\(!\$\('#faqPage'\)\?\.hidden\)renderFaq\(\)/);
});

test("Current FAQ SSOT records the multi-open no-self-close boundary", () => {
  assert.match(faqSsot, /FAQ question expansion is \*\*multi-open\*\*/);
  assert.match(faqSsot, /closes \*\*only that question\*\*/);
  assert.match(faqSsot, /search activation\/clear and runtime language changes must preserve/);
  assert.match(faqSsot, /Leaving the FAQ page resets the page-local open set/);
  assert.match(faqSsot, /Production React and standalone must preserve these semantics in parity/);
});
