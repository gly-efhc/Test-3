import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
const root=resolve(import.meta.dirname,'../../..');
const read=path=>readFileSync(resolve(root,path),'utf8');
const names=readdirSync(root).filter(x=>/^FRONTEND_v\d+\.html$/.test(x));
assert.equal(names.length,1);
const html=read(names[0]);
const chrome=read('frontend/src/styles/referrals-social-brand-contract.css');
const global=read('frontend/src/styles/globals.css');
const coverage=read('frontend/src/styles/global-theme-owner-coverage.css');

test('0561 owner dark sheet and CT01..CT10 standalone palette preserve all ten independent accents',()=>{
 assert.match(html,/#standaloneDirectDepositV218 .standalone-settings-dialog\{border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.30\)!important;background:#101319!important;/);
 for(let n=1;n<=10;n++){
  const id=`CT-${String(n).padStart(2,'0')}`;
  assert.match(html,new RegExp(`data-color-theme-id="${id}"\\] #standaloneDirectDepositV218\\{--efhc-ct-accent-rgb:`));
 }
 assert.match(html,/#standaloneDirectDepositV218 :is\(\.standalone-settings-dialog,input,\.standalone-direct-deposit-v218_summary\)\{\s*border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.30\)!important;/);
 assert.match(html,/#standaloneDirectDepositV218 input:focus-visible\{border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.40\)!important;/);
 assert.match(html,/#standaloneDirectDepositV218 input\{border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.30\)!important;background:rgba\(var\(--efhc-ct-accent-rgb\),\.035\)!important;/);
 assert.match(html,/#standaloneDirectDepositV218 \[data-direct-deposit-close-v218\]\{background:rgba\(var\(--efhc-ct-accent-rgb\),\.035\)!important;/);
});

test('0561 React direct deposit amount/header/dividers and close button track CT; sheet stays dark',()=>{
 assert.match(chrome,/OWNER Cycle0561/);
 assert.match(chrome,/\.efhc-direct-deposit_summary\)\{\s*border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.28\)!important;/);
 assert.match(chrome,/\.efhc-direct-deposit_amount-control:focus-within\{\s*border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.40\)!important;/);
 assert.match(global,/\.efhc-user-direct-deposit-portal\[data-color-theme-id\] \.efhc-modal-sheet\{background:#101319!important;/);
 assert.match(global,/\.efhc-direct-deposit_amount-control\{background:rgba\(var\(--efhc-ct-accent-rgb\),\.035\)!important;background-image:none!important;border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.28\)!important;/);
 assert.match(coverage,/\.efhc-modal-close\{\s*border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.30\)!important;\s*background:rgba\(var\(--efhc-ct-accent-rgb\),\.035\)!important;/);
 for(let n=1;n<=10;n++) assert.match(global,new RegExp(`\\.efhc-user-direct-deposit-portal\\[data-color-theme-id="CT-${String(n).padStart(2,'0')}"\\]\\{`));
});

test('0561 deposit amount, preview, recipient and action hooks are unchanged',()=>{
 const modal=read('frontend/src/components/DepositModal.tsx');
 assert.match(modal,/data-direct-deposit-amount="efhc-jetton"/);
 assert.match(modal,/data-direct-deposit-credit-preview="true"/);
 assert.match(modal,/data-direct-deposit-action="send-efhc-jetton"/);
 assert.match(modal,/data-direct-deposit-action="cancel"/);
 assert.match(html,/id="standaloneDirectDepositAmountV218"[^>]*value="100\.00000000"/);
 assert.match(html,/id="standaloneDirectDepositCreditV218">100\.00000000 EFHCm/);
 assert.match(html,/standaloneShopPositiveD8\(String\(input\?\.value\|\|''\)/);
 assert.match(html,/\[data-direct-deposit-send-v218\]/);
});
