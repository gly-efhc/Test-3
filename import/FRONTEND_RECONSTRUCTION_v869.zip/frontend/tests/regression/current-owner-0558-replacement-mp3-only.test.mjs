import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync, readdirSync} from 'node:fs';
import {resolve} from 'node:path';
const root=resolve(import.meta.dirname,'../../..');
const read=(p)=>readFileSync(resolve(root,p),'utf8');
const audio=readFileSync(resolve(root,'frontend/public/audio/background/1.mp3'));
const current=readdirSync(root).filter(f=>/^FRONTEND_v\d+\.html$/.test(f));
assert.equal(current.length,1);
const frontend=read(current[0]);
const controller=read('frontend/src/components/BackgroundMusicController.tsx');
const generator=read('frontend/scripts/generate-background-playlist.mjs');
const publishedDir=resolve(root,'frontend/public/audio/background');

test('OWNER 0558: exact converted replacement, not old 28s track or unsupported OGG',()=>{
  assert.equal(createHash('sha256').update(audio).digest('hex'),'c23bfadc0eb96f788abf3687b053a962fdd0a5ce024fb1e5c23e7b416fff307f');
  assert.ok(audio.byteLength>650_000 && audio.byteLength<800_000,'compact 58-second MP3 must be real and smaller than v858');
  assert.ok(audio.subarray(0,3).toString()==='ID3'||(audio[0]===0xff&&(audio[1]&0xe0)===0xe0));
  assert.deepEqual(JSON.parse(read('frontend/public/audio/background/playlist.json')),['1.mp3']);
  assert.deepEqual(readdirSync(publishedDir).filter(n=>/\.(mp3|ogg|m4a)$/i.test(n)),['1.mp3']);
  assert.ok(frontend.includes("const trackData='data:audio/mpeg;base64,"+audio.toString('base64')+"';"),'Standalone must embed exactly the compact MP3');
  assert.doesNotMatch(frontend,/data:audio\/(ogg|mp4);base64,/);
});

test('OWNER 0558: single compatible MP3, opt-in Web Audio loop and full cleanup',()=>{
  assert.match(controller,/if \(!enabled \|\| typeof window === "undefined"\) return/);
  assert.match(controller,/fetch\("\/audio\/background\/1\.mp3"/);
  assert.match(controller,/context\.decodeAudioData\(bytes\)/);
  assert.match(controller,/source\.loop = true/);
  assert.match(controller,/source\.stop\(\)/);
  assert.match(controller,/context\.close\(\)/);
  assert.match(generator,/mp3/);
  assert.doesNotMatch(controller,/new Audio\(|mp3\|ogg\|m4a/);
  const standalone=frontend.slice(frontend.lastIndexOf('/* OWNER 0558 iteration 02: gapless opt-in'));
  assert.match(standalone,/source\.loop=true/);
  assert.match(standalone,/ctx\.decodeAudioData\(decodeTrackData\(\)\)/);
  assert.match(standalone,/old\.close\(\)/);
  assert.doesNotMatch(standalone,/new Audio\(|fetch\(/);
});
