import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const read=relative=>fs.readFileSync(path.join(root,relative),'utf8');
const langs=['ru','en','uk','de','fr','es','it','pt','tr','pl','da','id','hi','sw','ko','ja'];
const standalone=(prefix)=>{
  const filenames=fs.readdirSync(root).filter(f=>new RegExp(`^${prefix}_v\\d+\\.html$`).test(f));
  assert.equal(filenames.length,1,`exactly one current ${prefix} HTML`);
  return read(filenames[0]);
};
const embedded=(text,id)=>JSON.parse(text.match(new RegExp(`<script id="${id}" type="application/json">([\\s\\S]*?)<\\/script>`))?.[1]??'null');

// A page-level color theme must win over Telegram-blue material for inactive and active controls.
test('Profile CT material controls buttons and expanded language carousel in both renderers',()=>{
 const css=read('frontend/src/styles/owner-0553-profile-ct.css');
 const app=read('frontend/src/pages/_app.tsx');
 const html=standalone('FRONTEND');
 assert.match(app,/owner-0553-profile-ct\.css/);
 for(const cls of ['efhc-profile-tabs','efhc-compact-language-picker_menu']) assert.ok(css.includes(cls),cls);
 for(const cls of ['source-profile-tabs','source-profile-language-menu']) assert.ok(html.includes(`:is(.${cls}`)||html.includes(` .${cls}`)||html.includes(`,.${cls}`),cls);
 assert.match(css,/data-interface-app-mode="user"/);
 assert.match(css,/aria-selected="true"/);
 assert.match(html,/rgba\(var\(--efhc-ct-accent-rgb\),\.18\)/);
});

test('Permanent Hub Shop label is native in all 16 source and embedded locale catalogs',()=>{
 const labels={ru:'Магазин',en:'Shop',uk:'Крамниця',de:'Geschäft',fr:'Boutique',es:'Tienda',it:'Negozio',pt:'Loja',tr:'Mağaza',pl:'Sklep',da:'Butik',id:'Toko',hi:'दुकान',sw:'Duka',ko:'상점',ja:'ショップ'};
 const embeddedLocales=embedded(standalone('FRONTEND'),'efhcFullLocales');
 for(const lang of langs){
  const data=JSON.parse(read(`frontend/public/locale/${lang}.json`));
  assert.equal(data['hub.action_shop'],labels[lang],lang);
  assert.equal(embeddedLocales[lang]['hub.action_shop'],labels[lang],lang+' standalone');
 }
 const hub=read('frontend/src/features/hub/HubPage.tsx');
 assert.match(hub,/const fixed = \["efhc_buy", "vip_getgems", "efhc_ceo", "efhc_admin"\]/);
 assert.match(hub,/const rows = publicLinks\.data \?\? \[\]/);
 assert.match(hub,/shop \? t\("hub.action_shop"\)/);
});

test('FAQ questions and answers in all 16 embedded and source catalogs have no literal WebApp',()=>{
 const faqs=embedded(standalone('FRONTEND'),'efhcFullFaqs');
 for(const lang of langs){
  const docs=[faqs[lang],JSON.parse(read(`frontend/public/faq/${lang}.json`)),JSON.parse(read(`docs/SSOT/faq_ssot/${lang}/faq_${lang}.json`))];
  for(const doc of docs) assert.doesNotMatch(JSON.stringify(doc),/WebApp/u,lang);
 }
 assert.match(JSON.stringify(faqs.ja),/アプリ/u);
 assert.match(JSON.stringify(faqs.ko),/앱/u);
});

test('All 16 Shop locale sources define dedicated static technical descriptions, React and Shop use them',()=>{
 const react=read('frontend/src/features/browser-shop/BrowserShopPage.tsx');
 const html=standalone('SHOP');
 const locales=embedded(standalone('FRONTEND'),'efhcFullLocales');
 const keys=['custom_exchange_title','custom_exchange_detail','custom_amount_placeholder','custom_amount_aria','custom_rate_label','custom_total_label','order_id_label','tx_hash_label','custom_minimum_error','intent_expired_error','unsupported_route_error','operation_failed_error'];
 for(const lang of langs){
  const json=JSON.parse(read(`frontend/public/locale/${lang}.json`));
  for(const key of keys){
   const full=`portal.browser_shop.${key}`;
   assert.ok(json[full],`${lang} ${full}`);
   assert.equal(locales[lang][full],json[full],`standalone portal ${lang} ${full}`);
  }
 }
 for(const key of keys.slice(0,8)) assert.match(react,new RegExp('portal\\.browser_shop\\.'+key));
 for(const key of keys) assert.ok(html.includes(key),key+' standalone');
 assert.match(html,/OWNER_0553_SHOP_I18N/);
 assert.match(html,/tr\('custom_total_label'\)/);
 assert.match(html,/tr\('order_id_label'\)/);
 assert.match(react,/type PayMethod = "TON" \| "USDT" \| "EFHC"/);
});

test('Profile language carousel preserves geometry/CT menu and uses only CT-colored check on selected option', () => {
  const css = read('frontend/src/styles/owner-0553-profile-ct.css');
  const html = standalone('FRONTEND');
  const block = html.split('/* OWNER Cycle0553: standalone Profile buttons and language carousel follow CT, not legacy blue. */')[1]?.split('</style>')[0];
  assert.ok(block, 'standalone profile CT scope is present');
  assert.match(css, /\.efhc-profile-page \.efhc-compact-language-picker_menu\s*\{/);
  assert.match(css, /background-color:color-mix\(in srgb,var\(--efhc-ct-accent\) 5%,#050508\)!important/);
  assert.match(css, /\.efhc-profile-page \.efhc-compact-language-picker_option\[data-active="true"\]/);
  assert.match(css, /border-color:transparent!important;[\s\S]*?background:transparent!important;/);
  assert.match(css, /color:var\(--efhc-ct-accent\)!important;/);
  assert.match(block, /\.source-profile-settings-card button:not\(\.source-profile-language-button\):not\(\.source-profile-language-option\)/, 'general profile button rule must exclude carousel');
  assert.match(block, /\.source-profile-language-menu\s*\{[^}]*background-color:color-mix/s);
  assert.match(block, /\.source-profile-language-option\[data-active="true"\]\s*\{/);
  assert.match(block, /border-color:transparent!important;[\s\S]*?background:transparent!important;/);
  assert.match(block, /color:var\(--efhc-ct-accent\)!important;/);
  assert.doesNotMatch(block, /\.source-profile-language-menu\s*\{[^}]*border-color/s, 'menu border remains historical');
});

test('The restored carousel keeps two columns, scroll, flags, original keyboard interaction', () => {
  const globals = read('frontend/src/styles/globals.css');
  const picker = read('frontend/src/components/profile/CompactLanguagePicker.tsx');
  const html = standalone('FRONTEND');
  assert.match(globals, /\.efhc-compact-language-picker_menu\s*\{[^}]*grid-template-columns:repeat\(2,minmax\(0,1fr\)\)/s);
  assert.match(html, /\.source-profile-language-menu\{[^}]*grid-template-columns:repeat\(2,minmax\(0,1fr\)\)/s);
  assert.match(globals, /\.efhc-compact-language-picker_menu\s*\{[^}]*overflow:auto/s);
  assert.match(html, /\.source-profile-language-menu\{[^}]*overflow:auto/s);
  for(const key of ['ArrowDown','ArrowUp','Escape','Enter']) assert.ok(picker.includes(key), key);
  for(const token of ['source-profile-language-option','profileLanguageFocusIndex','standaloneProfileLanguageKeydown']) assert.ok(html.includes(token),token);
});
