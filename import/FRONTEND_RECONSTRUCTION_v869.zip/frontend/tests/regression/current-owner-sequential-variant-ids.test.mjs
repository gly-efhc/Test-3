import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { createRequire } from 'node:module';
import vm from 'node:vm';
import { resolve } from 'node:path';
const require = createRequire(import.meta.url);
const ts = require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');
const base = resolve(import.meta.dirname, '../../..');
const source = (path) => readFileSync(resolve(base, path), 'utf8');
const htmlNames = readdirSync(base).filter(name => /^FRONTEND_v\d+\.html$/.test(name));
assert.equal(htmlNames.length, 1, 'one release HTML in root');
const h = source(htmlNames[0]);
const registrySource = source('frontend/src/lib/interfaceVariantRegistry.ts');
const exported = {};
const compiled = ts.transpileModule(registrySource, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 } }).outputText;
vm.runInNewContext(compiled, { exports: exported, require });
const { INTERFACE_VARIANT_REGISTRY: active, INTERFACE_VARIANT_STYLE_BINDINGS: styles, DEFAULT_INTERFACE_VARIANTS: defaults, normalizeInterfaceVariant, resolveInterfaceVariantStyle } = exported;

test('OWNER 0546: all 29 selection catalogs are consecutive 01..N without holes or duplicate IDs', () => {
  assert.equal(Object.keys(active).length, 29);
  for (const [group, ids] of Object.entries(active)) {
    assert.ok(ids.length > 0, group);
    assert.deepEqual([...ids], group==='EI'?['EI-07']:Array.from({ length: ids.length }, (_, i) => `${group}-${String(i + 1).padStart(2, '0')}`));
    assert.equal(defaults[group], ids[0]);
    assert.equal(new Set(ids).size, ids.length, group);
    assert.deepEqual(Object.keys(styles[group]), [...ids].filter(id=>styles[group][id] && styles[group][id]!==id));
    for (const id of ids) assert.equal(resolveInterfaceVariantStyle(group, id), styles[group][id] || id);
  }
});

test('OWNER 0546: reordered selections keep exact authored CSS styles without inferring old persisted IDs', () => {
  for (const [g, old, id] of [['HS', 'HS-03', 'HS-01'], ['HS', 'HS-13', 'HS-06'], ['FQ', 'FQ-13', 'FQ-06'], ['TG', 'TG-09', 'TG-04'], ['HI', 'HI-04', 'HI-03'], ['WD', 'WD-13', 'WD-05'], ['PT','PT-10','PT-04'], ['PC','PC-10','PC-09'], ['RP','PB-35','RP-33']]) {
    assert.equal(styles[g][id], old, `${g}: ${id} must preserve ${old}`);
  }
  assert.equal(normalizeInterfaceVariant('HS', 'HS-13'), 'HS-01');
  assert.equal(normalizeInterfaceVariant('FQ', 'FQ-13'), 'FQ-01');
  assert.equal(normalizeInterfaceVariant('RP', 'PB-35'), 'RP-01');
});

test('OWNER 0546: standalone source catalog and CSS style map match React for all 29 groups', () => {
  const r = /const REGISTRY = Object\.freeze\((\{[^\n]*\})\);/.exec(h);
  const sm = /const SOURCE_STYLE = Object\.freeze\((\{[^\n]*\})\);/.exec(h);
  assert.ok(r && sm, 'canonical standalone catalogs required');
  const rj = JSON.parse(r[1]), sj = JSON.parse(sm[1]);
  for (const group of Object.keys(active)) {
    assert.deepEqual(rj[group], [...active[group]]);
    assert.deepEqual(sj[group], JSON.parse(JSON.stringify(styles[group])));
  }
});

test('OWNER 0546: old preferences reset, CT is independent, no retired aliases re-activate', () => {
  const s = source('frontend/src/lib/settings.ts');
  assert.match(s, /resetRetiredSelections\s*=\s*parsed\.interface_settings_version\s*===\s*1/);
  assert.match(s, /resetRetiredSelections\s*\?\s*\{\s*\.\.\.DEFAULT_INTERFACE_VARIANTS\s*\}/);
  assert.match(s, /const colorThemeId = normalizeColorThemeId\(source\.color_theme_id\)/);
  assert.match(h, /!\[2,3,4\]\.includes\(raw\.interface_settings_version\)/);
  assert.doesNotMatch(registrySource, /OWNER_RETIRED_VARIANT_ALIASES|LEGACY_VALUE_MAP/);
});

test('OWNER 0546: FQ-01 and FQ-05 CT borders; upper corner decorative glow has USER-only scope', () => {
  const css = source('frontend/src/styles/global-theme-owner-0544.css');
  for (const id of ['FQ-01','FQ-05']) {
    assert.match(css, new RegExp(`data-fq="${id}"`));
    assert.match(h, new RegExp(`data-fq="${id}"`));
  }
  assert.match(css, /border-top-color:rgba\(var\(--efhc-ct-accent-rgb\),\.40\)!important/);
  assert.match(css, /\[data-interface-app-mode="user"\]/);
  assert.match(h, /id="owner0546-faq-corner-glow"/);
  assert.doesNotMatch(css.slice(css.indexOf('OWNER 0546')), /\[data-interface-app-mode="admin"\]/);
});

test('OWNER 0547: all seven Energy icon selections resolve to authored markup in standalone', () => {
  const snippet = h.match(/const ICONS = Object\.freeze\(\{([\s\S]*?)\n  \}\);/);
  assert.ok(snippet, 'Energy SVG source map must be present');
  const ids = [...snippet[1].matchAll(/^\s*'(EI-\d\d)':`/gm)].map(match => match[1]);
  assert.deepEqual(ids.slice().sort(), [...active.EI].sort(), 'every EI selection has exactly one SVG/image entry');
  const styleIds = [...active.EI].map(id => styles.EI[id] || id);
  for (const id of styleIds) {
    assert.ok(ids.includes(id), `${id} must render, not become undefined`);
  }
  assert.match(h, /\$\('#energyIcon'\)\.innerHTML=ICONS\[styleOf\('EI',v\.EI\)\]/);
  assert.match(h, /<div class="efhc-energy-stage_coin" data-ei="EI-07" id="energyIcon"><\/div>/);
  assert.deepEqual(ids,['EI-07']);
});

test('OWNER 0548: only EI-07 retains identical authored lightning SVG in React/standalone', () => {
  const react=source('frontend/src/components/icons/EnergyVariantIcon.tsx');
  const svgPath='m13 4.5-5 7.4h3.4l-.6 7.6 5.2-7.5h-3.5l.5-7.5Z';
  assert.ok(react.includes(svgPath));
  assert.ok(h.includes(svgPath));
  assert.deepEqual([...active.EI], ['EI-07']);
  assert.doesNotMatch(h,/data-swipe-group="EI"/);
  assert.match(h,/data-energy-fixed-icon="EI-07"/);
});
