import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root=path.resolve(import.meta.dirname,'../../..');
const read=(file)=>fs.readFileSync(path.join(root,file),'utf8');
const registry=read('frontend/src/lib/interfaceVariantRegistry.ts');
const standalone=read(read('VERSION').trim()+'.html');
const adapter=read('frontend/src/styles/referrals-social-brand-contract.css');
const globals=read('frontend/src/styles/globals.css');
const active={
 PT:['PT-01','PT-02','PT-03','PT-04','PT-05'],
 PC:['PC-01','PC-02','PC-03','PC-04','PC-05','PC-06','PC-07','PC-08','PC-09'],
 WD:['WD-01','WD-02','WD-03','WD-04','WD-05'],
};
const retired={
 PT:['PT-04','PT-05','PT-06','PT-07','PT-08','PT-12'],
 PC:['PC-11','PC-12'],
 WD:['WD-03','WD-04','WD-05','WD-07','WD-08','WD-09','WD-11','WD-12'],
};
function parsedStandalone(pattern){const found=standalone.match(pattern);assert.ok(found);return JSON.parse(found[1]);}

test('only OWNER-approved PT PC WD active choices remain in both authorities',()=>{
 const standaloneRegistry=parsedStandalone(/const REGISTRY = Object\.freeze\((\{[^\n]+\})\);/);
 for(const [group,values] of Object.entries(active)){
   assert.deepEqual(standaloneRegistry[group],values,group);
   assert.match(registry,new RegExp(`${group}: numbered\\("${group}", ${values.length}\\)`));
 }
});
test('saved retired variant aliases are absent and normalization resolves only active IDs',()=>{
 assert.doesNotMatch(standalone,/const OWNER_RETIRED_VARIANT_ALIASES/);
 assert.doesNotMatch(registry,/OWNER_RETIRED_VARIANT_ALIASES/);
 assert.match(registry,/return allowed\.includes\(raw\) \? raw : DEFAULT_INTERFACE_VARIANTS\[group\]/);
 assert.match(standalone,/const SOURCE_STYLE = Object\.freeze/);
});

test('design-specific chroma corrections use 10 Color Theme tokens with CT03 visual freeze',()=>{
 for(const value of ['data-pa="PA-04"','data-tg="TG-09"','data-kg="KG-02"','data-ranks-refresh-action','data-ranks-show-me-action','efhc-withdraw-requests-history']){
  assert.ok(adapter.includes(value),value);
 }
 assert.match(adapter,/data-color-theme-id="CT-03"/);
 assert.match(adapter,/--efhc-ct-accent-rgb/);
 assert.match(globals,/TG-09: design layer|TG-09 design layer/);
 assert.match(standalone,/#rankRefresh,#findMyRank/);
 assert.match(standalone,/standalone-withdraw-request-filters \.efhc-history-filter--active/);
});
