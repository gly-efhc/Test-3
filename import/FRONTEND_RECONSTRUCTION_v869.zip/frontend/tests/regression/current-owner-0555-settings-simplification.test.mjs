import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'../../..');
const read=(p)=>fs.readFileSync(path.join(root,p),'utf8');
const htmlFile=fs.readdirSync(root).filter(n=>/^FRONTEND_v\d+\.html$/.test(n));
assert.equal(htmlFile.length,1);
const html=read(htmlFile[0]);
const react=read('frontend/src/components/ProfileModal.tsx');
const settings=read('frontend/src/lib/settings.ts');
const editor=read('frontend/src/components/profile/AvatarPreferenceEditor.tsx');
const music=read('frontend/src/components/BackgroundMusicController.tsx');
const settingMarkup=html.split('id="profileSettingsOverlay"')[1]?.split('id="profileAvatarOverlay"')[0]||'';
const keys=['reduce_motion','sfx_enabled','haptics_enabled','music_enabled'];

test('settings standalone has exactly four active controls and no nested menu',()=>{
 assert.equal((settingMarkup.match(/data-setting="/g)||[]).length,4);
 assert.doesNotMatch(settingMarkup,/data-setting="show_decimal_detail"/);
 for(const key of keys) assert.match(settingMarkup,new RegExp(`data-setting="${key}"`));
 assert.doesNotMatch(settingMarkup,/<details\b/);
 assert.doesNotMatch(settingMarkup,/standalone-avatar-settings/);
});
test('avatar editor is on avatar click, outside Settings, retains direct image preview and save',()=>{
 assert.match(html,/id="profileAvatarOverlay"/);
 assert.match(html,/id="standaloneAvatarUrlInput"/);
 assert.match(html,/id="standaloneAvatarCheckUrl"/);
 assert.match(html,/id="standaloneAvatarSaveUrl"/);
 assert.match(html,/\$\('#standaloneProfileAvatar'\).*profileAvatarOverlay/);
 assert.match(react,/data-profile-avatar-edit-trigger="true"/);
 assert.match(react,/<AvatarPreferenceEditor\s*\/>/);
 assert.match(react,/open=\{avatarEditorOpen && props.open\}/);
 assert.match(editor,/source.status === "available"/);
 assert.match(editor,/normalizeAvatarHttpsUrl\(draftUrl\)/);
});
test('React settings: four flat toggles, no rendered disclosures; carousel untouched',()=>{
 const view=react.split('<SectionCard title={t("profile.interface_title")}>')[1].split('{props.isAdmin ? (')[0];
 for(const key of keys) assert.match(view,new RegExp(`checked=\\{props.settings.${key}\\}`));
 assert.equal((view.match(/<ToggleRow\b/g)||[]).length,4);
 assert.doesNotMatch(view,/<SettingsDisclosure/);
 assert.match(view,/<CompactLanguagePicker\b/);
});
test('removed settings remain in persistence model without changing safety defaults',()=>{
 for(const key of ['confirm_actions','confirm_purchase','confirm_withdraw','confirm_convert','confirm_watch_ad','toasts_enabled','important_alerts_only']) assert.match(settings,new RegExp(`${key}:`));
 assert.match(settings,/music_enabled: false/);
 assert.match(settings,/music_enabled: boolean/);
});
test('opt-in music: no fetch when disabled, stop and unload; numeric tracks',()=>{
 assert.match(music,/if \(!enabled \|\| typeof window/);
 assert.match(music,/controller\.abort\(\)/);
 assert.match(music,/source\.stop\(\)/);
 assert.match(music,/context\.close\(\)/);
 assert.match(music,/context\.decodeAudioData\(bytes\)/);
 assert.ok(fs.existsSync(path.join(root,'frontend/public/audio/background/playlist.json')));
 assert.deepEqual(JSON.parse(read('frontend/public/audio/background/playlist.json')),['1.mp3']);
 assert.match(music,/source\.loop = true/);
});
