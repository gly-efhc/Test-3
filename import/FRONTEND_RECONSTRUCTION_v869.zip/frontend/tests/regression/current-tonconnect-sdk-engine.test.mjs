import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import { createRequire } from "node:module";

const repoRoot = path.resolve(import.meta.dirname, "../../..");
const read = (relativePath) => fs.readFileSync(path.join(repoRoot, relativePath), "utf8");
const packageJson = JSON.parse(read("frontend/package.json"));
const packageLock = JSON.parse(read("frontend/package-lock.json"));
const compat = read("frontend/src/lib/vendor/tonconnect-ui-react-compat.tsx");
const tonconnect = read("frontend/src/lib/tonconnect.ts");
const adapter = read("frontend/src/lib/wallet-provider/adapters/TonConnectAdapter.ts");
const routing = read("frontend/src/lib/wallet-provider/primaryWalletRouting.ts");
const chooser = read("frontend/src/components/wallet/TonConnectWalletChooser.tsx");
const engine = read("ops/dependencies/update_tonconnect_sdk.py");

const sdkLock = packageLock.packages["node_modules/@tonconnect/sdk"];
const protocolLock = packageLock.packages["node_modules/@tonconnect/protocol"];

test("Current keeps the exact OWNER-approved @tonconnect/sdk 5.0.0 pin", () => {
  const sdkVersion = packageJson.dependencies["@tonconnect/sdk"];
  assert.equal(sdkVersion, "5.0.0");
  assert.equal(packageLock.packages[""].dependencies["@tonconnect/sdk"], "5.0.0");
  assert.equal(sdkLock.version, "5.0.0");
  assert.equal(
    sdkLock.resolved,
    `https://registry.npmjs.org/@tonconnect/sdk/-/sdk-${sdkVersion}.tgz`,
  );
  assert.match(sdkLock.integrity, /^sha512-/);
  const protocolVersion = sdkLock.dependencies["@tonconnect/protocol"];
  assert.match(protocolVersion, /^\d+\.\d+\.\d+$/);
  assert.equal(protocolLock.version, protocolVersion);
  assert.match(protocolLock.integrity, /^sha512-/);
});

test("Current keeps the current headless SDK execution chain and disables SDK telemetry", async () => {
  assert.match(compat, /import\("@tonconnect\/sdk"\)/);
  assert.match(compat, /new sdk\.TonConnect\(\{/);
  assert.match(compat, /analytics:\s*\{\s*mode:\s*"off"\s*\}/);
  assert.match(compat, /\.restoreConnection\(\)/);
  assert.match(compat, /\.getWallets\(\)/);
  assert.match(compat, /connector\.onStatusChange/);
  assert.match(compat, /\.disconnect\(\)/);
  assert.match(compat, /this\.connector\.connect\(/);
  assert.match(adapter, /fetchTonConnectWallets\(ui\)/);
  assert.match(adapter, /ui\.connectWallet\(wallet\.walletKey\)/);

  const installedSdkPackage = path.join(repoRoot, "frontend/node_modules/@tonconnect/sdk/package.json");
  if (!fs.existsSync(installedSdkPackage)) {
    return;
  }

  // Exercise the installed exact pin when dependencies are materialized; physical release archives intentionally omit node_modules.
  const originalWindow = globalThis.window;
  const originalFetch = globalThis.fetch;
  try {
    const bank = "UQAyCoxmxzb2D6cmlf4M8zWYFYkaQuHbN_dgH-IfraFP8QKW";
    const store = new Map();
    const storage = {
      getItem: async (key) => store.get(key) ?? null,
      setItem: async (key, value) => { store.set(key, value); },
      removeItem: async (key) => { store.delete(key); },
    };
    const event = {
      event: "connect", id: 1,
      payload: {
        items: [{name: "ton_addr", address: "0:" + "11".repeat(32), network: "-239",
          publicKey: "22".repeat(32), walletStateInit: "fixture-boc"}],
        device: {platform: "browser", appName: "fixture", appVersion: "1",
          maxProtocolVersion: 3, features: [{name: "SendTransaction", maxMessages: 4}]},
      },
    };
    let listener = null, reject = false, sends = 0;
    globalThis.window = new EventTarget();
    window.fixtureWallet = {tonconnect: {
      walletInfo: {name: "Fixture", app_name: "fixture", image: "https://example.invalid/icon.png",
        about_url: "https://example.invalid", platforms: ["browser"]},
      isWalletBrowser: false,
      connect: async (version, request) => {
        assert.equal(version, 2); // npm protocol package 3.0.0 retains wire version 2.
        assert.equal(request.items[1].payload, "fixture-proof");
        return event;
      },
      listen: (cb) => { listener = cb; return () => { listener = null; }; },
      send: async (rpc) => {
        sends++;
        assert.equal(rpc.method, "sendTransaction");
        const request = JSON.parse(rpc.params[0]);
        assert.equal(request.network, "-239");
        assert.deepEqual(request.messages, [{address: bank, amount: "1"}]);
        return reject ? {id: rpc.id, error: {code: 300, message: "User declined"}}
          : {id: rpc.id, result: "fixture-signed-boc"};
      },
      restoreConnection: async () => event,
      disconnect: () => {},
    }};
    globalThis.fetch = async (url) => {
      assert.equal(url, "https://example.invalid/wallets.json");
      return {json: async () => [{...window.fixtureWallet.tonconnect.walletInfo,
        bridge: [{type: "js", key: "fixtureWallet"}]}]};
    };
    const {TonConnect, UserRejectsError, WalletWrongNetworkError} = createRequire(import.meta.url)("@tonconnect/sdk");
    const connector = new TonConnect({manifestUrl: "https://example.invalid/tonconnect-manifest.json",
      walletsListSource: "https://example.invalid/wallets.json", analytics: {mode: "off"}, storage});
    assert.ok((await connector.getWallets()).some((wallet) => wallet.jsBridgeKey === "fixtureWallet"));
    await connector.restoreConnection();
    assert.equal(connector.connected, false);
    const connected = new Promise((resolve, reject) => connector.onStatusChange((wallet) => {
      if (wallet) resolve(wallet);
    }, reject));
    assert.equal(connector.connect({jsBridgeKey: "fixtureWallet"}, {request: {tonProof: "fixture-proof"}}), undefined);
    await connected;
    assert.equal(connector.wallet.account.chain, "-239");
    const tx = {validUntil: Math.floor(Date.now() / 1000) + 300, network: "-239",
      messages: [{address: bank, amount: "1"}]};
    const result = {boc: "fixture-signed-boc", traceId: undefined};
    assert.deepEqual(await connector.sendTransaction(tx), result);
    assert.equal(sends, 1);
    await assert.rejects(connector.sendTransaction({...tx, network: "-3"}), WalletWrongNetworkError);
    assert.equal(sends, 1, "network mismatch must fail before provider handoff");
    reject = true;
    await assert.rejects(connector.sendTransaction(tx), UserRejectsError);
    reject = false;
    assert.deepEqual(await connector.sendTransaction(tx), result);
    await connector.disconnect();
    assert.equal(connector.connected, false);
    assert.equal(listener, null);
  } finally {
    if (originalWindow === undefined) delete globalThis.window;
    else globalThis.window = originalWindow;
    globalThis.fetch = originalFetch;
  }
});

test("Current preserves SDK registry branding authority and protected technical IDs", () => {
  assert.match(tonconnect, /const raw = await tonConnectUI\.getWallets\(\)/);
  assert.match(tonconnect, /item\?\.appName/);
  assert.match(tonconnect, /item\?\.imageUrl/);
  assert.match(tonconnect, /item\?\.universalLink/);
  assert.match(chooser, /data-tonconnect-registry-source="@tonconnect\/sdk\.getWallets"/);
  assert.doesNotMatch(chooser, /tonConnectFirstBindRegistry/);
  assert.match(chooser, /"tonkeeper"/);
  assert.match(chooser, /"mytonwallet"/);
  assert.match(chooser, /"gramwallet"/);
  assert.match(routing, /normalized === "mytonwallet" \|\| normalized === "mywallet"/);
});

test("Current update engine queries npm latest but keeps runtime pinned", () => {
  assert.match(engine, /npm.*view/si);
  assert.match(engine, /PACKAGE_NAME = "@tonconnect\/sdk"/);
  assert.match(engine, /--package-lock-only/);
  assert.match(engine, /--save-exact/);
  assert.match(engine, /UPDATE_AVAILABLE/);
  assert.match(engine, /NOOP/);
  assert.match(engine, /refusing downgrade/);
  assert.doesNotMatch(compat, /@latest/);
  assert.doesNotMatch(tonconnect, /@latest/);
});

test("Current promotion is guard-bound and fail-closed", () => {
  assert.match(engine, /guard evidence must have status PASS/);
  assert.match(engine, /guard evidence does not bind to this candidate/);
  assert.match(engine, /live package state changed after candidate preparation/);
  assert.match(engine, /candidate package\/lock hashes changed after preparation/);
  assert.match(engine, /atomic_replace/);
});
