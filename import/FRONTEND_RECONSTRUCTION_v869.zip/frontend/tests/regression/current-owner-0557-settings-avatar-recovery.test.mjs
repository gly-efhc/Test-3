import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '../../..');
const read = (p) => fs.readFileSync(path.join(root,p),'utf8');
const frontendFile=fs.readdirSync(root).find(f=>/^FRONTEND_v\d+\.html$/.test(f));
assert.ok(frontendFile);
const html=read(frontendFile);
const css=read('frontend/src/styles/owner-0556-profile-settings-avatar.css');
const editor=read('frontend/src/components/profile/AvatarPreferenceEditor.tsx');
test('OWNER 0557 settings are a single dark CT-tinted surface, including standalone',()=>{
 assert.match(css,/--efhc-settings-profile-plane:color-mix\(in srgb,#05070b 94%,var\(--efhc-ct-accent\) 6%\)/);
 assert.match(css,/#profileSettingsOverlay \.standalone-settings-dialog/);
 assert.match(css,/#profileSettingsOverlay \.standalone-settings-row::before/);
 assert.match(css, /efhc-profile-modal-theme \.efhc-card:has\(\.efhc-settings-row\)/);
 assert.ok(html.includes(css),'Standalone must embed exactly the bounded CSS source');
});
test('OWNER 0557 avatar editor has only one header, no empty provider section',()=>{
 const block=html.split('id="profileAvatarOverlay"')[1]?.split('id="hubPage"')[0]||'';
 assert.ok(block.includes('id="profileAvatarDialogTitle"'));
 assert.equal((block.match(/data-i18n-key="profile.edit_profile_photo"/g)||[]).length,1);
 assert.doesNotMatch(block,/id="standaloneAvatarSocialEmpty"/);
 assert.match(block,/id="standaloneAvatarSocialHeading"[^>]+hidden/);
 assert.match(html,/socialHeading\.hidden=providers\.length===0/);
 assert.match(html,/social\.hidden=providers\.length===0/);
 assert.doesNotMatch(editor,/avatar_linked_accounts_empty/);
 assert.match(editor,/availablePhotos\.length > 0/);
 assert.doesNotMatch(editor,/profile\.avatar_choose/);
});
test('OWNER 0557 leaves protected carousel and playback activation contract untouched',()=>{
 assert.doesNotMatch(css,/compact-language-picker|source-profile-language-menu/);
 assert.match(html,/if\(key==='music_enabled'\)return/);
 assert.match(html,/if\(!enabled\|\|context\)return/);
});
