import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const frontendRoot = path.resolve(here, "../..");
const root = path.resolve(frontendRoot, "..");
const read = (relative) => fs.readFileSync(path.join(root, relative), "utf8");

const transport = read("frontend/src/lib/referral-start-param.ts");
const telegram = read("frontend/src/lib/telegram-auth.ts");
const telegramService = read("frontend/src/services/authSession.service.ts");
const ton = read("frontend/src/lib/ton-auth.ts");
const provider = read("frontend/src/auth/AuthSessionProvider.tsx");
const frontendSource = [transport, telegram, telegramService, ton, provider].join("\n");

test("current referral transport has no late-bind referral mutation", () => {
  assert.doesNotMatch(frontendSource, /["'`]\/referrals\/(?:bind|attach)["'`]/);
  assert.match(transport, /existingAccountLateBind:\s*false/);
});

test("current first-entry capture is session-only and scrubs referral query keys", () => {
  assert.match(provider, /captureReferralStartParamFromFirstEntry\(\)/);
  assert.match(transport, /const STORAGE_KEY = "efhc\.referral\.start\.v1"/);
  assert.match(transport, /return globalThis\.sessionStorage \?\? null/);
  assert.doesNotMatch(transport, /localStorage/);
  assert.match(transport, /window\.history\.replaceState\(/);
  for (const key of ["referral_start_param", "tgWebAppStartParam", "startapp", "start", "ref"]) {
    assert.ok(transport.includes(`"${key}"`), key);
  }
});

test("current Telegram and TON authentication carry referral_start_param only through auth requests", () => {
  assert.match(telegramService, /["']\/auth\/telegram\/session["']/);
  assert.match(telegramService, /body:\s*referralStartParam === null[\s\S]*referral_start_param:\s*referralStartParam/);
  assert.match(ton, /["']\/auth\/ton\/proof["']/);
  assert.match(ton, /referral_start_param:\s*referralStartParam/);
});

test("current referral transport clears on success and final invalid errors but survives transient failures", () => {
  assert.match(telegram, /acceptIssuedAuthSession\(result\);\s*clearReferralStartParam\(\);/s);
  assert.match(ton, /acceptIssuedAuthSession\(result\);\s*clearReferralStartParam\(\);/s);
  assert.match(transport, /if \(error\.status === 400 \|\| error\.status === 422\) \{\s*clearReferralStartParam\(\);/s);
  assert.match(transport, /if \(reason && finalReasons\.has\(reason\)\) \{\s*clearReferralStartParam\(\);/s);
  assert.doesNotMatch(transport, /status:\s*["']pending["']/);
  assert.doesNotMatch(transport, /status:\s*["']done["']/);
});
