import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const css=fs.readFileSync(new URL("../../src/styles/referrals-social-brand-contract.css",import.meta.url),"utf8");
const contract=JSON.parse(fs.readFileSync(new URL("../../src/design-system/referrals-social-share-brand-contract.json",import.meta.url),"utf8"));
const app=fs.readFileSync(new URL("../../src/pages/_app.tsx",import.meta.url),"utf8");
const version=fs.readFileSync(new URL("../../../VERSION",import.meta.url),"utf8").trim();
const html=fs.readFileSync(new URL(`../../../${version}.html`,import.meta.url),"utf8");

test("Referral social brand identity is global across all thirteen themes",()=>{
  assert.equal(contract.themes.length,13);
  assert.deepEqual(contract.confirmedRegressionThemes,["01","02"]);
  for(const [service,hex] of Object.entries({telegram:"26a5e4",whatsapp:"25d366",viber:"7360f2",facebook:"0866ff"})){
    assert.ok(css.includes(`data-share-kind="${service}"`),service);
    assert.ok(css.toLowerCase().includes(`#${hex}`),hex);
  }
  assert.match(css,/data-share-kind="x"/);
});

test("Brand contract covers production and standalone but never shape geometry",()=>{
  assert.match(css,/data-referral-share-kind/);
  assert.match(css,/data-share-kind/);
  assert.match(css,/:hover,:active,:focus-visible/);
  assert.doesNotMatch(css,/border-radius|width\s*:|height\s*:|padding\s*:|gap\s*:/);
});

test("Brand contract loads after theme-specific corrections and exists in physical HTML",()=>{
  const t1=app.indexOf("theme01-bounded-chroma-corrections.css");
  const t2=app.indexOf("theme02-bounded-chroma-corrections.css");
  const b=app.indexOf("referrals-social-brand-contract.css");
  assert.ok(t1>=0&&t2>t1&&b>t2);
  assert.ok(html.includes("OWNER Referrals social-share brand contract"));
});
