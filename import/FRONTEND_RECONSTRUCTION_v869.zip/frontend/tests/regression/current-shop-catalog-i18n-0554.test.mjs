import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname,'../../..');
const read = p => fs.readFileSync(path.join(root,p),'utf8');
const backend = read('backend/app/services/shop_service.py');
const route = read('backend/app/routes/admin_shop_routes.py');
const hub = read('backend/app/routes/hub_routes.py');
const react = read('frontend/src/features/browser-shop/BrowserShopPage.tsx');
const admin = read('frontend/src/pages/admin/shop.tsx');
const styles = read('frontend/src/styles/owner-0553-profile-ct.css');
const htmlNames = fs.readdirSync(root).filter(name => /^SHOP_v\d+\.html$/.test(name));
assert.equal(htmlNames.length, 1);
const html = read(htmlNames[0]);
const langs = ['en','ru','uk','de','fr','es','it','tr','pl','da','hi','id','sw','pt','ko','ja'];

test('v849 language carousel structure preserved with CT-only material',()=>{
  assert.match(read('frontend/src/components/profile/CompactLanguagePicker.tsx'),/SUPPORTED_LANGS\.map/);
  assert.match(styles,/\-\-efhc-ct-accent/);
  assert.match(styles,/#050508/);
  assert.match(read(fs.readdirSync(root).find(name => /^FRONTEND_v\d+\.html$/.test(name))),/source-profile-language-option\[data-active="true"\]/);
});
test('16 native static Shop descriptions are present and no test-fixture copy is displayed on canonical package slots',()=>{
  for (const lang of langs) {
    const d=JSON.parse(read(`frontend/public/locale/${lang}.json`));
    for (const k of ['coins_title','coins_detail','package_default_subtitle','vip_0000_detail']) {
      assert.ok(d[`portal.browser_shop.${k}`]?.trim(), `${lang}.${k}`);
    }
    assert.match(html,new RegExp(`"${lang}":\\{`));
  }
  assert.match(react,/localized\(item, "description", t\("portal\.browser_shop\.package_default_subtitle"\)\)/);
  assert.match(html,/shopDescription\(item\)/);
  assert.match(html,/translations:row\.translations\|\|\{\}/);
  assert.match(html,/translations:customRow\.translations\|\|\{\}/);
  assert.match(html,/ショップの準備ができました/);
});
test('catalog translations flow Admin to JSONB to public response and validated TS storefront',()=>{
  assert.match(route,/validate_translations/);
  assert.match(backend,/extra\["translations"\] = translations/);
  assert.match(backend,/translations=extra\.get\("translations", \{\}\)/);
  assert.match(hub,/translations=item\.translations/);
  assert.match(read('backend/app/schemas/hub_schemas.py'),/translations: dict\[str, dict\[str, str\]\]/);
  assert.match(read('frontend/src/lib/api/generated/economicUserSeamValidators.ts'),/translations: z\.record/);
  assert.match(admin,/data-admin-shop-translations="16"/);
  assert.match(admin,/translations: payload\?\.translations \?\? editor\.translations/);
});
test('financial interfaces remain unchanged by new localization fields',()=>{
  assert.match(backend,/normalize_shop_external_price_d2\(price_ton\)/);
  assert.match(backend,/CAST\(:extra AS jsonb\)/);
  assert.match(react,/methodAllowed\(item, globalMethod\)/);
  assert.match(html,/const methodLabel=method=>method==='TON'\?'GRAM\(TON\)'/);
});
