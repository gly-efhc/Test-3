import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { createRequire } from 'node:module';
import vm from 'node:vm';

const require = createRequire(import.meta.url);
const ts = require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');
const root = resolve(import.meta.dirname, '../../..');
const src = name => readFileSync(resolve(root,name),'utf8');
const names = readdirSync(root).filter(name => /^FRONTEND_v\d+\.html$/.test(name));
assert.equal(names.length,1);
const html = src(names[0]);
const registrySource = src('frontend/src/lib/interfaceVariantRegistry.ts');
const compile = path => ts.transpileModule(src(path), {compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const registry = {};
vm.runInNewContext(compile('frontend/src/lib/interfaceVariantRegistry.ts'),{exports:registry,require});
const mocks={
 './i18n':{normalizeLang:lang=>lang},
 './interfaceVariantRegistry':registry,
 './globalThemeRegistry':{GLOBAL_THEME_CATALOG:[{id:'01'},{id:'05'}],GLOBAL_THEME_GROUPS:['BN','HS'],normalizeGlobalThemeId:x=>x},
 './telegram':{telegramCloudStorageGet:async()=>null,telegramCloudStorageSet:async()=>{}},
 './colorThemeRegistry':{normalizeColorThemeId:x=>x,runtimeLegacyThemeIdForColorTheme:x=>String(x).slice(-2)},
};
function load(raw){
 const module={};
 vm.runInNewContext(compile('frontend/src/lib/settings.ts'),{
   exports:module,require:dep=>{assert.ok(mocks[dep],dep);return mocks[dep];},
   window:{localStorage:{getItem:()=>JSON.stringify(raw),setItem:()=>{}}},URL,console,
 });
 return module.loadSettings();
}
const rx = r => JSON.parse(html.match(r)?.[1] ?? 'null');

test('0560 BN-01 renders former second style; BN-02 retains former first; 5 exact slots, no sixth',()=>{
 const ids=registry.INTERFACE_VARIANT_REGISTRY.BN;
 assert.deepEqual([...ids],['BN-01','BN-02','BN-03','BN-04','BN-05']);
 assert.deepEqual(JSON.parse(JSON.stringify(registry.INTERFACE_VARIANT_STYLE_BINDINGS.BN)),{
  'BN-01':'BN-02','BN-02':'BN-01','BN-04':'BN-10','BN-05':'BN-13',
 });
 assert.equal(registry.DEFAULT_INTERFACE_VARIANTS.BN,'BN-01');
 assert.equal(registry.resolveInterfaceVariantStyle('BN','BN-01'),'BN-02');
 assert.equal(registry.resolveInterfaceVariantStyle('BN','BN-03'),'BN-03');
 assert.equal(registry.normalizeInterfaceVariant('BN','BN-06'),'BN-01');
 assert.deepEqual(rx(/const REGISTRY = Object\.freeze\((\{[^\n]+\})\);/).BN,[...ids]);
 assert.deepEqual(rx(/const SOURCE_STYLE = Object\.freeze\((\{[^\n]+\})\);/).BN,JSON.parse(JSON.stringify(registry.INTERFACE_VARIANT_STYLE_BINDINGS.BN)));
});

test('0560 v3 persisted profile and non-BN choices survive, only BN selection/overrides reset',()=>{
 const input={interface_settings_version:3,lang:'ru',color_theme_id:'CT-05',global_theme_id:'05',
  interface_variants:{...registry.DEFAULT_INTERFACE_VARIANTS,BN:'BN-04',HS:'HS-04',FQ:'FQ-05',PB:'PB-20'},
  theme_overrides:{'05':{BN:'BN-03',HS:'HS-04'},'01':{BN:'BN-02'}},
 };
 const result=load(input);
 assert.equal(result.interface_settings_version,4);
 assert.equal(result.interface_variants.BN,'BN-01');
 assert.equal(result.interface_variants.HS,'HS-04');
 assert.equal(result.interface_variants.FQ,'FQ-05');
 assert.equal(result.interface_variants.PB,'PB-20');
 assert.equal(result.lang,'ru');assert.equal(result.color_theme_id,'CT-05');
 assert.equal(result.theme_overrides['05'].HS,'HS-04');
 assert.equal(result.theme_overrides['05'].BN,undefined);
 assert.equal(result.theme_overrides['01'],undefined);
 assert.equal(input.interface_variants.BN,'BN-04');
 assert.equal(input.theme_overrides['05'].BN,'BN-03');
});

test('0560 v4 settings persist user-chosen BN and independent themes without repetitive reset',()=>{
 const raw={interface_settings_version:4,color_theme_id:'CT-01',global_theme_id:'01',
  interface_variants:{...registry.DEFAULT_INTERFACE_VARIANTS,BN:'BN-05',EI:'EI-07',PB:'PB-20'},
  theme_overrides:{'01':{BN:'BN-05'}}};
 const saved=load(raw);
 assert.equal(saved.interface_variants.BN,'BN-05');
 assert.equal(saved.interface_variants.PB,'PB-20');
 assert.equal(saved.theme_overrides['01'].BN,'BN-05');
 assert.match(html,/!\[2,3,4\]\.includes\(raw\.interface_settings_version\)/);
 assert.match(html,/interface_variants\.BN='BN-01'/);
 assert.match(html,/saved=\{interface_settings_version:4,/);
});

test('0560 selected Profile locale only check is CT accent, no selection frame/fill in React or standalone',()=>{
 const css=src('frontend/src/styles/owner-0553-profile-ct.css');
 assert.match(css,/\.efhc-profile-page \.efhc-compact-language-picker_option\[data-active="true"\]/);
 assert.match(css,/border-color:transparent!important;\s*background:transparent!important;\s*background-image:none!important;\s*box-shadow:none!important;/);
 assert.match(css,/color:var\(--efhc-ct-accent\)!important;/);
 assert.match(html,/#profilePage \.source-profile-language-option\[data-active="true"\] > span:last-child\s*\{\s*color:var\(--efhc-ct-accent\)!important;/);
 assert.match(html,/#profilePage \.source-profile-language-option\[data-active="true"\]\s*\{\s*border-color:transparent!important;\s*background:transparent!important;/);
 for (let i=1;i<=10;i++) {
  const id=`CT-${String(i).padStart(2,'0')}`;
  assert.match(html,new RegExp(`data-color-theme-id="${id}"`));
 }
 assert.match(html,/profileLanguageFocusIndex/);
 const picker=src('frontend/src/components/profile/CompactLanguagePicker.tsx');
 assert.match(picker,/aria-selected=\{selected\}/);
 assert.match(picker,/selected \? <span aria-hidden="true">✓<\/span>/);
});
