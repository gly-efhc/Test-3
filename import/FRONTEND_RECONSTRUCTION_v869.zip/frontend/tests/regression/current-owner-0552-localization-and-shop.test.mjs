import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../../..');
const findReleaseHtml = prefix => {
  const names = fs.readdirSync(root).filter(name => new RegExp(`^${prefix}_v\\d+\\.html$`).test(name));
  assert.equal(names.length,1,`exactly one ${prefix} standalone HTML expected`);
  return path.join(root,names[0]);
};
const frontend = findReleaseHtml('FRONTEND');
const shop = findReleaseHtml('SHOP');
const languages = ['ru','en','uk','de','fr','es','it','pt','tr','pl','da','id','hi','sw','ko','ja'];
const read = p => fs.readFileSync(p,'utf8');
const extract = (html,id) => JSON.parse(html.match(new RegExp(`<script id="${id}" type="application/json">([\\s\\S]*?)<\\/script>`))?.[1] ?? 'null');
const terms = v => /(?<!GRAM\()(?<![A-Za-z0-9_])TON(?![A-Za-z0-9_]| Connect)/u.test(v);
const visit = v => {
  if (typeof v==='string') return !terms(v);
  if (Array.isArray(v)) return v.every(visit);
  return !v || Object.values(v).every(visit);
};

test('Exchange and Withdraw MAX remain universal for all 16 locales', () => {
 const standalone=extract(read(frontend),'efhcFullLocales');
 for (const lang of languages) {
  const source=JSON.parse(read(path.join(root,'frontend/public/locale',lang+'.json')));
  for (const table of [source,standalone[lang]]) {
   assert.equal(table['exchange.max'],'MAX',lang);
   assert.equal(table['withdraw.max'],'MAX',lang);
  }
 }
});
test('Shop is the first protected HUB slot and honors backend visibility/URL', () => {
 const react=read(path.join(root,'frontend/src/features/hub/HubPage.tsx'));
 const demo=read(frontend);
 assert.match(react,/const fixed = \["efhc_buy", "vip_getgems", "efhc_ceo", "efhc_admin"\]/);
 assert.match(react,/shop \? t\("hub.action_shop"\)/);
 assert.match(react,/publicLinks\.data \?\? \[\]/);
 assert.match(demo,/standaloneHubCompareV559/);
 assert.match(demo,/STANDALONE_HUB_FIXED_V559/);
});
test('FAQ denominational labels synchronized to React, standalone and SSOT without replacing TON Connect',()=>{
 const standalone=extract(read(frontend),'efhcFullFaqs');
 const source=read(path.join(root,'frontend/src/data/faq/catalogs.ts'));
 assert.ok(source.includes('GRAM(TON)'));
 for (const lang of languages) {
  const catalog=JSON.parse(read(path.join(root,'frontend/public/faq',lang+'.json')));
  assert.ok(visit(catalog),lang);
  assert.ok(visit(standalone[lang]),lang+' standalone');
  const mirror=JSON.parse(read(path.join(root,'docs/SSOT/faq_ssot',lang,`faq_${lang}.json`)));
  assert.ok(visit(mirror),lang+' SSOT');
 }
});
test('Shop user-visible denominations standardized; payment transport stays TON',()=>{
 const contents=read(shop);
 const runLocales=extract(read(frontend),'efhcFullLocales');
 assert.ok(contents.includes('GRAM(TON)'));
 assert.match(contents,/data-currency="TON"/);
 assert.match(contents,/method==='TON'\?'GRAM\(TON\)'/);
 assert.ok(contents.includes('TON Connect'));
 for(const lang of languages) {
  const strings=JSON.parse(read(path.join(root,'frontend/public/locale',lang+'.json')));
  for(const [key,val] of Object.entries(strings)) {
   if(key.startsWith('portal.browser_shop.') && typeof val==='string') assert.equal(terms(val),false,lang+' '+key);
  }
  assert.equal(runLocales[lang]['portal.browser_shop.pay_ton_gram'], strings['portal.browser_shop.pay_ton_gram']);
 }
});
