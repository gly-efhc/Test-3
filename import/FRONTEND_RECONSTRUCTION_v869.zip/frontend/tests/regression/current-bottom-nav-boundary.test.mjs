import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const frontendRoot = path.resolve(here, "../..");
const root = path.resolve(frontendRoot, "..");
const read = (relative) => fs.readFileSync(path.join(root, relative), "utf8");

const layout = read("frontend/src/components/Layout.tsx");
const globals = read("frontend/src/styles/globals.css");
const version = read("VERSION").trim();
const standalone = read(`${version}.html`);

test("USER scroll viewport owns a Bottom Nav reserve separate from final content clearance", () => {
  assert.match(
    globals,
    /--efhc-user-bottom-nav-viewport-reserve:\s*calc\(\s*4\.72rem\s*\+\s*var\(--efhc-safe-bottom\)\s*\)/,
  );
  assert.match(globals, /--efhc-user-bottom-nav-boundary:\s*2\.78rem;/);
  assert.doesNotMatch(
    globals,
    /--efhc-user-bottom-nav-boundary:\s*calc\(\s*7\.5rem/,
  );
});

test("production shared Layout measures the fixed Bottom Nav and reserves its exact height", () => {
  assert.match(layout, /const bottomNavElementRef = useRef<HTMLElement \| null>\(null\);/);
  assert.match(layout, /new ResizeObserver\(syncBottomNavViewport\)/);
  assert.match(layout, /const height = nav\.getBoundingClientRect\(\)\.height;/);
  assert.match(layout, /ref=\{bottomNavElementRef\}/);
  assert.match(
    layout,
    /marginBottom: isAdminRoute[\s\S]*?"var\(--efhc-user-bottom-nav-viewport-reserve\)"[\s\S]*?`\$\{bottomNavViewportHeight\}px`/,
  );
  assert.match(
    layout,
    /scrollPaddingBottom: isAdminRoute[\s\S]*?"var\(--efhc-user-bottom-nav-boundary\)"/,
  );
});

test("standalone mirrors measured viewport reserve instead of clearance-only padding", () => {
  assert.match(
    standalone,
    /--efhc-user-bottom-nav-viewport-reserve:calc\(4\.72rem \+ var\(--efhc-safe-bottom\)\)/,
  );
  assert.match(standalone, /--efhc-user-bottom-nav-boundary:2\.78rem/);
  assert.match(
    standalone,
    /\[data-interface-app-mode="user"\] \.unified-pages\{margin-bottom:var\(--efhc-user-bottom-nav-viewport-reserve\);padding-bottom:var\(--efhc-user-bottom-nav-boundary\);scroll-padding-bottom:var\(--efhc-user-bottom-nav-boundary\)\}/,
  );
  assert.match(standalone, /const syncStandaloneBottomNavViewport=\(\)=>\{/);
  assert.match(standalone, /standaloneBottomNav\.getBoundingClientRect\(\)\.height/);
  assert.match(standalone, /new ResizeObserver\(syncStandaloneBottomNavViewport\)/);
  assert.match(
    standalone,
    /style\.setProperty\('--efhc-user-bottom-nav-viewport-reserve',`\$\{Math\.ceil\(height\*100\)\/100\}px`\)/,
  );
});

test("Admin remains outside the USER Bottom Nav viewport contract", () => {
  assert.match(layout, /marginBottom: isAdminRoute\s*\? undefined/);
  assert.match(
    standalone,
    /\[data-interface-app-mode="admin"\] \.efhc-main\{padding-bottom:1rem!important\}/,
  );
});

test("Bottom Nav protected labels, order and geometry remain unchanged", () => {
  const labels = [...layout.matchAll(/visualLabel: (?:"([^"]+)"|t\("([^"]+)"\))/g)]
    .map((match) => match[1] || match[2])
    .filter((label) => ["Energy", "Panels", "Exchange", "Tasks", "Referrals", "Ranks"].includes(label));
  assert.deepEqual(labels, ["Energy", "Panels", "Exchange", "Tasks", "Referrals", "Ranks"]);
  assert.doesNotMatch(layout, /visualLabel: t\("nav\.ranks"\)/);
  assert.match(standalone, /data-route="\/ranks" title="Ranks"/);
  assert.match(standalone, /efhc-game-nav_label">Ranks<\/span>/);
  assert.doesNotMatch(standalone, /data-i18n-key="nav\.ranks"/);
  assert.doesNotMatch(standalone, /data-i18n-title-key="nav\.ranks"/);
  assert.match(layout, /data-nav-geometry="wide-rounded-six"/);
  assert.match(standalone, /data-nav-geometry="wide-rounded-six"/);
});
