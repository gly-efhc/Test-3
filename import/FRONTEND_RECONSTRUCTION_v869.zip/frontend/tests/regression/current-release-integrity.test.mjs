import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";

const frontendRoot = path.resolve(import.meta.dirname, "../..");
const root = path.resolve(frontendRoot, "..");
const version = fs.readFileSync(path.join(root, "VERSION"), "utf8").trim();

test("current unified repository retains canonical release core and working evidence", () => {
  for (const rel of ["backend", "frontend", "api", "ops", "scripts/release", "reports", "docs"]) {
    assert.equal(fs.existsSync(path.join(root, rel)), true, rel);
  }
  for (const rel of ["routes", "tables", "reports/generated"]) {
    assert.equal(fs.existsSync(path.join(root, rel)), false, rel);
  }
});

test("current frontend repository contains only current standalone release HTML", () => {
  const htmls = fs.readdirSync(root).filter((name) => /^FRONTEND_v\d+\.html$/.test(name));
  assert.deepEqual(htmls, [`${version}.html`]);
  const number = version.replace("FRONTEND_v", "");
  const shops = fs.readdirSync(root).filter((name) => /^SHOP_v\d+\.html$/.test(name));
  assert.deepEqual(shops, [`SHOP_v${number}.html`]);
});

test("reports remain frontend-only", () => {
  const files = [];
  const walk = (dir) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full); else files.push(path.relative(path.join(root, "reports"), full).replaceAll(path.sep, "/"));
    }
  };
  walk(path.join(root, "reports"));
  assert.ok(files.every((p) => !p.startsWith("generated/")));
  assert.ok(files.every((p) => !/\.(log|sql|db|sqlite)$/i.test(p)));
});


test("active documentation index direct file paths exist in the physical HEAD", () => {
  const indexPath = path.join(root, "docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md");
  const indexText = fs.readFileSync(indexPath, "utf8");
  const directPaths = indexText
    .split(/\r?\n/)
    .map((line) => line.match(/^\|\s*`([^`]+)`\s*\|/u)?.[1] ?? null)
    .filter((value) => value !== null);
  assert.ok(directPaths.length > 0);
  for (const rel of directPaths) {
    assert.equal(fs.existsSync(path.join(root, rel)), true, rel);
  }
});


test("current regression suites do not contain historical one-off tests", () => {
  const suites = fs.readdirSync(path.join(root,"frontend/tests/regression")).filter((name)=>name.endsWith(".test.mjs"));
  assert.ok(suites.length > 0);
  assert.ok(suites.every((name) => name.startsWith("current-") && !/^current-cycle\d/.test(name)), suites.join(", "));
});
