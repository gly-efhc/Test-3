import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
const root=resolve(import.meta.dirname,'../../..');
const read=(p)=>readFileSync(resolve(root,p),'utf8');
const htmlFiles=readdirSync(root).filter(n=>/^FRONTEND_v\d+\.html$/.test(n));
assert.equal(htmlFiles.length,1);
const html=read(htmlFiles[0]);
const css=read('frontend/src/styles/hub-demo-react-parity.css').trimEnd();

test('OWNER0562: HUB exact 50px border-box and two-line ellipsis share identical React/standalone CSS',()=>{
 const marker='<style id="hub-demo-react-parity">\n'+css+'\n</style>';
 assert.ok(html.includes(marker));
 assert.match(css,/box-sizing:border-box!important;\s*min-height:50px!important;\s*height:50px!important;\s*max-height:50px!important/);
 assert.match(css,/-webkit-line-clamp:2!important;\s*overflow:hidden!important;\s*overflow-wrap:anywhere!important;/);
 assert.match(css,/grid-template-columns:repeat\(2,minmax\(0,1fr\)\)!important;/);
});
test('OWNER0563: settings gear three-second hide preserves no fixed-opacity overrides',()=>{
 const react=read('frontend/src/components/interface-settings/InterfaceCustomizationProvider.tsx');
 const reactBase=read('frontend/src/styles/globals.css');
 const reactCoverage=read('frontend/src/styles/global-theme-owner-coverage.css');
 assert.match(react,/setButtonVisible\(false\)/);
 assert.match(react, /3_000/);
 assert.match(reactBase,/\.efhc-interface-customization-button\[data-visible="false"\]\s*\{\s*pointer-events:\s*none;\s*opacity:\s*0;/);
 assert.doesNotMatch(reactCoverage,/opacity:1;/);
 assert.match(reactCoverage,/\.efhc-interface-customization-button\[data-visible="false"\] \{\s*pointer-events:none!important;/);
 assert.match(html,/customizeHideTimer=setTimeout\(\(\)=>setCustomizeButtonVisible\(false\),3000\)/);
 assert.doesNotMatch(html,/color:#f8fafc!important;opacity:1!important;/);
 assert.match(html,/\.customization-control-dock>\.interface-customization-button\[data-visible="false"\]\{pointer-events:none!important\}/);
 assert.match(html,/\.interface-customization-button\{position:fixed;/);
});
test('OWNER0562: 20 unreachable XC10-13 standalone CT visual aliases removed without changing XC01 or financial logic',()=>{
 for(const id of ['XC-10','XC-11','XC-12','XC-13']) assert.doesNotMatch(html,new RegExp(`#exchangeBody\\[data-xc="${id}"\\]`));
 assert.match(html,/#exchangeBody\[data-xc="XC-01"\]/);
 assert.match(html,/const SOURCE_STYLE = Object\.freeze/);
 assert.match(read('frontend/src/lib/interfaceVariantRegistry.ts'),/XC: numbered\("XC", 1\)/);
});
