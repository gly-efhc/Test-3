import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "../../..");
const read = (relative) => fs.readFileSync(path.join(root, relative), "utf8");

const laws = read("docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md");
const standard = read("docs/NORM/FRONTEND_REPORT_STANDARD.md");
const timebox = read("docs/NORM/FRONTEND_CYCLE_TIMEBOX_CANON.md");
const tz = read("docs/NORM/EFHC_REPORTING_RULES_TZ.md");
const docs = `${laws}\n${standard}\n${timebox}\n${tz}`;

const forbiddenPrintedQuestions = [
  "Что ты сделал в этом цикле человеческим языком?",
  "Какой следующий цикл по плану человеческим языком?",
];

test("ordinary closure does not print the two questions as boilerplate", () => {
  for (const question of forbiddenPrintedQuestions) {
    assert.doesNotMatch(laws, new RegExp(question.replace(/[?]/g, "\\?")));
    assert.doesNotMatch(standard, new RegExp(question.replace(/[?]/g, "\\?")));
  }
  assert.match(standard, /Сделано:/);
  assert.match(standard, /Следующий цикл:/);
});

test("next cycle is sequential and scope is not invented without a plan", () => {
  assert.match(standard, /следующий последовательный номер/i);
  assert.match(standard, /scope\/название не придумываются/i);
  assert.match(docs, /Следующий cycle не стартует автоматически|Следующий цикл автоматически не запускается/i);
});

test("ordinary OWNER output forbids technical dump and report replay", () => {
  assert.match(standard, /SHA\/CRC/);
  assert.match(standard, /numbered-report replay/);
  assert.match(standard, /ссылку на numbered report/);
  assert.match(standard, /Подробный отчёт означает больше человеческого объяснения, а не technical dump/);
});

test("required material checkpoints preserve independent report, cycle and release numbering", () => {
  assert.match(standard, /обязательный material release checkpoint всё равно должен быть физически создан согласно archive\/release law до объявления соответствующего material state завершённым/i);
  assert.match(laws, /Material state, для которого release law требует checkpoint, не считается физически закреплённым до выпуска следующего `FRONTEND_vNNN\.zip` с matching HTML\/Shop/);
  assert.match(standard, /Report ledger независим от MAIN-cycle numbering и physical release numbering/);
  assert.match(standard, /Physical release не обязан иметь связь 1:1 с report или cycle/);
  assert.match(laws, /Report, MAIN-cycle и physical-release numbering независимы/);
  assert.match(laws, /Один OWNER-authorized cycle может содержать несколько bounded итераций, несколько immutable reports и несколько physical checkpoints/);
});

test("direct OWNER decisions take precedence over every document", () => {
  assert.match(laws, /Прямое решение OWNER выше любого документа/);
});

test("service evidence is internal and only final Frontend artifacts are exposed", () => {
  assert.match(standard, /FRONTEND_vNNN\.zip/);
  assert.match(standard, /FRONTEND_vNNN\.html/);
  assert.match(standard, /SHOP_vNNN\.html/);
  assert.match(standard, /Service\/evidence files остаются внутри проекта/);
});

test("closure validation is single-pass and non-recursive", () => {
  assert.match(standard, /один bounded preflight/);
  assert.match(standard, /Recursive report validators\/retry loops запрещены/);
});

test("temporary files follow DELETE_DIRECT REQUIRED_EVIDENCE REVIEW", () => {
  assert.match(standard, /DELETE_DIRECT/);
  assert.match(standard, /REQUIRED_EVIDENCE/);
  assert.match(standard, /REVIEW/);
});

test("Frontend active timebox is 15-20 minutes, never 25", () => {
  assert.match(timebox, /15–20 минут/);
  assert.doesNotMatch(timebox, /5–25 минут/);
  assert.doesNotMatch(laws, /5–25 минут/);
});
