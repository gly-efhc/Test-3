import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
const root = resolve(import.meta.dirname, '../../..');
const read = path => readFileSync(resolve(root, path), 'utf8');
const css = read('frontend/src/styles/owner-0551-user-polish.css');
const header = read('frontend/src/components/GlobalHeader.tsx');
const app = read('frontend/src/pages/_app.tsx');
const html = read(`${read('VERSION').trim()}.html`);

test('0551 Header balance navigates by button to full Profile Balance route', () => {
  assert.match(header, /<button\s+type="button"\s+ref=\{balanceFit\.containerRef\}/);
  assert.match(header, /data-header-balance-navigation="\/web-profile\?section=history"/);
  assert.match(header, /router\.push\("\/web-profile\?section=history"\)/);
  assert.match(html, /id="headerBalance"[^>]*>/);
  assert.match(html, /data-route-direct="\/web-profile\?section=history"/);
  assert.match(html, /if\(target==='\/web-profile\?section=history'\)\{target='\/web-profile';profileTab='history';\}/);
});

test('0551 Rank actions neutral, translucent and CT-border across all variants', () => {
  assert.match(css, /\[data-ranks-refresh-action\]/);
  assert.match(css, /\[data-ranks-show-me-action\]/);
  assert.match(css, /#rankRefresh/);
  assert.match(css, /#findMyRank/);
  assert.match(css, /background-color:rgba\(12,17,29,\.62\)!important/);
  assert.match(css, /border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.38\)!important/);
  assert.match(css, /:focus-visible/);
});

test('0551 Tasks and Panels glow is disabled at hero and nested material level', () => {
  for (const selector of ['.efhc-tasks-shell','#tasksPage','.efhc-panels-page','#panelsPage','#panelsPortfolioPage','.efhc-game-hero_glow','.panel-tile','.efhc-task-card','.panels-activation-card']) {
    assert.ok(css.includes(selector), selector);
  }
  assert.match(css, /background-image:none!important/);
  assert.match(css, /display:none!important/);
  assert.doesNotMatch(css, /\.efhc-admin|data-interface-app-mode="admin"/);
});

test('0551 Settings uses the ten CT roles for standalone and React modal only', () => {
  assert.match(css, /body:has\(\.efhc-independent-shell\[data-interface-app-mode="user"\]/);
  for (let theme=1;theme<=10;theme++) assert.ok(css.includes(`data-color-theme-id="CT-${String(theme).padStart(2,'0')}"`));
  assert.match(css, /#profileSettingsOverlay/);
  assert.match(css, /\.efhc-profile-avatar-url-input/);
  assert.match(css, /\.standalone-avatar-url-input/);
  assert.match(css, /\.standalone-setting-toggle\[data-active="true"\]/);
  assert.match(css, /--efhc-settings-edge:rgba\(var\(--efhc-ct-accent-rgb\),\.31\)/);
  assert.match(css, /:focus-visible/);
  assert.doesNotMatch(css, /rgba\(110,168,255/);
});

test('0551 stylesheet is imported last and identical to embedded standalone stylesheet', () => {
  assert.match(app, /import "\.\.\/styles\/owner-0551-user-polish\.css";/);
  assert.ok(app.indexOf('owner-0551-user-polish.css') > app.indexOf('owner-0550-faq-withdraw-ct.css'));
  const anchor = '<style id="owner-0551-user-polish">\n';
  assert.equal(html.split(anchor).length,2);
  assert.ok(html.includes(anchor + css + '</style>'));
  assert.match(html, /<\/body>\s*<\/html>\s*$/);
});
