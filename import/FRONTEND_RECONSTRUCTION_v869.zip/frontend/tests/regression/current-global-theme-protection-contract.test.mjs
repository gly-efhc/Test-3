import test from "node:test";
import assert from "node:assert/strict";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const root = path.resolve(import.meta.dirname, "../../..");
const read = (rel) => fs.readFileSync(path.join(root, rel), "utf8");
const bytes = (rel) => fs.readFileSync(path.join(root, rel));
const sha = (rel) => crypto.createHash("sha256").update(bytes(rel)).digest("hex");
const json = (rel) => JSON.parse(read(rel));
const contract = json("frontend/src/design-system/global-theme-protection-contract.json");
const kicker = read("frontend/src/styles/global-theme-page-kicker-contract.css");
const app = read("frontend/src/pages/_app.tsx");
const version = read("VERSION").trim();
const html = read(`${version}.html`);


test("eight OWNER theme-accent elements always consume the active Global Theme accent", () => {
  for (const selector of [
    ".efhc-panels-shell .efhc-panels-hero[data-ph] .efhc-game-kicker",
    ".efhc-exchange-shell .efhc-exchange-hero[data-xh] .efhc-game-kicker",
    ".efhc-tasks-shell[data-tg] .efhc-game-hero .efhc-game-kicker",
    ".efhc-referrals-shell[data-rg] .efhc-game-hero .efhc-game-kicker",
    "#panelsPage[data-pa] .panels-kicker",
    "#exchangePage .source-hero-kicker",
    "#tasksPage[data-tg] .source-hero-kicker",
    "#referralsPage[data-rg] .source-hero-kicker",
    ".efhc-referrals-shell[data-rg] .efhc-referral-achievement-dot",
    "#referralsPage[data-rg] .standalone-referral-achievement-nodes > div > b",
    ".efhc-withdraw-shell .efhc-withdraw-hero .efhc-game-kicker",
    "#withdrawPage[data-wd] .source-hero-kicker",
    ".efhc-referrals-shell[data-rg] [data-referral-action=\"copy-link\"]",
    "#referralsPage[data-rg] #copyReferral",
    ".efhc-referrals-shell[data-rg] .efhc-referral-achievement-track > span",
    "#referralsPage[data-rg] .standalone-referral-achievement-track > span",
  ]) assert.ok(kicker.includes(selector), selector);
  assert.match(kicker, /color:var\(--efhc-route-accent\) !important/);
  assert.equal(contract.themeAccentElementLaw.colorOwner, "--efhc-route-accent");
  assert.equal(contract.themeAccentElementLaw.elements.length, 8);
  assert.equal(contract.themeAccentElementLaw.elements.find((x) => x.id === "user.referrals.achievement.level-circle").scope, "circle outline/glow only; number/check glyph stays standard light; Lvl labels, thresholds, progress track/fill and state background excluded");
  const levelBlock = kicker.slice(kicker.indexOf('.efhc-referrals-shell[data-rg] .efhc-referral-achievement-dot'), kicker.indexOf('.efhc-withdraw-shell'));
  assert.match(levelBlock, /border-color:var\(--efhc-route-accent\) !important/);
  assert.match(levelBlock, /color:var\(--tg-text,#f8fafc\) !important/);
  assert.match(levelBlock, /color:var\(--tg-hint,#94a3b8\) !important/);
  assert.doesNotMatch(levelBlock, /background-color:/);
  assert.match(levelBlock, /box-shadow:0 0 8px color-mix\(in srgb,var\(--efhc-route-accent\) 28%,transparent\) !important/);
  assert.match(levelBlock, /box-shadow:0 0 0 2px color-mix\(in srgb,var\(--efhc-route-accent\) 10%,transparent\) !important/);
  const copy = contract.themeAccentElementLaw.elements.find((x) => x.id === "user.referrals.invite.copy-link");
  const connector = contract.themeAccentElementLaw.elements.find((x) => x.id === "user.referrals.achievement.connector-progress");
  assert.equal(copy.scope, "button border/background/shadow follow theme accent; label stays standard light");
  assert.equal(connector.scope, "filled connector segment follows theme accent; neutral rail remains state-owned");
  assert.match(kicker, /#copyReferral/);
  assert.match(kicker, /standalone-referral-achievement-track > span/);
});

// Evergreen theme-contract checks. Maintain these tests when OWNER changes the
// UI: never add one test file per cycle or assert superseded catalog totals.
test("current OWNER theme consumers bind HUB, MAX frame, and deposit portal to CT tokens", () => {
  const css = read("frontend/src/styles/global-theme-owner-coverage.css");
  const hub = css.slice(css.indexOf("/* Cycle0467/02 OWNER: HUB"));
  assert.ok(hub.includes('.efhc-hub-page[data-hu] .efhc-hub-choice{'));
  assert.ok(hub.includes('border-color:rgba(var(--efhc-ct-accent-rgb),.30)!important'));
  assert.ok(hub.includes('background-color:rgba(var(--efhc-ct-accent-rgb),.03)!important'));
  assert.ok(hub.includes('color:var(--efhc-ct-accent)!important'));
  const withdrawStart=css.indexOf("/* Withdraw MAX: OWNER specified CT outline ONLY.");
  const withdrawEnd=css.indexOf("/* Deposit portal is rooted in body",withdrawStart);
  assert.ok(withdrawStart>=0 && withdrawEnd>withdrawStart);
  const withdraw=css.slice(withdrawStart,withdrawEnd);
  assert.match(withdraw,/\.efhc-withdraw-max-cta\{[\s\S]*?border-color:rgba\(var\(--efhc-ct-accent-rgb\),\.45\)!important/);
  assert.doesNotMatch(withdraw,/(?:^|[;{]\s*)(?:background|color|box-shadow)\s*:/m);
  const deposit=css.slice(withdrawEnd);
  assert.match(deposit,/\.efhc-user-direct-deposit-portal\[data-color-theme-id\]/);
  assert.match(deposit,/background:rgba\(var\(--efhc-ct-accent-rgb\),\.08\)!important/);
  assert.match(deposit,/color:#f8fafc!important/);
  assert.match(deposit,/\[data-direct-deposit-action="cancel"\]/);
  // Standalone parity comes from the current physical HTML, not historical screenshots.
  assert.match(html,/"XH":\["XH-01","XH-02","XH-03","XH-04","XH-05","XH-06"\]/);
  assert.match(html,/data-direct-deposit-action="send-efhc-jetton"/);
});

test("current Exchange selector has six contiguous visible positions and singleton internal groups", () => {
  const source = read("frontend/src/lib/interfaceVariantRegistry.ts");
  assert.match(source,/XH: numbered\("XH", 6\)/);
  for(const group of ["XS","XC","XA"]){
    assert.match(source,new RegExp(`${group}: numbered\\("${group}", 1\\)`));
    assert.ok(html.includes(`"${group}":["${group}-01"]`));
  }
  const registry=JSON.parse(html.match(/const REGISTRY = Object\.freeze\((\{[^\n]+\})\);/)[1]);
  assert.deepEqual(registry.XH,["XH-01","XH-02","XH-03","XH-04","XH-05","XH-06"]);
  const migrations=read("frontend/src/lib/interfaceVariantRegistry.ts");
  assert.doesNotMatch(migrations,/OWNER_RETIRED_VARIANT_ALIASES/);
});


test("all ten USER color themes share WD decorative inset without CT03 exclusion", () => {
  const html = read(`${read("VERSION").trim()}.html`);
  assert.doesNotMatch(html, /:not\(\[data-color-theme-id="CT-03"\]\)/);
  assert.match(html, /WD decorative inset is transparent in all ten USER CTs/);
  assert.match(html, /html\[data-interface-app-mode="user"\]\[data-color-theme-id\]\s*\.efhc-independent-shell[\s\S]*?#withdrawPage\[data-wd\] \.standalone-withdraw-create-card/);
  assert.doesNotMatch(read("frontend/src/pages/_app.tsx"), /theme03-protection-perimeter\.css/);
  const lock=json("frontend/src/design-system/theme03-reference-lock.json");
  assert.match(lock.status,/SUPERSEDED_BY_OWNER/);
  assert.equal(contract.status,"ACTIVE_CT01_CT10_EQUAL_USER_POLICY");
});
test("Energy and Panels CT01–CT10 materials are bound to active color, inactive Activ neutral", () => {
  const css=read("frontend/src/styles/global-theme-owner-coverage.css");
  for (const selector of [".efhc-energy-stage[data-eg]", ".efhc-panels-card-surface .efhc-panel-tile", ".efhc-panel-tile_dates", ".efhc-panel-activ-status[data-status=\"activ\"][data-active=\"true\"]", ".efhc-panels-generation-tier[data-tier=\"vip\"]", ".efhc-energy-stage_level strong"]) assert.ok(css.includes(selector),selector);
  assert.match(css,/background:rgba\(var\(--efhc-ct-accent-rgb\),\.035\)!important/);
  assert.match(css,/color:#94a3b8!important/);
  for (const selector of ["#panelsPortfolioPage .panels-list .panel-tile","#panelsPage .panels-activation-card","#energyPage .efhc-energy-stage[data-eg]"]) assert.ok(html.includes(selector),selector);
});

test("Energy Lvl is text-only; Referrals and Panels remain neutral across CT01–CT10", () => {
  const css = read("frontend/src/styles/global-theme-owner-coverage.css");
  const ref = css.slice(css.indexOf("/* Cycle0468 iteration02:"));
  const standalone = html.slice(html.indexOf("/* OWNER Cycle0468 iteration02 / USER standalone"));
  const my = read("frontend/src/pages/referrals/my.tsx");
  const shell = '.efhc-energy-stage[data-eg] .efhc-energy-stage_level strong';
  assert.ok(ref.includes(shell));
  assert.ok(standalone.includes('#energyPage .efhc-energy-stage[data-eg] .efhc-energy-stage_level strong'));
  for (const source of [ref,standalone]) {
    assert.match(source,/border:0!important;border-radius:0!important;padding:0!important/);
    assert.match(source,/background:transparent!important;background-image:none!important/);
    assert.match(source,/background-color:#0b1019!important/);
    assert.match(source,/color:#f8fafc!important/);
  }
  assert.match(ref,/\.efhc-panels-portfolio-shell \.efhc-panel-tile/);
  assert.match(ref,/\.efhc-referrals-shell\[data-rg\] \.efhc-list-row\[data-referral-row\][\s\S]*?padding-block:8px!important/);
  assert.match(standalone,/#referralsPage \.source-ref-row\{padding-block:calc\(\.7rem - 6px\)!important/);
  assert.match(ref,/\.efhc-referral-activ-indicator \.efhc-game-header_status\[data-status="activ"\]\[data-active="false"\]/);
  assert.match(ref,/color:#94a3b8!important/);
  assert.match(my,/data-rg=\{resolveInterfaceVariantStyle\("RG", customization\.effective\.RG\)\}/);
  // Preview-only; no OWNER acceptance and no accidental replacement of active page.
  assert.ok(read("demo/review/REFERRALS_TEMPLATE_C_0468_OWNER_PREVIEW.html").includes("Шаблон C · PREVIEW"));
  assert.doesNotMatch(my,/REFERRALS_TEMPLATE_C_0468_OWNER_PREVIEW/);
});

// Forensic retained-design invariant from the OWNER-accepted v727 CSS.
// A deletion of retired KG IDs must not erase shared KG01/RG/WG declarations.
test("retired KG selector cleanup cannot delete retained KG01 or shared RG/WG rules", () => {
  const css = read("frontend/src/styles/globals.css");
  const required = [
    '.efhc-ranks-shell:is([data-kg="KG-01"],[data-kg="KG-03"],[data-kg="KG-05"]) .efhc-game-stat{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.3fr);align-items:center;gap:.5rem}',
    '.efhc-ranks-shell:is([data-kg="KG-01"],[data-kg="KG-03"],[data-kg="KG-05"]) .efhc-game-stat_value{text-align:right;min-width:0;white-space:nowrap}',
    '.efhc-referrals-shell[data-rg="RG-03"],.efhc-ranks-shell[data-kg="KG-03"],.efhc-profile-page[data-wg="WG-03"]{border-radius:1.2rem;background:radial-gradient(520px 220px at 100% 0,rgba(124,92,255,.12),transparent 72%)}',
  ];
  for(const declaration of required) assert.ok(css.includes(declaration), `missing protected historical joint CSS rule: ${declaration.slice(0,80)}`);
  assert.match(css, /\.efhc-referrals-shell\[data-rg="RG-03"\] \.efhc-game-hero,\.efhc-ranks-shell\[data-kg="KG-03"\] \.efhc-game-hero,\.efhc-profile-page\[data-wg="WG-03"\] \.efhc-profile-hero/);
});

// OWNER active-catalog contract: removal means no selectable alias/renumbering.
test("current FAQ/HUB active registry excludes only OWNER-retired IDs and HUB is static", () => {
  const source = read("frontend/src/lib/interfaceVariantRegistry.ts");
  const reg = JSON.parse(html.match(/const REGISTRY = Object\.freeze\((\{[^\n]+\})\);/)[1]);
  const active = json("frontend/src/design-system/universal-design-catalog.json");
  const historical = json("frontend/src/design-system/universal-design-registry.json");
  const ids = Object.fromEntries(active.groups.map(group => [group.group, group.variants.map(v => v.id)]));
  const faq = ["FQ-01","FQ-02","FQ-03","FQ-04","FQ-05","FQ-06"];
  assert.deepEqual(reg.HU, ["HU-01"]);
  assert.deepEqual(reg.FQ, faq);
  assert.deepEqual(ids.HU, reg.HU);
  assert.deepEqual(ids.FQ.map((_,i)=>`FQ-${String(i+1).padStart(2,"0")}`), reg.FQ);
  assert.match(source, /HU: numbered\("HU", 1\)/);
  assert.doesNotMatch(html, /data-swipe-group="HU"/);
  assert.doesNotMatch(html, /\{"page":"Hub","route":"\/hub","groups"/);
  assert.match(read("frontend/src/features/hub/HubPage.tsx"), /data-hu="HU-01"/);
  // Historical evidence remains immutable and no new per-ID migration map is introduced.
  assert.equal(historical.groups.find(x => x.group === "HU").variant_count, 1);
  assert.equal(historical.groups.find(x => x.group === "FQ").variant_count, 6);
  assert.equal(active.counts.registry_variant_tokens_total, 236);
  assert.equal(active.counts.color_theme_applicable_design_variants, 207);
});

test("Exchange and Tasks owner-directed decorative hero icons are physically absent", () => {
  const exchange = read("frontend/src/pages/exchange.tsx");
  const tasks = read("frontend/src/pages/tasks.tsx");
  assert.doesNotMatch(exchange, /icon="↔"/);
  assert.doesNotMatch(tasks, /icon="✓"/);
  assert.doesNotMatch(html.match(/id="exchangeHero"[\s\S]{0,650}/)[0], /source-hero-icon/);
  assert.doesNotMatch(html.match(/id="tasksPage"[\s\S]{0,900}/)[0], /source-hero-icon/);
});

test("OWNER ten-CT color ownership binds PH-02/PH-10, XH-02, FQ-02/03/04 and CT03 Energy/Header", () => {
  const css = read("frontend/src/styles/global-theme-owner-0544.css");
  assert.match(app, /global-theme-owner-0544\.css/);
  assert.match(html, /id="owner-0544-ten-theme-contract"/);
  for (const v of ["PH-02","PH-10","XH-02","FQ-02","FQ-03","FQ-04","HU-01"]) {
    assert.ok(css.includes(v), v);
  }
  assert.match(css, /\[data-color-theme-id\]/);
  assert.match(css, /--efhc-ct-accent-rgb/);
  for (const selector of [".efhc-game-header", ".efhc-game-header_profile", ".efhc-game-header_balance", ".efhc-energy-stage", ".efhc-energy-stage_veil"]) {
    assert.ok(css.includes(selector), selector);
  }
  assert.match(css, /data-interface-app-mode="user"/);
  assert.doesNotMatch(css.replace(/\/\*[\s\S]*?\*\//g, ""), /data-interface-app-mode="admin"|\.efhc-admin/);
});
