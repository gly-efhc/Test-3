import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const frontendRoot = path.resolve(here, '../..');
const root = path.resolve(frontendRoot, '..');
const read = (relative) => fs.readFileSync(path.join(root, relative), 'utf8');
const version = read('VERSION').trim();

const section = read('frontend/src/components/profile/ProfileWalletSection.tsx');
const primary = read('frontend/src/components/profile/wallet/WalletPrimaryCard.tsx');
const address = read('frontend/src/components/profile/wallet/WalletAddressVerification.tsx');
const queries = read('frontend/src/queries/useProfile.ts');
const css = read('frontend/src/styles/globals.css');
const standalone = read(`${version}.html`);

const localeDir = path.join(frontendRoot, 'public/locale');
const localeFiles = fs.readdirSync(localeDir).filter((name) => name.endsWith('.json')).sort();

test('Current makes Primary ordering explicit and optimistic in production', () => {
  assert.match(section, /\.sort\(\(left, right\) => Number\(right\.is_primary\) - Number\(left\.is_primary\)\)/);
  assert.match(queries, /onMutate: async \(action\) =>/);
  assert.match(queries, /queryClient\.setQueryData<WalletsMeOut>/);
  assert.match(queries, /is_primary: wallet\.id === action\.walletId/);
  assert.match(queries, /onError: \(_error, _action, context\) =>/);
  assert.match(queries, /queryClient\.setQueryData\(context\.queryKey, context\.previous\)/);
});

test('Current keeps the Primary address first and badge at the lower-right tail', () => {
  const addressIndex = primary.indexOf('<WalletAddressVerification');
  const actionsIndex = primary.indexOf('className="efhc-wallet-primary-actions"');
  const badgeIndex = primary.indexOf('className="efhc-wallet-status-zone efhc-wallet-primary-status"');
  assert.ok(addressIndex >= 0);
  assert.ok(actionsIndex > addressIndex);
  assert.ok(badgeIndex > actionsIndex);
  assert.match(css, /\.efhc-wallet-primary-status \{ justify-self:end; align-self:end; \}/);
});

test('Current replaces copy underline with translucent state feedback', () => {
  assert.doesNotMatch(css, /\.efhc-wallet-address-control:hover code \{ text-decoration:underline/);
  assert.match(css, /\.efhc-wallet-address-control:hover,\.efhc-wallet-address-control:focus-visible,\.efhc-wallet-address-control\[data-copy-state="copied"\]/);
  assert.match(address, /data-copy-state=\{copyState\}/);
  assert.match(address, /className="efhc-wallet-copy-feedback"/);
  assert.match(address, /t\("wallet\.copied"\)/);
  assert.match(address, /}, 1400\);/);
});

test('Current provides wallet.copied in all 16 locale catalogs', () => {
  assert.equal(localeFiles.length, 16);
  for (const file of localeFiles) {
    const payload = JSON.parse(fs.readFileSync(path.join(localeDir, file), 'utf8'));
    assert.equal(typeof payload['wallet.copied'], 'string', file);
    assert.ok(payload['wallet.copied'].trim().length > 0, file);
  }
});

test('Current standalone reorders Primary and mirrors transient copy feedback', () => {
  const rendererStart = standalone.indexOf('function renderStandaloneWallets()');
  const rendererEnd = standalone.indexOf('const standaloneHistoryT=', rendererStart);
  assert.ok(rendererStart >= 0 && rendererEnd > rendererStart);
  const renderer = standalone.slice(rendererStart, rendererEnd);
  assert.match(renderer, /\.sort\(\(left,right\)=>Number\(right\.is_primary\)-Number\(left\.is_primary\)\)/);
  const addressIndex = renderer.indexOf('class="standalone-wallet-address"');
  const actionsIndex = renderer.indexOf('class="standalone-wallet-actions"');
  const badgeIndex = renderer.indexOf('standalone-wallet-primary-status');
  assert.ok(addressIndex >= 0);
  assert.ok(actionsIndex > addressIndex);
  assert.ok(badgeIndex > actionsIndex);
  assert.match(standalone, /standalone-wallet-address\[data-copy-state="copied"\]/);
  assert.doesNotMatch(standalone, /\.standalone-wallet-address:hover code\{text-decoration:underline/);
  assert.match(standalone, /standalonePublicT\('wallet\.copied','Скопировано'\)/);
  assert.match(standalone, /standaloneWalletCopyTimer=setTimeout\(\(\)=>\{/);
  assert.match(standalone, /},1400\);/);
});

test('Current does not alter the established wallet-card frame declarations', () => {
  assert.match(css, /\.efhc-wallet-entry \{[\s\S]*border: 1px solid color-mix\(in oklab, var\(--tg-hint\) 20%, transparent\);[\s\S]*border-radius: 1rem;/);
  assert.match(css, /\.efhc-wallet-entry\[data-wallet-role="primary"\] \{ border-color: color-mix\(in oklab, var\(--tg-button\) 38%, var\(--tg-hint\)\); \}/);
  assert.match(standalone, /\.standalone-wallet-card\{display:grid;gap:\.58rem;padding:\.72rem;border:1px solid rgba\(148,163,184,\.14\);border-radius:\.82rem;background:rgba\(15,23,42,\.7\)\}/);
});

test('Current disconnected Connect CTA is de-nested and placed under Linked wallets', () => {
  const banner = read('frontend/src/components/profile/wallet/WalletConnectBanner.tsx');
  const disconnectedStart = banner.indexOf('if (!props.connected)');
  const connectedCard = banner.indexOf('className="efhc-wallet-card"');
  assert.ok(disconnectedStart >= 0 && connectedCard > disconnectedStart);
  const disconnected = banner.slice(disconnectedStart, connectedCard);
  assert.match(disconnected, /<Button[\s\S]*className="w-full efhc-wallet-connect-cta"[\s\S]*data-wallet-provider-action="connect"/);
  assert.doesNotMatch(disconnected, /efhc-wallet-card/);

  const heading = section.indexOf('data-wallet-section-heading="linked"');
  const disconnectedPlacement = section.indexOf('{!props.sessionConnected ? (', heading);
  const disconnectedBanner = section.indexOf('<WalletConnectBanner', disconnectedPlacement);
  assert.ok(heading >= 0 && disconnectedPlacement > heading && disconnectedBanner > disconnectedPlacement);

  const connectedPlacement = section.indexOf('{props.sessionConnected ? (');
  const firstHeading = section.indexOf('data-wallet-section-heading="linked"');
  assert.ok(connectedPlacement >= 0 && connectedPlacement < firstHeading);
});

test('Current standalone keeps one direct wide Connect button without a wallet-card wrapper', () => {
  assert.doesNotMatch(standalone, /standalone-wallet-connect-block/);
  assert.match(standalone, /data-wallet-section-heading="linked">Привязанные кошельки<\/div><button class="source-button wide secondary"[^>]*id="standaloneWalletConnect"/);
  assert.equal((standalone.match(/id="standaloneWalletConnect"/g) || []).length, 1);
});

test('Current connected session banner semantics remain present', () => {
  const banner = read('frontend/src/components/profile/wallet/WalletConnectBanner.tsx');
  assert.match(banner, /className="efhc-wallet-card"/);
  assert.match(banner, /t\("wallet\.session_connected"\)/);
  assert.match(banner, /t\("wallet\.disconnect_session"\)/);
  assert.match(banner, /t\("wallet\.faq_button"\)/);
});


test('Current linked-wallet state is passed only to the Connect banner', () => {
  const banner = read('frontend/src/components/profile/wallet/WalletConnectBanner.tsx');
  const listItem = read('frontend/src/components/profile/wallet/WalletListItem.tsx');
  assert.match(banner, /hasLinkedWallet: boolean;/);
  const primaryStart = section.indexOf('<WalletPrimaryCard');
  assert.ok(primaryStart >= 0);
  const beforeCards = section.slice(0, primaryStart);
  const walletCards = section.slice(primaryStart);
  assert.equal((beforeCards.match(/hasLinkedWallet=\{serverBoundWallets\.length > 0\}/g) || []).length, 2);
  assert.doesNotMatch(walletCards, /hasLinkedWallet=/);
  assert.doesNotMatch(primary, /hasLinkedWallet/);
  assert.doesNotMatch(listItem, /hasLinkedWallet/);
});
