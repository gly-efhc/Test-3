import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
const root=path.resolve(import.meta.dirname,'../../..');
const txt=(p)=>fs.readFileSync(path.join(root,p),'utf8');
const json=(p)=>JSON.parse(txt(p));
const sha=(b)=>createHash('sha256').update(b).digest('hex');
const htmlFile=fs.readdirSync(root).filter(name=>/^FRONTEND_v\d+\.html$/.test(name));
assert.equal(htmlFile.length,1);
const html=txt(htmlFile[0]);
const canon=fs.readFileSync(path.join(root,'frontend/public/assets/efhc/canon/efhc_logo_canon.svg'));
const catalog=json('frontend/src/design-system/universal-design-catalog.json');
const registry=json('frontend/src/design-system/universal-design-registry.json');
const runtime=txt('frontend/src/lib/interfaceVariantRegistry.ts');

test('OWNER0562 new SVG is canonical for React splash and standalone DEMO, no old source',()=>{
 assert.match(txt('frontend/src/components/SplashScreen.tsx'),/src="\/assets\/efhc\/canon\/efhc_logo_canon.svg"/);
 assert.doesNotMatch(txt('frontend/src/components/SplashScreen.tsx'),/<EfhcJettonLogo/);
 assert.match(html,/id="efhcOwner0562Splash"/);
 const embedded=html.match(/src="data:image\/svg\+xml;base64,([A-Za-z0-9+/=]+)"/);
 assert.ok(embedded);
 assert.equal(sha(Buffer.from(embedded[1],'base64')),sha(canon));
 assert.equal(fs.existsSync(path.join(root,'frontend/public/assets/efhc/EFHC_logo_ETALON_4_gap113_8192.svg')),false);
});
test('OWNER0562 five-second delay is DEMO-only and production React keeps real readiness gate',()=>{
 assert.match(html,/const start=performance\.now\(\);const duration=5000;/);
 assert.match(html,/setTimeout\(function\(\)\{splash\.dataset\.done='true'/);
 assert.doesNotMatch(txt('frontend/src/pages/_app.tsx'),/SPLASH_DEMO_DELAY|duration=5000|setTimeout\([^)]*,5000\)/);
 assert.match(txt('frontend/src/pages/_app.tsx'),/effectiveSplashReady/);
 assert.match(txt('frontend/src/components/SplashScreen.tsx'),/efhc-splash-progress/);
});
test('OWNER0562 236 active design IDs in both machine inventories, no legacy presentation alias data',()=>{
 for(const doc of [catalog,registry]){
  assert.equal(doc.groups.length,29);
  assert.equal(doc.counts.registry_variant_tokens_total,236);
  assert.equal(doc.groups.reduce((sum,g)=>sum+g.variants.length,0),236);
  for(const g of doc.groups){
   assert.equal(g.variant_count,g.variants.length,g.group);
   assert.equal(new Set(g.variants.map(v=>v.id)).size,g.variant_count,g.group);
   for(let i=0;i<g.variants.length;i++){
    const variant=g.variants[i];
    assert.equal(variant.id, g.group==='EI'?'EI-07':`${g.group}-${String(i+1).padStart(2,'0')}`,g.group);
    assert.ok(!Object.hasOwn(variant,'legacy_aliases'),g.group);
    assert.ok(!Object.hasOwn(variant,'canonical_alias'),g.group);
   }
  }
  assert.equal(Object.hasOwn(doc,'alias_contract'),false);
 }
 assert.match(runtime,/BN: numbered\("BN", 5\)/);
 assert.match(runtime,/PB: numbered\("PB", 33\)/);
 assert.match(runtime,/RP: numbered\("RP", 33\)/);
});
test('OWNER0562 existing shared physical design rendering contract remains unchanged',()=>{
 // Non-destructive renderer: 96 non-identical physical style bindings still require planned CSS migration.
 assert.match(runtime,/INTERFACE_VARIANT_STYLE_BINDINGS/);
 const themes=json('frontend/src/design-system/color-theme-registry.json');
 assert.ok(themes);
});
