import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const frontendRoot = path.resolve(here, "../..");
const root = path.resolve(frontendRoot, "..");
const read = (relative) => fs.readFileSync(path.join(root, relative), "utf8");

const layout = read("frontend/src/components/Layout.tsx");
const globals = read("frontend/src/styles/globals.css");
const version = read("VERSION").trim();
const standalone = read(`${version}.html`);

const userDockBottom = /--efhc-user-floating-control-bottom:\s*calc\(\s*4\.72rem\s*\+\s*var\(--efhc-safe-bottom\)\s*\)/;
const userViewportReserve = /--efhc-user-bottom-nav-viewport-reserve:\s*calc\(\s*4\.72rem\s*\+\s*var\(--efhc-safe-bottom\)\s*\)/;
const userContentBoundary = /--efhc-user-bottom-nav-boundary:\s*2\.78rem;/;

test("USER floating Settings dock uses one safe-area-aware shared shell boundary", () => {
  assert.match(globals, userDockBottom);
  assert.match(globals, userViewportReserve);
  assert.match(globals, userContentBoundary);
  assert.match(
    globals,
    /\.efhc-customization-control-dock\s*\{[\s\S]*?bottom:\s*var\(--efhc-user-floating-control-bottom\);/,
  );
  assert.doesNotMatch(
    globals,
    /\.efhc-customization-control-dock\s*\{[\s\S]*?bottom:\s*calc\(4\.72rem \+ env\(/,
  );
});

test("production Layout marks USER dock as shared-shell owned", () => {
  assert.match(
    layout,
    /data-user-floating-boundary=\{\s*isAdminRoute \? undefined : "shared-shell"\s*\}/,
  );
  assert.match(layout, /data-has-bottom-nav=\{!isAdminRoute \? "true" : "false"\}/);
});

test("standalone mirrors dock and final-content clearance tokens", () => {
  assert.match(
    standalone,
    /--efhc-user-floating-control-bottom:calc\(4\.72rem \+ var\(--efhc-safe-bottom\)\)/,
  );
  assert.match(
    standalone,
    /--efhc-user-bottom-nav-boundary:2\.78rem/,
  );
  assert.match(
    standalone,
    /\.customization-control-dock\{position:absolute;right:\.58rem;bottom:var\(--efhc-user-floating-control-bottom\);/,
  );
  assert.match(
    standalone,
    /class="customization-control-dock" data-has-bottom-nav="true" data-user-floating-boundary="shared-shell"/,
  );
});

test("gear size and icon geometry remain unchanged", () => {
  assert.match(globals, /\.efhc-interface-customization-button\s*\{[\s\S]*?width:\s*2\.25rem;[\s\S]*?height:\s*2\.25rem;/);
  assert.match(
    read("frontend/src/components/interface-settings/InterfaceCustomizationButton.tsx"),
    /<svg viewBox="0 0 24 24" fill="none" aria-hidden="true">/,
  );
});

test("Admin remains outside USER Bottom Nav floating boundary", () => {
  assert.match(
    globals,
    /\.efhc-customization-control-dock\[data-has-bottom-nav="false"\]\s*\{\s*bottom:\s*calc\(\.8rem \+ env\(safe-area-inset-bottom, 0px\)\);\s*\}/,
  );
  assert.match(
    standalone,
    /\.customization-control-dock\[data-has-bottom-nav="false"\]\{bottom:calc\(\.8rem \+ env\(safe-area-inset-bottom,0px\)\)\}/,
  );
});
