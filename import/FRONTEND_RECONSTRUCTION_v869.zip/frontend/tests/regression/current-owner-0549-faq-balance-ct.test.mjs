import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
const root = resolve(import.meta.dirname, '../../..');
const read = path => readFileSync(resolve(root,path),'utf8');
const contract=read('frontend/src/styles/owner-0549-faq-balance-ct.css');
const app=read('frontend/src/pages/_app.tsx');
const version=read('VERSION').trim();
const standalone=read(`${version}.html`);

test('0549 CT contract is loaded in React and byte-exact in standalone',()=>{
 assert.match(app,/import "\.\.\/styles\/owner-0549-faq-balance-ct\.css";/);
 const anchor='<style id="owner-0549-faq-balance-ct">\n';
 assert.equal(standalone.split(anchor).length,2);
 assert.ok(standalone.includes(anchor+contract+'</style>'));
 assert.match(standalone,/\s<\/body>\s*<\/html>\s*$/);
 assert.equal((standalone.match(/<style(?:\s|>)/g)||[]).length,(standalone.match(/<\/style>/g)||[]).length);
});
test('0549 FAQ FQ-06 inner CT frames target React and standalone only',()=>{
 assert.match(contract,/data-interface-app-mode="user"/);
 assert.match(contract,/data-color-theme-id/);
 assert.match(contract,/\.efhc-faq-shell\[data-fq="FQ-06"\]/);
 assert.match(contract,/#faqPage\[data-fq="FQ-06"\]/);
 for(const selector of ['.efhc-faq-section-node','.efhc-faq-subsection-node','.efhc-faq-question-node','.release-faq-item','.release-faq-subsection','.release-faq-question','.standalone-faq-index-row']){
  assert.ok(contract.includes(selector),selector);
 }
 assert.match(contract,/border-color:var\(--fq-edge\)!important/);
 assert.doesNotMatch(contract,/\.efhc-admin|\.release-admin|\[data-interface-app-mode="admin"\]/);
});
test('0549 Balance all approved buttons are CT-bound with active distinction',()=>{
 assert.match(contract,/\[data-profile-active-tab="history"\]/);
 for(const selector of ['.efhc-profile-topbar button','.efhc-profile-tabs .efhc-profile-tab','.efhc-history-head-actions > button','.efhc-history-head-actions > a','.efhc-history-filter-row .efhc-history-filter','.source-profile-topbar .source-button','.source-profile-tabs button','.standalone-history-head-actions .source-button','.standalone-history-filters button']){
  assert.ok(contract.includes(selector),selector);
 }
 assert.match(contract,/border-width:1px!important/);
 assert.match(contract,/\.efhc-profile-tab--active/);
 assert.match(contract,/\.efhc-history-filter--active/);
 assert.match(contract,/background-color:rgba\(var\(--efhc-ct-accent-rgb\),\.045\)!important/);
 assert.match(contract,/background-color:rgba\(var\(--efhc-ct-accent-rgb\),\.13\)!important/);
 assert.ok(!contract.includes('rgba(148,163,184'), 'no legacy blue-gray literals');
});
