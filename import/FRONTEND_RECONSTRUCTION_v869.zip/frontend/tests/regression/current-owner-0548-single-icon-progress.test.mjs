import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createRequire } from 'node:module';
import vm from 'node:vm';

const require = createRequire(import.meta.url);
const ts = require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript');
const root = resolve(import.meta.dirname, '../../..');
const src = (n) => readFileSync(resolve(root,n),'utf8');
const transpile = (n) => ts.transpileModule(src(n), {compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const registry={};
vm.runInNewContext(transpile('frontend/src/lib/interfaceVariantRegistry.ts'),{exports:registry,require});
const physical=Array.from({length:35},(_,i)=>i+1).filter(n=>n!==8&&n!==17);
const standalone=src(`${src('VERSION').trim()}.html`);

function jsonFromSource(name) {
 const match = new RegExp(`const ${name} = Object\\.freeze\\((\\{[^\\n]*\\})\\);`).exec(standalone);
 assert.ok(match,`missing standalone ${name}`);
 return JSON.parse(match[1]);
}

test('OWNER 0548: exact one EI-07, selectable PB/RP sequences 01..33 preserve 33 authored identities',()=>{
 assert.deepEqual([...registry.INTERFACE_VARIANT_REGISTRY.EI],['EI-07']);
 assert.equal(registry.DEFAULT_INTERFACE_VARIANTS.EI,'EI-07');
 assert.deepEqual(Object.keys(registry.INTERFACE_VARIANT_STYLE_BINDINGS.EI),[]);
 assert.equal(registry.resolveInterfaceVariantStyle('EI','EI-07'),'EI-07');
 for(const g of ['PB','RP']) {
  const choices=registry.INTERFACE_VARIANT_REGISTRY[g];
  assert.deepEqual([...choices],Array.from({length:33},(_,i)=>`${g}-${String(i+1).padStart(2,'0')}`));
  for(let i=1;i<=33;i++) {
   const id=choices[i-1];
   assert.equal(registry.resolveInterfaceVariantStyle(g,id),`PB-${String(physical[i-1]).padStart(2,'0')}`);
  }
  assert.equal(registry.normalizeInterfaceVariant(g,`${g}-34`),`${g}-01`);
  assert.equal(registry.normalizeInterfaceVariant(g,`${g}-35`),`${g}-01`);
 }
 assert.deepEqual([...registry.getRouteInterfaceGroups('/')],['HS','EG','PB','BN']);
 assert.equal(registry.normalizeInterfaceVariant('EI','EI-01'),'EI-07');
 assert.equal(registry.normalizeInterfaceVariant('EI','EI-06'),'EI-07');
});

test('OWNER 0548: standalone uses same physical design map, fixed SVG and no EI swipe control',()=>{
 const styles=jsonFromSource('SOURCE_STYLE');
 const selected=jsonFromSource('REGISTRY');
 assert.deepEqual(selected.EI,['EI-07']);
 assert.deepEqual(Object.keys(styles.EI),[]);
 assert.equal(selected.EI[0],'EI-07');
 assert.equal(selected.PB.length,33); assert.equal(selected.RP.length,33);
 for(const g of ['PB','RP']) for(const id of selected[g]) assert.equal(styles[g][id] || id,registry.resolveInterfaceVariantStyle(g,id));
 const icons=/const ICONS = Object\.freeze\(\{([\s\S]*?)\n  \}\);/.exec(standalone);
 assert.ok(icons);assert.deepEqual([...icons[1].matchAll(/'(EI-\d\d)':`/g)].map(m=>m[1]),['EI-07']);
 assert.ok(standalone.includes('data-energy-fixed-icon="EI-07"'));
 assert.ok(!standalone.includes('data-swipe-group="EI"'));
 assert.ok(!standalone.includes('["EI","Energy icons"]'));
 assert.match(src('frontend/src/pages/index.tsx'),/registerDots: false/);
 assert.match(src('frontend/src/styles/global-theme-energy-progress-contract.css'),/data-ei="EI-07"/);
});

test('OWNER 0548: v2 settings reset only EI/PB/RP, preserving CT, other designs and preferences',()=>{
 const storage={
   interface_settings_version:2, color_theme_id:'CT-05',global_theme_id:'05',
   lang:'ru',show_decimal_detail:true,
   theme_overrides:{'05':{HS:'HS-02'}},
   interface_variants:{...registry.DEFAULT_INTERFACE_VARIANTS,HS:'HS-02',FQ:'FQ-04',EI:'EI-04',PB:'PB-17',RP:'RP-30'},
   avatar_energy_variant:'EI-05',
 };
 const mocks={
  './i18n':{normalizeLang:v=>v},
  './interfaceVariantRegistry':registry,
  './globalThemeRegistry':{GLOBAL_THEME_CATALOG:[{id:'05'}],GLOBAL_THEME_GROUPS:['HS'],normalizeGlobalThemeId:x=>x},
  './telegram':{telegramCloudStorageGet:async()=>null,telegramCloudStorageSet:async()=>undefined},
  './colorThemeRegistry':{normalizeColorThemeId:x=>x,runtimeLegacyThemeIdForColorTheme:x=>x.slice(-2)},
 };
 const exported={};
 vm.runInNewContext(transpile('frontend/src/lib/settings.ts'),{
   exports:exported,require:(name)=>{if(!mocks[name])throw new Error(name);return mocks[name]},
   window:{localStorage:{getItem:()=>JSON.stringify(storage),setItem:()=>{}}},URL,console,
 });
 const got=exported.loadSettings();
 assert.equal(got.interface_settings_version,4);
 assert.equal(got.color_theme_id,'CT-05');assert.equal(got.global_theme_id,'05');
 assert.equal(got.lang,'ru');assert.equal(got.show_decimal_detail,true);
 assert.equal(got.interface_variants.HS,'HS-02');assert.equal(got.interface_variants.FQ,'FQ-04');
 assert.equal(got.interface_variants.EI,'EI-07');assert.equal(got.interface_variants.PB,'PB-01');assert.equal(got.interface_variants.RP,'RP-01');
 assert.equal(got.avatar_energy_variant,'EI-07');
 assert.equal(got.theme_overrides['05'].HS,'HS-02');
 assert.equal(storage.interface_settings_version,2,'do not mutate legacy record in memory');
});

test('OWNER 0548: all ten CT progress starters still reference valid renamed slots and matching runtime standalone',()=>{
 const color=src('frontend/src/lib/colorThemeRegistry.ts');
 const st=standalone;
 const map=/const CT_PROGRESS_STARTER=Object\.freeze\((\{[^\n]*\})\)/.exec(st);
 assert.ok(map);
 const starters=vm.runInNewContext('('+map[1]+')');
 assert.equal(Object.keys(starters).length,10);
 assert.equal(new Set(Object.values(starters)).size,10);
 for(let i=1;i<=10;i++){
  const ct=`CT-${String(i).padStart(2,'0')}`,v=starters[ct];
  assert.ok(registry.INTERFACE_VARIANT_REGISTRY.PB.includes(v));
  assert.ok(color.includes(`"${ct}": "${v}"`));
 }
});
