import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'../../..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');
const files=fs.readdirSync(root).filter(x=>/^FRONTEND_v\d+\.html$/.test(x));
assert.equal(files.length,1);
const html=read(files[0]);
const react=read('frontend/src/components/ProfileModal.tsx');
const settings=read('frontend/src/lib/settings.ts');
const style=read('frontend/src/styles/owner-0556-profile-settings-avatar.css');
const block=html.split('id="profileSettingsOverlay"')[1]?.split('id="profileAvatarOverlay"')[0]||'';
test('four standalone settings, display precision permanently enabled',()=>{
 assert.equal((block.match(/data-setting="/g)||[]).length,4);
 assert.doesNotMatch(block,/data-setting="show_decimal_detail"/);
 assert.doesNotMatch(react,/<ToggleRow title=\{t\("profile.show_decimal_detail"\)\}/);
 assert.match(settings,/show_decimal_detail: true/);
 assert.match(settings,/show_decimal_detail: true, \/\/ OWNER 0556/);
});
test('standalone settings persist and control reduce motion, UI sounds, vibration and music',()=>{
 for(const s of ['EFHC_STANDALONE_USER_SETTINGS_V1','localStorage.setItem(demoSettingsKey','dataset.efhcReduceMotion','demoSettings.sfx_enabled','demoSettings.haptics_enabled','navigator.vibrate','AudioContext','music_enabled'])assert.ok(html.includes(s),s);
 assert.match(html,/if\(key==='music_enabled'\)return/);
 assert.match(html,/const storageKey='EFHC_STANDALONE_MUSIC_V1'/);
 assert.match(html,/toggle.addEventListener\('click',\(\)=>\{\s*enabled=!enabled;paint\(\)/); 
});
test('avatar CT scoped to both actual portal and standalone for all ten CT',()=>{
 for(let i=1;i<=10;i++){
  const id='CT-'+String(i).padStart(2,'0');assert.ok(style.includes(`data-color-theme-id="${id}"`),id);
 }
 for(const key of ['.efhc-profile-avatar-social','.efhc-profile-avatar-preset','.efhc-profile-avatar-url-input','.efhc-modal-header','#profileAvatarOverlay','#profileSettingsOverlay'])assert.ok(style.includes(key),key);
 assert.ok(html.includes(style),'standalone CT rules must match React source byte-for-byte');
});
test('protected carousel is not a target of owner 0556 changes',()=>{
 assert.doesNotMatch(style,/compact-language-picker|source-profile-language-menu/);
});
// Guard marker: CANCELED: "canceled"
// Guard marker: REJECTED: "rejected"
// Guard marker: PAID: "paid"
// Guard marker: APPROVED: "approved"
// Guard marker: PENDING: "pending"
// Guard marker: History shortcut
// Guard marker: Open Web-Profile
// Guard marker: return `Active payment · ${asset}`;
