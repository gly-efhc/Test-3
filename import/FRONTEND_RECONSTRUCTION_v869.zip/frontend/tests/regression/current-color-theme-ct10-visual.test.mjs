import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
const read = (file) => readFileSync(resolve(root, file), 'utf8');
const css = read('frontend/src/styles/globals.css');
const html = read(`FRONTEND_${read('VERSION').trim().split('_')[1]}.html`);

test('CT10 task rewards have no metallic rectangular backing in React and standalone', () => {
  assert.match(css, /\[data-color-theme-id="CT-10"\] \.efhc-task-card_reward \.efhc-badge\s*\{[^}]*background:transparent!important;[^}]*border-color:transparent!important;[^}]*box-shadow:none!important;/);
  assert.ok(html.includes('[data-color-theme-id="CT-10"] .source-task-card .source-reward{color:var(--efhc-route-accent)!important;border-color:transparent!important;background:transparent!important;box-shadow:none!important}'));
  assert.match(html, /\.source-reward\{display:flex;align-items:center/);
});

test('CT10 active header statuses are text-only; other Color Themes retain their original rules', () => {
  assert.match(css, /\[data-color-theme-id="CT-10"\] \.efhc-status-indicator-context \.efhc-game-header_status\[data-active="true"\]\{\s*text-shadow:none!important/);
  assert.match(html, /\[data-color-theme-id="CT-10"\] \.efhc-status-indicator-context \.efhc-game-header_status\[data-active="true"\]\{text-shadow:none!important/);
  assert.match(css, /\[data-global-theme-id\] \.efhc-status-indicator-context \.efhc-game-header_status\[data-active="true"\]\{[^}]*text-shadow:0 0 5px/);
});

test('CT10 task completion icon uses muted gold and dark material only in Tasks', () => {
  assert.match(css, /\[data-color-theme-id="CT-10"\] \.efhc-tasks-shell \.efhc-game-hero_icon\{[^}]*color:var\(--efhc-route-accent\)!important;[^}]*background:rgba\(var\(--efhc-route-accent-rgb\),\.025\)!important/);
  assert.match(html, /\[data-color-theme-id="CT-10"\] #tasksPage \.source-hero-icon\{color:var\(--efhc-route-accent\)!important/);
});

test('CT10 shared active bottom navigation is not repainted by this continuation', () => {
  assert.match(css, /\[data-global-theme-id\] \.efhc-game-nav_item\[data-active="true"\]/);
  assert.doesNotMatch(css.slice(css.indexOf('Cycle0464/03: Tasks completion icon'), css.indexOf('/* v296 chroma firewall')), /\.efhc-game-nav_item\[data-active="true"\]/);
});
