import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const read=path=>fs.readFileSync(`${root}/${path}`,'utf8');
const langs=['ru','en','uk','de','fr','es','it','pt','tr','pl','da','id','hi','sw','ko','ja'];
const currentFrontend=fs.readdirSync(root).filter(x=>/^FRONTEND_v\d+\.html$/.test(x));
assert.equal(currentFrontend.length,1);
const demo=read(currentFrontend[0]);
const seeds=read('backend/app/release/initial_data.py');
const server=read('backend/app/services/admin/admin_hub_links_service.py');
const react=read('frontend/src/features/hub/HubPage.tsx');

const expected=['efhc_buy','vip_getgems','efhc_ceo','efhc_admin'];
test('Four fixed HUB identities keep immutable names/order and distinct initial contact addresses',()=>{
 const rules=read('backend/app/services/hub_reserved_links.py');
 for (const [i,key] of expected.entries()) {
   assert.match(rules,new RegExp(`"${key}": \\(.*?, ${(i+1)*10}\\)`));
   assert.match(seeds,new RegExp(`"${key}": \\{`));
   assert.ok(demo.includes(`code:'${key}'`));
 }
 assert.match(seeds,/"efhc_admin":\s*\{[\s\S]*?"url": "https:\/\/t\.me\/EFHC_Administrator"/);
 assert.match(seeds,/"efhc_ceo":\s*\{[\s\S]*?"url": "https:\/\/t\.me\/EFHC_Official"/);
 assert.match(demo,/code:'efhc_admin',title:'Админ',subtitle:null,url:'https:\/\/t\.me\/EFHC_Administrator'/);
 assert.match(demo,/code:'efhc_ceo',title:'CEO EFHC',subtitle:null,url:'https:\/\/t\.me\/EFHC_Official'/);
});
test('Seeding does not reset a changed URL/visibility, and server refuses renamed/deleted/reordered fixed slots',()=>{
 assert.match(seeds,/ON CONFLICT \(code\) DO UPDATE SET/);
 const conflict=seeds.split('ON CONFLICT (code) DO UPDATE SET')[1].split('"',1)[0];
 assert.doesNotMatch(conflict,/url|is_active/);
 assert.match(server,/protected HUB title\/position cannot be edited/);
 assert.match(server,/protected HUB position cannot be changed/);
 assert.match(server,/protected HUB link cannot be deleted/);
 assert.match(server,/link\.is_active = bool\(is_active\)/);
 assert.match(server,/await db\.delete\(link\)/);
 assert.match(read('backend/app/routes/admin_hub_routes.py'),/@router\.delete\("\/links\/\{link_id\}"/);
});
test('React HUB fails closed on unavailable API, uses server URL and visibility, with four fixed display slots',()=>{
 assert.match(react,/publicLinks\.data \?\? \[\]/);
 assert.match(react,/filter\(\(link\) => link\.is_active\)/);
 assert.match(react,/const fixed = \["efhc_buy", "vip_getgems", "efhc_ceo", "efhc_admin"\]/);
 assert.match(react,/shop \? t\("hub.action_shop"\)/);
 assert.match(react,/link\.code === "efhc_admin" \? t\("hub.action_admin"\)/);
 assert.match(react,/openTelegramLink\(link\.url\)/);
});
test('Semantic labels for Admin and CEO EFHC exist in 16 locale sources; standalone lookup agrees',()=>{
 const expectedAdmin={ru:'Админ',uk:'Адміністратор',en:'Administrator',de:'Administrator',fr:'Administrateur',es:'Administrador',it:'Amministratore',pt:'Administrador',tr:'Yönetici',pl:'Administrator',da:'Administrator',id:'Administrator',hi:'प्रशासक',sw:'Msimamizi',ko:'관리자',ja:'管理者'};
 for (const lang of langs){
  const locale=JSON.parse(read(`frontend/public/locale/${lang}.json`));
  assert.equal(locale['hub.action_admin'],expectedAdmin[lang],lang);
  assert.equal(locale['hub.action_ceo'],'CEO EFHC',lang);
  assert.ok(demo.includes(`"${lang}":"${expectedAdmin[lang]}"`),`standalone ${lang}`);
 }
 assert.match(demo,/standaloneHubTitleV559/);
 assert.match(demo,/standaloneHubNormalizeV559\(loadStandaloneAdminState\(\)\)/);
 assert.match(demo,/data-admin-hub-toggle-v559/);
});
test('Other HUB links are removable but protected codes cannot be overwritten in standalone simulator',()=>{
 assert.match(demo,/protected HUB link cannot be deleted/);
 assert.match(demo,/protected HUB title\/order/);
 assert.match(demo,/protected HUB order/);
 assert.match(demo,/hubLinks=standaloneAdminState\.hubLinks\.filter/);
 assert.match(read('frontend/src/features/admin/AdminHubPage.tsx'),/ADMIN_HUB_LINKS_LINK_ID_PATH/);
});
