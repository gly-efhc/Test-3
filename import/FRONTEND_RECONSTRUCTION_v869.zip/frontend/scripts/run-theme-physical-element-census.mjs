import fs from "node:fs";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, "../..");
const DEFAULT_PLAN = path.join(
  ROOT,
  "frontend/tests/visual/theme01-physical-census-scenes.json",
);
const COLOR_CANON = path.join(
  ROOT,
  "frontend/src/design-system/global-theme-color-canon.json",
);

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const readJson = (file) => JSON.parse(fs.readFileSync(file, "utf8"));

async function freePort() {
  return await new Promise((resolve, reject) => {
    const server = net.createServer();
    server.unref();
    server.on("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      const port = typeof address === "object" && address ? address.port : 0;
      server.close(() => resolve(port));
    });
  });
}

function chromiumBinary() {
  const candidates = [
    process.env.CHROMIUM_BIN,
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/usr/bin/google-chrome",
  ].filter(Boolean);
  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) return candidate;
  }
  throw new Error("Chromium executable not found. Set CHROMIUM_BIN.");
}

class Cdp {
  constructor(ws) {
    this.ws = ws;
    this.nextId = 1;
    this.pending = new Map();
    ws.addEventListener("message", (event) => {
      const payload = JSON.parse(String(event.data));
      if (!payload.id) return;
      const item = this.pending.get(payload.id);
      if (!item) return;
      this.pending.delete(payload.id);
      if (payload.error) {
        item.reject(new Error(payload.error.message || JSON.stringify(payload.error)));
      } else {
        item.resolve(payload.result || {});
      }
    });
  }

  send(method, params = {}) {
    const id = this.nextId;
    this.nextId += 1;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }

  async evaluate(expression) {
    const result = await this.send("Runtime.evaluate", {
      expression,
      awaitPromise: true,
      returnByValue: true,
    });
    if (result.exceptionDetails) {
      throw new Error(result.exceptionDetails.text || "Runtime.evaluate failed");
    }
    return result.result?.value;
  }

  close() {
    try {
      this.ws.close();
    } catch {}
  }
}

async function waitJson(url, attempts = 80) {
  let last;
  for (let index = 0; index < attempts; index += 1) {
    try {
      const response = await fetch(url);
      if (response.ok) return await response.json();
      last = new Error(`${response.status} ${response.statusText}`);
    } catch (error) {
      last = error;
    }
    await sleep(50);
  }
  throw last || new Error(`Timed out: ${url}`);
}

async function openBrowser(width, height) {
  const port = await freePort();
  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), "efhc-census-"));
  const child = spawn(
    chromiumBinary(),
    [
      "--headless=new",
      "--no-sandbox",
      "--disable-gpu",
      "--disable-dev-shm-usage",
      `--remote-debugging-port=${port}`,
      `--user-data-dir=${userDataDir}`,
      "about:blank",
    ],
    { stdio: "ignore" },
  );
  const version = await waitJson(`http://127.0.0.1:${port}/json/version`);
  const target = await fetch(
    `http://127.0.0.1:${port}/json/new?${encodeURIComponent("about:blank")}`,
    { method: "PUT" },
  ).then((response) => response.json());
  const ws = new WebSocket(target.webSocketDebuggerUrl || version.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener("open", resolve, { once: true });
    ws.addEventListener("error", reject, { once: true });
  });
  const cdp = new Cdp(ws);
  await cdp.send("Page.enable");
  await cdp.send("Runtime.enable");
  await cdp.send("Emulation.setDeviceMetricsOverride", {
    width,
    height,
    deviceScaleFactor: 1,
    mobile: true,
  });
  return { cdp, child, userDataDir };
}

async function closeBrowser(browser) {
  browser.cdp.close();
  if (browser.child.exitCode === null) {
    browser.child.kill("SIGTERM");
    await Promise.race([
      new Promise((resolve) => browser.child.once("exit", resolve)),
      sleep(750),
    ]);
  }
  if (browser.child.exitCode === null) browser.child.kill("SIGKILL");
  await sleep(80);
  fs.rmSync(browser.userDataDir, {
    recursive: true,
    force: true,
    maxRetries: 5,
    retryDelay: 80,
  });
}

async function loadContent(cdp, file) {
  const frameTree = await cdp.send("Page.getFrameTree");
  const frameId = frameTree.frameTree?.frame?.id;
  if (!frameId) throw new Error("Chromium main frame unavailable.");
  const html = fs.readFileSync(path.resolve(file), "utf8");
  await cdp.send("Page.setDocumentContent", { frameId, html });
  for (let index = 0; index < 100; index += 1) {
    const state = await cdp.evaluate("document.readyState").catch(() => "");
    if (state === "complete") {
      await sleep(90);
      return;
    }
    await sleep(40);
  }
  throw new Error("Document did not reach readyState=complete.");
}

async function configureFrontend(cdp, themeId) {
  for (let index = 0; index < 50; index += 1) {
    const current = await cdp.evaluate(
      "document.querySelector('.efhc-independent-shell')?.dataset.globalThemeId || ''",
    );
    if (current) break;
    await sleep(40);
  }
  let current = await cdp.evaluate(
    "document.querySelector('.efhc-independent-shell')?.dataset.globalThemeId || ''",
  );
  if (!current) throw new Error("Standalone Global Theme marker unavailable.");
  if (current === themeId) return;
  const enteredEditing = await cdp.evaluate(`(() => {
    if (document.documentElement.dataset.customizationMode === 'editing') return true;
    const customize = document.querySelector('#customizeButton');
    if (!customize) return false;
    customize.click();
    return document.documentElement.dataset.customizationMode === 'editing';
  })()`);
  if (!enteredEditing) {
    throw new Error(`Unable to enter customization mode for Theme ${themeId}`);
  }
  for (let index = 0; index < 15; index += 1) {
    current = await cdp.evaluate(
      "document.querySelector('.efhc-independent-shell')?.dataset.globalThemeId || ''",
    );
    if (current === themeId) break;
    const cycled = await cdp.evaluate(`(() => {
      const node=document.querySelector('#globalThemeControl');
      if(!node)return false;
      node.click();
      return true;
    })()`);
    if (!cycled) break;
    await sleep(45);
  }
  current = await cdp.evaluate(
    "document.querySelector('.efhc-independent-shell')?.dataset.globalThemeId || ''",
  );
  if (current !== themeId) {
    throw new Error(`Unable to activate Theme ${themeId}; current=${current}`);
  }
  await cdp.evaluate(`(() => {
    if (document.documentElement.dataset.customizationMode !== 'editing') return true;
    document.querySelector('#customizeButton')?.click();
    return true;
  })()`);
  await sleep(80);
}

async function configureShop(cdp, themeId) {
  await cdp.evaluate(`(() => {
    document.documentElement.dataset.shopTheme='dark';
    document.documentElement.dataset.globalThemeId=${JSON.stringify(themeId)};
    if(typeof shopTheme!=='undefined')shopTheme='dark';
    return true;
  })()`);
  await sleep(80);
}

async function routeFrontend(cdp, route) {
  const nativeSelectors = {
    "/": '.efhc-game-nav_item[data-route="/"]',
    "/panels": '.efhc-game-nav_item[data-route="/panels"]',
    "/exchange": '.efhc-game-nav_item[data-route="/exchange"]',
    "/tasks": '.efhc-game-nav_item[data-route="/tasks"]',
    "/referrals": '.efhc-game-nav_item[data-route="/referrals"]',
    "/ranks": '.efhc-game-nav_item[data-route="/ranks"]',
    "/panels/portfolio": '[data-route-direct="/panels/portfolio"]',
    "/referrals/my": '[data-route-direct="/referrals/my"]',
    "/web-profile": "[data-profile-open]",
    "/faq": '[data-route-direct="/faq"]',
    "/withdraw": '[data-route-direct="/withdraw"]',
    "/hub": '.efhc-header-action[data-action="HUB"]',
  };
  const selector = nativeSelectors[route];
  if (selector) {
    const clicked = await cdp.evaluate(`(() => {
      const node=document.querySelector(${JSON.stringify(selector)});
      if(!node)return false;
      node.click();
      return true;
    })()`);
    if (clicked) {
      await sleep(90);
      return;
    }
  }
  const techIndexes = {
    "/": 1,
    "/panels": 3,
    "/exchange": 4,
    "/tasks": 5,
    "/referrals": 6,
    "/ranks": 7,
    "/web-profile": 8,
    "/hub": 9,
    "/faq": 10,
    "/withdraw": 11,
    "/ads": 12,
    "/404": 14,
  };
  const index = techIndexes[route];
  if (index !== undefined) {
    const clicked = await cdp.evaluate(`(() => {
      const node=document.querySelector('[data-tech-page-index="${index}"]');
      if(!node)return false;
      node.click();
      return true;
    })()`);
    if (clicked) {
      await sleep(90);
      return;
    }
  }
  throw new Error(`No standalone route control for ${route}`);
}

async function runSetup(cdp, setup = []) {
  for (const expression of setup) {
    await cdp.evaluate(`(() => { ${expression}; return true; })()`);
    await sleep(70);
  }
}

function anchorForTheme(canon, themeId) {
  const theme = canon.themes.find((item) => item.id === themeId);
  if (!theme) throw new Error(`Theme ${themeId} absent from color canon.`);
  return theme;
}

async function captureCensus(cdp, sceneId, surface, width, theme) {
  return await cdp.evaluate(`(() => {
    const sceneId=${JSON.stringify(sceneId)};
    const surface=${JSON.stringify(surface)};
    const width=${Number(width)};
    const theme=${JSON.stringify(theme)};
    const properties=[
      'backgroundColor','backgroundImage','color','borderTopColor',
      'borderRightColor','borderBottomColor','borderLeftColor','outlineColor',
      'outlineStyle','boxShadow','textShadow','fill','stroke','filter','opacity',
      'caretColor','accentColor','textDecorationColor','columnRuleColor'
    ];
    const visualTags=new Set(['path','line','circle','ellipse','rect','polyline','polygon','use','text']);
    const excludedSvgTags=new Set(['defs','clippath','mask','lineargradient','radialgradient','stop','symbol','marker']);
    const interactiveTags=new Set(['a','button','input','select','textarea','summary','option']);
    const roleInteractive=new Set(['button','link','tab','switch','checkbox','radio','option','menuitem']);
    const visible=(node)=>{
      if(!(node instanceof Element))return false;
      const clientRects=node.getClientRects();
      if(!clientRects.length)return false;
      const style=getComputedStyle(node);
      if(style.display==='none'||style.visibility==='hidden'||Number(style.opacity||1)===0)return false;
      const tag=node.localName?.toLowerCase()||'';
      if(excludedSvgTags.has(tag))return false;
      const rect=node.getBoundingClientRect();
      if(rect.width>0&&rect.height>0)return true;
      if(node instanceof SVGElement&&visualTags.has(tag)){
        const svg=node.closest('svg');
        if(!svg)return false;
        const svgRect=svg.getBoundingClientRect();
        return svgRect.width>0&&svgRect.height>0;
      }
      return false;
    };
    const esc=(value)=>{
      if(globalThis.CSS?.escape)return CSS.escape(String(value));
      return String(value).replace(/[^a-zA-Z0-9_-]/g,'\\$&');
    };
    const pathFor=(node)=>{
      if(node.id)return '#'+esc(node.id);
      const parts=[];
      let current=node;
      while(current&&current.nodeType===1&&parts.length<7){
        let part=current.localName.toLowerCase();
        const classes=[...current.classList].filter(Boolean).slice(0,3);
        if(classes.length)part+='.'+classes.map(esc).join('.');
        const parent=current.parentElement;
        if(parent){
          const peers=[...parent.children].filter((item)=>item.localName===current.localName);
          if(peers.length>1)part+=':nth-of-type('+(peers.indexOf(current)+1)+')';
        }
        parts.unshift(part);
        if(current.id)break;
        current=parent;
      }
      return parts.join(' > ');
    };
    const stateFor=(node)=>{
      const tag=node.localName.toLowerCase();
      const role=(node.getAttribute('role')||'').toLowerCase();
      const tabAttr=node.getAttribute('tabindex');
      const tabIndex=tabAttr===null?Number.NaN:Number(tabAttr);
      const interactive=interactiveTags.has(tag)||roleInteractive.has(role)||(Number.isFinite(tabIndex)&&tabIndex>=0)||typeof node.onclick==='function';
      const capabilities=[];
      if(interactive)capabilities.push('hover','active','focus','focus-visible');
      if(tag==='input'){
        const type=(node.getAttribute('type')||'text').toLowerCase();
        if(['checkbox','radio'].includes(type))capabilities.push('checked');
      }
      if(tag==='details'||tag==='summary')capabilities.push('expanded');
      if(role==='tab'||node.hasAttribute('aria-selected'))capabilities.push('selected');
      if(role==='switch'||node.hasAttribute('aria-checked'))capabilities.push('checked');
      return {
        interactive,
        capabilities:[...new Set(capabilities)].sort(),
        current:{
          disabled:node.matches(':disabled'),
          checked:node.matches(':checked'),
          selected:node.matches(':checked,[aria-selected="true"],[data-active="true"]'),
          focused:document.activeElement===node,
          open:node.hasAttribute('open'),
          ariaPressed:node.getAttribute('aria-pressed'),
          ariaSelected:node.getAttribute('aria-selected'),
          ariaExpanded:node.getAttribute('aria-expanded'),
          ariaChecked:node.getAttribute('aria-checked'),
          dataActive:node.getAttribute('data-active')
        }
      };
    };
    const styleObject=(node,pseudo=null)=>{
      const style=getComputedStyle(node,pseudo);
      const out={};
      for(const property of properties)out[property]=style[property]??'';
      return out;
    };
    const pseudoGenerated=(node,pseudo)=>{
      const style=getComputedStyle(node,pseudo);
      const content=style.content;
      if(content==='none'||content==='normal')return false;
      if(style.display==='none'||style.visibility==='hidden'||Number(style.opacity||1)===0)return false;
      return true;
    };
    const entries=[];
    for(const node of document.querySelectorAll('*')){
      if(!visible(node))continue;
      const rect=node.getBoundingClientRect();
      const base={
        sceneId,surface,width,
        path:pathFor(node),
        tag:node.localName.toLowerCase(),
        id:node.id||null,
        classes:[...node.classList].sort(),
        role:node.getAttribute('role'),
        state:stateFor(node),
        rect:{x:rect.x,y:rect.y,width:rect.width,height:rect.height},
        style:styleObject(node),
        inlineStyle:node.getAttribute('style')||null,
        pseudo:null,
        themeAnchor:theme.accent
      };
      entries.push(base);
      for(const pseudo of ['::before','::after']){
        if(!pseudoGenerated(node,pseudo))continue;
        entries.push({
          ...base,
          path:base.path+pseudo,
          pseudo,
          state:{interactive:false,capabilities:[],current:{}},
          style:styleObject(node,pseudo)
        });
      }
    }
    return {
      sceneId,
      surface,
      width,
      bodyElements:document.querySelectorAll('*').length,
      renderedElements:entries.length,
      entries
    };
  })()`);
}

function extractColorTokens(value) {
  if (!value) return [];
  const matches = String(value).match(
    /rgba?\([^)]*\)|color\(srgb[^)]*\)|#[0-9a-f]{3,8}/gi,
  );
  return matches || [];
}

function parseColor(token) {
  const text = token.trim().toLowerCase();
  if (text.startsWith("#")) {
    const hex = text.slice(1);
    const expand = (part) => part.split("").map((item) => item + item).join("");
    const value = hex.length <= 4 ? expand(hex) : hex;
    if (![6, 8].includes(value.length)) return null;
    return {
      r: Number.parseInt(value.slice(0, 2), 16),
      g: Number.parseInt(value.slice(2, 4), 16),
      b: Number.parseInt(value.slice(4, 6), 16),
      a: value.length === 8 ? Number.parseInt(value.slice(6, 8), 16) / 255 : 1,
    };
  }
  if (text.startsWith("color(srgb")) {
    const body = text.replace(/^color\(srgb\s*/, "").replace(/\)$/, "");
    const [channels, alphaRaw] = body.split("/").map((part) => part.trim());
    const nums = channels.split(/\s+/).map(Number);
    if (nums.length < 3 || nums.some((value) => Number.isNaN(value))) return null;
    return {
      r: Math.round(nums[0] * 255),
      g: Math.round(nums[1] * 255),
      b: Math.round(nums[2] * 255),
      a: alphaRaw === undefined ? 1 : Number(alphaRaw),
    };
  }
  if (text.startsWith("rgb")) {
    const body = text.replace(/^rgba?\(/, "").replace(/\)$/, "").trim();
    const [channels, alphaRaw] = body.split("/").map((part) => part.trim());
    const nums = channels.includes(",")
      ? channels.split(",").map((part) => Number(part.trim()))
      : channels.split(/\s+/).map(Number);
    if (nums.length < 3 || nums.slice(0, 3).some(Number.isNaN)) return null;
    let alpha = alphaRaw === undefined ? 1 : Number(alphaRaw);
    if (channels.includes(",") && nums.length > 3) alpha = nums[3];
    return { r: nums[0], g: nums[1], b: nums[2], a: alpha };
  }
  return null;
}

function rgbToHsl({ r, g, b }) {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const delta = max - min;
  let hue = 0;
  if (delta) {
    if (max === rn) hue = 60 * (((gn - bn) / delta) % 6);
    else if (max === gn) hue = 60 * ((bn - rn) / delta + 2);
    else hue = 60 * ((rn - gn) / delta + 4);
  }
  if (hue < 0) hue += 360;
  const lightness = (max + min) / 2;
  const saturation = delta === 0 ? 0 : delta / (1 - Math.abs(2 * lightness - 1));
  return { hue, saturation, lightness };
}

function hueDistance(left, right) {
  const raw = Math.abs(left - right) % 360;
  return Math.min(raw, 360 - raw);
}

function classifyColor(token, anchorHue) {
  const rgba = parseColor(token);
  if (!rgba) return { token, class: "UNKNOWN_COLOR_SYNTAX" };
  if (!Number.isFinite(rgba.a) || rgba.a <= 0.001) {
    return { token, rgba, class: "TRANSPARENT" };
  }
  const hsl = rgbToHsl(rgba);
  if (hsl.saturation < 0.12) {
    return { token, rgba, hsl, class: "NEUTRAL" };
  }
  if (hueDistance(hsl.hue, anchorHue) <= 32) {
    return { token, rgba, hsl, class: "THEME_HUE_FAMILY" };
  }
  return { token, rgba, hsl, class: "FOREIGN_CHROMA_CANDIDATE" };
}

function enrichEntries(result, theme) {
  const anchor = parseColor(theme.accent);
  const anchorHue = rgbToHsl(anchor).hue;
  const paletteProperties = [
    "backgroundColor",
    "backgroundImage",
    "color",
    "borderTopColor",
    "borderRightColor",
    "borderBottomColor",
    "borderLeftColor",
    "outlineColor",
    "boxShadow",
    "textShadow",
    "fill",
    "stroke",
    "caretColor",
    "accentColor",
    "textDecorationColor",
    "columnRuleColor",
  ];
  for (const entry of result.entries) {
    const colours = [];
    for (const property of paletteProperties) {
      for (const token of extractColorTokens(entry.style[property])) {
        colours.push({ property, ...classifyColor(token, anchorHue) });
      }
    }
    entry.colours = colours;
    entry.palette = {
      themeFamily: colours.filter((item) => item.class === "THEME_HUE_FAMILY").length,
      neutral: colours.filter((item) => item.class === "NEUTRAL").length,
      foreignCandidates: colours
        .filter((item) => item.class === "FOREIGN_CHROMA_CANDIDATE")
        .map((item) => ({ property: item.property, token: item.token })),
    };
  }
  return result;
}

function mergeObservation(map, entry) {
  const key = [entry.surface, entry.sceneId, entry.path, entry.pseudo || ""].join("|");
  const existing = map.get(key);
  const observation = {
    width: entry.width,
    rect: entry.rect,
    style: entry.style,
    state: entry.state,
    colours: entry.colours,
    palette: entry.palette,
  };
  if (!existing) {
    map.set(key, {
      key,
      surface: entry.surface,
      sceneId: entry.sceneId,
      path: entry.path,
      pseudo: entry.pseudo,
      tag: entry.tag,
      id: entry.id,
      classes: entry.classes,
      role: entry.role,
      inlineStyle: entry.inlineStyle,
      themeAnchor: entry.themeAnchor,
      viewports: [entry.width],
      observations: [observation],
    });
    return;
  }
  if (!existing.viewports.includes(entry.width)) existing.viewports.push(entry.width);
  existing.observations.push(observation);
}

async function runScene(browser, file, scene, surface, themeId, width, theme) {
  await loadContent(browser.cdp, file);
  if (surface === "frontend") {
    await configureFrontend(browser.cdp, themeId);
    await routeFrontend(browser.cdp, scene.route);
  } else {
    await configureShop(browser.cdp, themeId);
  }
  await runSetup(browser.cdp, scene.setup);
  const captured = await captureCensus(
    browser.cdp,
    scene.id,
    surface,
    width,
    theme,
  );
  return enrichEntries(captured, theme);
}

async function runSurface({ file, scenes, surface, widths, height, themeId, theme }) {
  const results = [];
  for (const width of widths) {
    const browser = await openBrowser(width, height);
    try {
      for (const scene of scenes) {
        try {
          results.push(
            await runScene(browser, file, scene, surface, themeId, width, theme),
          );
        } catch (error) {
          results.push({
            sceneId: scene.id,
            surface,
            width,
            error: String(error?.message || error),
            bodyElements: 0,
            renderedElements: 0,
            entries: [],
          });
        }
      }
    } finally {
      await closeBrowser(browser);
    }
  }
  return results;
}

async function main() {
  const args = process.argv.slice(2);
  const get = (name, fallback = null) => {
    const index = args.indexOf(name);
    return index >= 0 ? args[index + 1] : fallback;
  };
  const frontend = get("--frontend");
  const shop = get("--shop");
  const themeId = String(get("--theme", "01")).padStart(2, "0");
  const plan = readJson(path.resolve(get("--plan", DEFAULT_PLAN)));
  const requestedScenes = String(get("--scenes", "")).split(",").map((item) => item.trim()).filter(Boolean);
  const pickScenes = (items) => requestedScenes.length ? items.filter((item) => requestedScenes.includes(item.id)) : items;
  const canon = readJson(COLOR_CANON);
  const theme = anchorForTheme(canon, themeId);
  const widths = String(get("--widths", plan.viewports.join(",")))
    .split(",")
    .map((item) => Number(item.trim()))
    .filter((item) => Number.isFinite(item) && item > 0);
  const height = Number(get("--height", String(plan.height || 844)));
  if (!frontend || !shop) {
    throw new Error("--frontend and --shop are required.");
  }
  const raw = [
    ...(await runSurface({
      file: frontend,
      scenes: pickScenes(plan.frontendScenes),
      surface: "frontend",
      widths,
      height,
      themeId,
      theme,
    })),
    ...(await runSurface({
      file: shop,
      scenes: pickScenes(plan.shopScenes),
      surface: "shop",
      widths,
      height,
      themeId,
      theme,
    })),
  ];
  const merged = new Map();
  for (const scene of raw) {
    for (const entry of scene.entries || []) mergeObservation(merged, entry);
  }
  const entries = [...merged.values()].sort((left, right) =>
    left.key.localeCompare(right.key),
  );
  const sceneSummary = raw.map((scene) => ({
    sceneId: scene.sceneId,
    surface: scene.surface,
    width: scene.width,
    bodyElements: scene.bodyElements,
    renderedElements: scene.renderedElements,
    error: scene.error || null,
  }));
  const foreign = [];
  for (const entry of entries) {
    for (const observation of entry.observations) {
      for (const candidate of observation.palette.foreignCandidates) {
        foreign.push({
          surface: entry.surface,
          sceneId: entry.sceneId,
          path: entry.path,
          pseudo: entry.pseudo,
          width: observation.width,
          property: candidate.property,
          token: candidate.token,
        });
      }
    }
  }
  const uniqueForeign = new Map();
  for (const item of foreign) {
    const key = [item.surface, item.path, item.pseudo || "", item.property, item.token].join("|");
    if (!uniqueForeign.has(key)) uniqueForeign.set(key, item);
  }
  const output = {
    schema: "EFHC_THEME_PHYSICAL_ELEMENT_CENSUS_V1",
    cycle: plan.cycle || "FRONTEND_ADMIN_CYCLE_0392",
    theme: {
      id: theme.id,
      name: theme.name,
      accent: theme.accent,
      colorNameRu: theme.colorNameRu,
    },
    baselineRelease: plan.baselineRelease,
    viewports: widths,
    height,
    censusLaw: {
      semanticMatrixIsIndexOnly: true,
      everyRenderedElementIsCensused: true,
      pseudoElementsIncluded: true,
      svgElementsIncluded: true,
      paletteMismatchIsErrorCandidate: true,
      semanticExceptionsRequireProvenanceResolutionNextCycle: true,
      nextProvenanceCycle: plan.nextCycle || "FRONTEND_ADMIN_CYCLE_0393",
    },
    scenes: sceneSummary,
    totals: {
      sceneViewportRuns: sceneSummary.length,
      failedSceneViewportRuns: sceneSummary.filter((item) => item.error).length,
      uniqueRenderedElementStateRecords: entries.length,
      uniqueForeignChromaCandidates: uniqueForeign.size,
      interactiveRecords: entries.filter((item) =>
        item.observations.some((obs) => obs.state.interactive),
      ).length,
      pseudoRecords: entries.filter((item) => item.pseudo).length,
      svgRecords: entries.filter((item) =>
        ["svg", "path", "line", "circle", "ellipse", "rect", "polyline", "polygon", "use", "text"].includes(item.tag),
      ).length,
    },
    foreignChromaCandidates: [...uniqueForeign.values()].sort((left, right) =>
      `${left.surface}|${left.path}|${left.property}|${left.token}`.localeCompare(
        `${right.surface}|${right.path}|${right.property}|${right.token}`,
      ),
    ),
    entries,
    note: `${plan.cycle || "Physical census"} inventory only. Foreign chroma candidates are not waived by similarity; ${plan.nextCycle || "the next provenance cycle"} must resolve each against the frozen palette and explicit semantic/status/brand/accessibility exceptions with cascade provenance.`,
  };
  const serialized = JSON.stringify(output, null, 2) + "\n";
  const outPath = get("--output");
  if (outPath) fs.writeFileSync(path.resolve(outPath), serialized);
  process.stdout.write(JSON.stringify({
    schema: output.schema,
    theme: output.theme,
    totals: output.totals,
  }, null, 2) + "\n");
  process.exitCode = output.totals.failedSceneViewportRuns === 0 ? 0 : 1;
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  main().catch((error) => {
    console.error(String(error?.stack || error));
    process.exit(2);
  });
}
