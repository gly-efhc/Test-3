import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, "../..");
const REGISTRY_PATH = path.join(ROOT, "frontend/src/design-system/global-theme-projection-registry.json");
const ROLE_SCHEMA_PATH = path.join(ROOT, "frontend/src/design-system/global-theme-role-schema.json");
const COLOR_CANON_PATH = path.join(ROOT, "frontend/src/design-system/global-theme-color-canon.json");

const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));
const normalizeHex = (value) => String(value || "").toUpperCase();
const rel = (p) => path.relative(ROOT, p).split(path.sep).join("/");
const resolveRoot = (p) => path.join(ROOT, p);
const writeStates = new Set(["READY_FOR_GENERATION", "PARTIAL_PROJECTION_AUTHORIZED", "QUALIFIED"]);
const rawColorLiteral = /(?:#[0-9a-fA-F]{3,8}\b|\brgba?\s*\(|\bhsla?\s*\()/;

function loadAuthority() {
  const registry = readJson(REGISTRY_PATH);
  const roleSchema = readJson(ROLE_SCHEMA_PATH);
  const colorCanon = readJson(COLOR_CANON_PATH);
  return { registry, roleSchema, colorCanon };
}

function targetFor(registry, themeId) {
  const target = registry.targets.find((item) => item.id === themeId);
  if (!target) throw new Error(`Unknown projection target theme: ${themeId}`);
  return target;
}

function validateRoleVector(vector, target, roleSchema) {
  const errors = [];
  const roles = vector?.roles || {};
  if (vector?.schema !== "EFHC_GLOBAL_THEME_ROLE_VECTOR_V1") errors.push("role-vector-schema");
  if (vector?.themeId !== target.id) errors.push("role-vector-theme-id");
  if (normalizeHex(vector?.accentAnchor) !== normalizeHex(target.accent)) errors.push("accent-anchor-mismatch");
  if (normalizeHex(roles.accent) !== normalizeHex(target.accent)) errors.push("accent-role-mismatch");
  const expected = roleSchema.roleOrder || [];
  if (Object.keys(roles).length !== expected.length || expected.some((key) => typeof roles[key] !== "string" || !roles[key].trim())) {
    errors.push("role-vector-exact-18");
  }
  if (Object.keys(roles).some((key) => !expected.includes(key))) errors.push("role-vector-extra-role");
  if (!writeStates.has(String(vector?.projectionState))) errors.push("role-vector-not-authorized");
  return errors;
}

function tokenName(role) {
  return `--efhc-color-${role.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`)}`;
}

function renderTokenBlock(themeId, roles) {
  const lines = Object.entries(roles).map(([role, value]) => `    ${tokenName(role)}:${value};`).join("\n");
  return `@layer efhc-theme-tokens {\n` +
    `  [data-interface-app-mode="user"][data-global-theme-id="${themeId}"],\n` +
    `  :root:has(.efhc-profile-modal-theme[data-pm="PM-${themeId}"]),\n` +
    `  :root:has(.efhc-independent-shell[data-interface-app-mode="user"][data-global-theme-id="${themeId}"]),\n` +
    `  .efhc-shop-site[data-interface-app-mode="shop-landing"][data-shop-theme="dark"][data-global-theme-id="${themeId}"],\n` +
    `  html[data-shop-theme="dark"][data-global-theme-id="${themeId}"] {\n${lines}\n  }\n}\n`;
}

function validateAdapter(text, target, matrix) {
  const errors = [];
  if (!text.trim()) return errors;
  if (text.includes('data-global-theme-id="03"') || /\b[A-Z]{2,4}-03\b/.test(text)) errors.push("theme03-selector-leak");
  if (rawColorLiteral.test(text)) errors.push("adapter-decorative-color-literal");
  if (!text.includes(`data-global-theme-id="${target.id}"`) && !text.includes(`data-global-theme-id='${target.id}'`)) {
    errors.push("target-root-selector-missing");
  }
  const allowed = new Set(target.authorizedMatrixRows || []);
  const matrixIds = new Set((matrix.elements || []).map((row) => row.id));
  for (const id of allowed) if (!matrixIds.has(id)) errors.push(`unknown-authorized-matrix-row:${id}`);
  return errors;
}

function renderTheme(themeId, authority) {
  const { registry, roleSchema } = authority;
  const target = targetFor(registry, themeId);
  const rolePath = resolveRoot(target.roleVectorPath);
  if (!fs.existsSync(rolePath)) throw new Error(`Role vector is absent: ${target.roleVectorPath}`);
  const vector = readJson(rolePath);
  const roleErrors = validateRoleVector(vector, target, roleSchema);
  if (roleErrors.length) throw new Error(`Role vector rejected: ${roleErrors.join(", ")}`);
  const matrix = readJson(resolveRoot(registry.matrix));
  const adapterPath = resolveRoot(target.adapterPath);
  const adapter = fs.existsSync(adapterPath) ? fs.readFileSync(adapterPath, "utf8") : "";
  const adapterErrors = validateAdapter(adapter, target, matrix);
  if (adapterErrors.length) throw new Error(`Adapter rejected: ${adapterErrors.join(", ")}`);
  if (!target.authorizedMatrixRows?.length && adapter.trim()) throw new Error("Adapter exists while no matrix rows are authorized.");
  const header = `/* GENERATED GLOBAL THEME ${themeId} PROJECTION. Source vector: ${target.roleVectorPath}.\n` +
    `   Target adapter: ${target.adapterPath}. USER CT color unification is independent of legacy generation. */\n`;
  return `${header}${renderTokenBlock(themeId, vector.roles)}\n${adapter.trim()}\n`;
}

function renderAggregate(authority) {
  const { registry } = authority;
  const parts = [
    "/* GENERATED TARGET-THEME PROJECTION AGGREGATE. DO NOT EDIT BY HAND.",
    "   Generator: frontend/scripts/generate-global-theme-projection.mjs",
    "   USER CT01–CT10 are governed by the unified color contract. */\n",
  ];
  for (const target of registry.targets) {
    if (!writeStates.has(target.state)) continue;
    parts.push(renderTheme(target.id, authority));
  }
  return parts.join("\n");
}

function plan(authority, themeId) {
  const { registry } = authority;
  const target = targetFor(registry, themeId);
  return {
    themeId,
    state: target.state,
    roleVectorPath: target.roleVectorPath,
    adapterPath: target.adapterPath,
    authorizedMatrixRows: target.authorizedMatrixRows || [],
    qualifiedMatrixRows: target.qualifiedMatrixRows || [],
    writeAllowed: writeStates.has(target.state),
    aggregateOutput: registry.aggregateOutput,
    legacyTargetInRegistry: Boolean(registry.targets.find((item) => item.id === themeId)),
  };
}

function cli() {
  const args = process.argv.slice(2);
  const get = (name) => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : null; };
  const has = (name) => args.includes(name);
  const authority = loadAuthority();
  const themeId = String(get("--theme") || "").padStart(2, "0");
  if (has("--aggregate-check")) {
    const output = renderAggregate(authority);
    process.stdout.write(JSON.stringify({ ok: true, bytes: Buffer.byteLength(output), enabledThemes: authority.registry.targets.filter((t) => writeStates.has(t.state)).map((t) => t.id) }) + "\n");
    return;
  }
  if (!themeId || themeId === "00") throw new Error("--theme NN is required");
  const result = plan(authority, themeId);
  if (has("--plan")) { process.stdout.write(JSON.stringify(result, null, 2) + "\n"); return; }
  if (has("--render")) { process.stdout.write(renderTheme(themeId, authority)); return; }
  if (has("--write")) {
    if (!result.writeAllowed) throw new Error(`Target ${themeId} is ${result.state}; runtime generation is fail-closed.`);
    const aggregate = renderAggregate(authority);
    const outPath = resolveRoot(authority.registry.aggregateOutput);
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    fs.writeFileSync(outPath, aggregate);
    process.stdout.write(JSON.stringify({ ok: true, output: rel(outPath), bytes: Buffer.byteLength(aggregate) }) + "\n");
    return;
  }
  process.stdout.write(JSON.stringify(result, null, 2) + "\n");
}

export { loadAuthority, plan, renderAggregate, renderTheme, validateAdapter, validateRoleVector };

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  try { cli(); } catch (error) { console.error(String(error?.message || error)); process.exit(2); }
}
