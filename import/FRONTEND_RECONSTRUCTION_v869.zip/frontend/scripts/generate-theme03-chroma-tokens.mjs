import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const frontendRoot = path.resolve(here, "..");
const repoRoot = path.resolve(frontendRoot, "..");
const sourcePath = path.join(frontendRoot, "src", "design-system", "theme03-chroma.json");
const outputPath = path.join(frontendRoot, "src", "styles", "generated", "theme03-chroma-tokens.css");

const roleToVar = Object.freeze({
  canvas: "--efhc-color-canvas",
  page: "--efhc-color-page",
  chrome: "--efhc-color-chrome",
  chromeInset: "--efhc-color-chrome-inset",
  hero: "--efhc-color-hero",
  card: "--efhc-color-card",
  inset: "--efhc-color-inset",
  active: "--efhc-color-active",
  accent: "--efhc-color-accent",
  accentSoft: "--efhc-color-accent-soft",
  accentStrong: "--efhc-color-accent-strong",
  border: "--efhc-color-border",
  borderStrong: "--efhc-color-border-strong",
  text: "--efhc-color-text",
  textMuted: "--efhc-color-text-muted",
  shadow: "--efhc-color-shadow",
  glow: "--efhc-color-glow",
  focus: "--efhc-color-focus",
});

const source = JSON.parse(fs.readFileSync(sourcePath, "utf8"));
if (source.schema !== "EFHC_GLOBAL_THEME_CHROMA_V1" || source.themeId !== "03") {
  throw new Error("Unexpected Theme03 chroma source schema/theme id");
}
for (const role of Object.keys(roleToVar)) {
  if (typeof source.roles?.[role] !== "string" || !source.roles[role].trim()) {
    throw new Error(`Missing Theme03 chroma role: ${role}`);
  }
}
const declarations = Object.entries(roleToVar)
  .map(([role, variable]) => `    ${variable}:${source.roles[role]};`)
  .join("\n");
const css = `/* GENERATED FILE — DO NOT EDIT.\n   Source: frontend/src/design-system/theme03-chroma.json\n   ${(source.ownerCycle || source.cycle)}: current USER Theme03 18-role semantic material vector; final role values come from the current machine authority. */\n@layer efhc-theme-tokens {\n  [data-interface-app-mode="user"][data-global-theme-id="03"],\n  :root:has(.efhc-profile-modal-theme[data-pm="PM-03"]),\n  :root:has(.efhc-independent-shell[data-interface-app-mode="user"][data-global-theme-id="03"]),
  .efhc-shop-site[data-interface-app-mode="shop-landing"][data-shop-theme="dark"],
  html[data-shop-theme="dark"] {\n${declarations}\n  }\n}\n`;
fs.writeFileSync(outputPath, css);

const shellAdapterPath = path.join(frontendRoot, "src", "styles", "theme03-shell-chroma.css");
const shellAdapterCss = fs.readFileSync(shellAdapterPath, "utf8").trimEnd() + "\n";
const panelsExchangeAdapterPath = path.join(frontendRoot, "src", "styles", "theme03-panels-exchange-chroma.css");
const panelsExchangeAdapterCss = fs.readFileSync(panelsExchangeAdapterPath, "utf8").trimEnd() + "\n";
const tasksReferralsAdapterPath = path.join(frontendRoot, "src", "styles", "theme03-tasks-referrals-chroma.css");
const tasksReferralsAdapterCss = fs.readFileSync(tasksReferralsAdapterPath, "utf8").trimEnd() + "\n";
const ranksProfileAdapterPath = path.join(frontendRoot, "src", "styles", "theme03-ranks-profile-chroma.css");
const ranksProfileAdapterCss = fs.readFileSync(ranksProfileAdapterPath, "utf8").trimEnd() + "\n";
const energyAdapterPath = path.join(frontendRoot, "src", "styles", "theme03-energy-chroma.css");
const energyAdapterCss = fs.readFileSync(energyAdapterPath, "utf8").trimEnd() + "\n";
const faqAdapterPath = path.join(frontendRoot, "src", "styles", "theme03-faq-chroma.css");
const faqAdapterCss = fs.readFileSync(faqAdapterPath, "utf8").trimEnd() + "\n";
const historyAdapterPath = path.join(frontendRoot, "src", "styles", "theme03-balance-history-chroma.css");
const historyAdapterCss = fs.readFileSync(historyAdapterPath, "utf8").trimEnd() + "\n";
const browserShopAdapterPath = path.join(frontendRoot, "src", "styles", "theme03-browser-shop-chroma.css");
const browserShopAdapterCss = fs.readFileSync(browserShopAdapterPath, "utf8").trimEnd() + "\n";

function updateStandalone(filePath) {
  if (!fs.existsSync(filePath)) return false;
  const begin = "<!-- THEME03_CHROMA_SSOT_BEGIN -->";
  const end = "<!-- THEME03_CHROMA_SSOT_END -->";
  const block = `${begin}\n<style id="theme03-chroma-ssot-generated">\n${css}</style>\n${end}`;
  const shellBegin = "<!-- THEME03_SHELL_CHROMA_BEGIN -->";
  const shellEnd = "<!-- THEME03_SHELL_CHROMA_END -->";
  const shellBlock = `${shellBegin}\n<style id="theme03-shell-chroma-source">\n${shellAdapterCss}</style>\n${shellEnd}`;
  const pageBegin = "<!-- THEME03_PANELS_EXCHANGE_CHROMA_BEGIN -->";
  const pageEnd = "<!-- THEME03_PANELS_EXCHANGE_CHROMA_END -->";
  const pageBlock = `${pageBegin}\n<style id="theme03-panels-exchange-chroma-source">\n${panelsExchangeAdapterCss}</style>\n${pageEnd}`;
  const engagementBegin = "<!-- THEME03_TASKS_REFERRALS_CHROMA_BEGIN -->";
  const engagementEnd = "<!-- THEME03_TASKS_REFERRALS_CHROMA_END -->";
  const engagementBlock = `${engagementBegin}\n<style id="theme03-tasks-referrals-chroma-source">\n${tasksReferralsAdapterCss}</style>\n${engagementEnd}`;
  const accountBegin = "<!-- THEME03_RANKS_PROFILE_CHROMA_BEGIN -->";
  const accountEnd = "<!-- THEME03_RANKS_PROFILE_CHROMA_END -->";
  const accountBlock = `${accountBegin}\n<style id="theme03-ranks-profile-chroma-source">\n${ranksProfileAdapterCss}</style>\n${accountEnd}`;
  const energyBegin = "<!-- THEME03_ENERGY_CHROMA_BEGIN -->";
  const energyEnd = "<!-- THEME03_ENERGY_CHROMA_END -->";
  const energyBlock = `${energyBegin}\n<style id="theme03-energy-chroma-source">\n${energyAdapterCss}</style>\n${energyEnd}`;
  const faqBegin = "<!-- THEME03_FAQ_CHROMA_BEGIN -->";
  const faqEnd = "<!-- THEME03_FAQ_CHROMA_END -->";
  const faqBlock = `${faqBegin}\n<style id="theme03-faq-chroma-source">\n${faqAdapterCss}</style>\n${faqEnd}`;
  const historyBegin = "<!-- THEME03_BALANCE_HISTORY_CHROMA_BEGIN -->";
  const historyEnd = "<!-- THEME03_BALANCE_HISTORY_CHROMA_END -->";
  const historyBlock = `${historyBegin}\n<style id="theme03-balance-history-chroma-source">\n${historyAdapterCss}</style>\n${historyEnd}`;
  const browserShopBegin = "<!-- THEME03_BROWSER_SHOP_CHROMA_BEGIN -->";
  const browserShopEnd = "<!-- THEME03_BROWSER_SHOP_CHROMA_END -->";
  const browserShopBlock = `${browserShopBegin}\n<style id="theme03-browser-shop-chroma-source">\n${browserShopAdapterCss}</style>\n${browserShopEnd}`;
  let html = fs.readFileSync(filePath, "utf8");
  const currentBlocks = [
    [begin, end, block],
    [shellBegin, shellEnd, shellBlock],
    [pageBegin, pageEnd, pageBlock],
    [engagementBegin, engagementEnd, engagementBlock],
    [accountBegin, accountEnd, accountBlock],
    [energyBegin, energyEnd, energyBlock],
    [faqBegin, faqEnd, faqBlock],
    [historyBegin, historyEnd, historyBlock],
    [browserShopBegin, browserShopEnd, browserShopBlock],
  ];

  // Cycle0383 parity law: the current Theme03 semantic layer must be the final
  // USER/Browser-Shop chroma authority in standalone documents. Historical
  // release blocks are retained as evidence, but must not outrank current
  // adapters merely because they appear later in the legacy HTML cascade.
  for (const [blockBegin, blockEnd] of currentBlocks) {
    for (;;) {
      const blockStart = html.indexOf(blockBegin);
      if (blockStart < 0) break;
      const blockFinish = html.indexOf(blockEnd, blockStart);
      if (blockFinish < blockStart) throw new Error(`Unclosed ${blockBegin} in ${filePath}`);
      html = html.slice(0, blockStart) + html.slice(blockFinish + blockEnd.length);
    }
  }
  const headEnd = html.lastIndexOf("</head>");
  if (headEnd < 0) throw new Error(`No </head> in ${filePath}`);
  const canonicalTheme03Layer = currentBlocks.map(([, , currentBlock]) => currentBlock).join("\n");
  html = html.slice(0, headEnd) + `${canonicalTheme03Layer}\n` + html.slice(headEnd);
  fs.writeFileSync(filePath, html);
  return true;
}

const standaloneArg = process.argv.find((arg) => arg.startsWith("--standalone="));
const standalonePath = standaloneArg
  ? path.resolve(repoRoot, standaloneArg.slice("--standalone=".length))
  : null;
if (standalonePath) updateStandalone(standalonePath);

console.log(`Theme03 chroma tokens generated: ${path.relative(repoRoot, outputPath)}`);
if (standalonePath) console.log(`Theme03 standalone token/shell/page/engagement/account/energy/faq/history blocks synchronized: ${path.relative(repoRoot, standalonePath)}`);
