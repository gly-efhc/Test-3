import { readdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
const directory = resolve("public/audio/background");
const names = (await readdir(directory)).filter((name) => /^[1-9]\d*\.mp3$/i.test(name));
names.sort((a, b) => Number.parseInt(a, 10) - Number.parseInt(b, 10));
await writeFile(resolve(directory, "playlist.json"), JSON.stringify(names, null, 2) + "\n");
console.log(`EFHC music: ${names.length} tracks in numerical order`);
