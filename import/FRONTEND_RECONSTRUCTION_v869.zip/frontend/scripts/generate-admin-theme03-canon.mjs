import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const frontendRoot = path.resolve(here, "..");
const repoRoot = path.resolve(frontendRoot, "..");
const adminSourcePath = path.join(frontendRoot, "src", "design-system", "admin-theme03-canon.json");
const outputPath = path.join(frontendRoot, "src", "styles", "generated", "admin-theme03-canon-tokens.css");
const adapterPath = path.join(frontendRoot, "src", "styles", "admin-theme03-canon.css");

const roleToVar = Object.freeze({
  canvas: "--efhc-admin-canon-canvas",
  page: "--efhc-admin-canon-page",
  chrome: "--efhc-admin-canon-chrome",
  chromeInset: "--efhc-admin-canon-chrome-inset",
  hero: "--efhc-admin-canon-hero",
  card: "--efhc-admin-canon-card",
  inset: "--efhc-admin-canon-inset",
  active: "--efhc-admin-canon-active",
  accent: "--efhc-admin-canon-accent",
  accentSoft: "--efhc-admin-canon-accent-soft",
  accentStrong: "--efhc-admin-canon-accent-strong",
  border: "--efhc-admin-canon-border",
  borderStrong: "--efhc-admin-canon-border-strong",
  text: "--efhc-admin-canon-text",
  textMuted: "--efhc-admin-canon-text-muted",
  shadow: "--efhc-admin-canon-shadow",
  glow: "--efhc-admin-canon-glow",
  focus: "--efhc-admin-canon-focus",
});

const admin = JSON.parse(fs.readFileSync(adminSourcePath, "utf8"));
if (admin.schema !== "EFHC_ADMIN_THEME03_CANON_V1") {
  throw new Error("Unexpected Admin Theme03 canon schema");
}
const frozenRoles = admin.frozenRoles;
if (!frozenRoles || typeof frozenRoles !== "object") {
  throw new Error("Missing frozen Admin Theme03 role vector");
}
const rolePayload = JSON.stringify(
  Object.fromEntries(Object.entries(frozenRoles).sort(([a], [b]) => a.localeCompare(b))),
);
const roleHash = crypto.createHash("sha256").update(rolePayload).digest("hex");
if (roleHash !== admin.sourceTheme03RoleSha256) {
  throw new Error(`Theme03 role hash drift: expected ${admin.sourceTheme03RoleSha256}, got ${roleHash}`);
}
for (const role of Object.keys(roleToVar)) {
  if (typeof frozenRoles?.[role] !== "string" || !frozenRoles[role].trim()) {
    throw new Error(`Missing frozen Admin Theme03 role ${role}`);
  }
}
const pages = Array.isArray(admin.migratedPages) ? admin.migratedPages : [];
if (!pages.length) throw new Error("No migrated Admin pages configured");
const selectors = [];
if (admin.globalAdminHeader?.enabled === true) {
  selectors.push('  .efhc-independent-shell[data-interface-app-mode="admin"]');
}
for (const page of pages) {
  if (!page?.marker || !page?.standaloneId) throw new Error("Admin migrated page requires marker and standaloneId");
  const productionSelectorExact = page.productionSelectorExact;
  const productionSelector = page.productionSelector || ".efhc-admin-shell";
  if (productionSelectorExact != null) {
    if (typeof productionSelectorExact !== "string" || !productionSelectorExact.startsWith(".efhc-admin-shell")) {
      throw new Error(`Unsafe exact Admin production selector for ${page.marker}`);
    }
    selectors.push(`  ${productionSelectorExact}`);
  } else {
    if (typeof productionSelector !== "string" || !productionSelector.startsWith(".")) {
      throw new Error(`Unsafe Admin production selector for ${page.marker}`);
    }
    selectors.push(`  ${productionSelector}[data-admin-page-marker="${page.marker}"]`);
  }
  selectors.push(`  .efhc-independent-shell[data-interface-app-mode="admin"] #${page.standaloneId}[data-admin-page-marker="${page.marker}"]`);
  for (const portalSelector of page.portalSelectors || []) {
    if (typeof portalSelector !== "string" || !portalSelector.startsWith(".")) {
      throw new Error(`Unsafe Admin portal selector for ${page.marker}`);
    }
    selectors.push(`  ${portalSelector}`);
  }
}
const declarations = Object.entries(roleToVar)
  .map(([role, variable]) => `    ${variable}:${frozenRoles[role]};`)
  .join("\n");
const css = `/* GENERATED FILE — DO NOT EDIT.\n   Frozen role source: frontend/src/design-system/admin-theme03-canon.json#frozenRoles\n   Provenance binding: ${admin.sourceTheme03RoleSha256}\n   ${(admin.decoupledCycle || admin.cycle)} / ${(admin.decoupledRelease || admin.release)}: Admin consumes its frozen role vector independently from live USER Theme03. */\n@layer efhc-admin-theme03-tokens {\n${selectors.join(",\n")} {\n${declarations}\n  }\n}\n`;
fs.writeFileSync(outputPath, css);

function replaceBlock(html, begin, end, block) {
  const start = html.indexOf(begin);
  const finish = html.indexOf(end);
  if (start >= 0 && finish >= start) {
    return html.slice(0, start) + block + html.slice(finish + end.length);
  }
  const headEnd = html.indexOf("</head>");
  if (headEnd < 0) throw new Error("Standalone HTML has no </head>");
  return html.slice(0, headEnd) + `${block}\n` + html.slice(headEnd);
}

function updateStandalone(filePath) {
  if (!fs.existsSync(filePath)) throw new Error(`Standalone not found: ${filePath}`);
  let html = fs.readFileSync(filePath, "utf8");
  const tokenBegin = "<!-- ADMIN_THEME03_CANON_TOKENS_BEGIN -->";
  const tokenEnd = "<!-- ADMIN_THEME03_CANON_TOKENS_END -->";
  const tokenBlock = `${tokenBegin}\n<style id="admin-theme03-canon-tokens-generated">\n${css}</style>\n${tokenEnd}`;
  html = replaceBlock(html, tokenBegin, tokenEnd, tokenBlock);

  const adapterCss = fs.readFileSync(adapterPath, "utf8").trimEnd() + "\n";
  const adapterBegin = "<!-- ADMIN_THEME03_CANON_ADAPTER_BEGIN -->";
  const adapterEnd = "<!-- ADMIN_THEME03_CANON_ADAPTER_END -->";
  const adapterBlock = `${adapterBegin}\n<style id="admin-theme03-canon-adapter-source">\n${adapterCss}</style>\n${adapterEnd}`;
  html = replaceBlock(html, adapterBegin, adapterEnd, adapterBlock);
  fs.writeFileSync(filePath, html);
}

const standaloneArg = process.argv.find((arg) => arg.startsWith("--standalone="));
if (standaloneArg) {
  updateStandalone(path.resolve(repoRoot, standaloneArg.slice("--standalone=".length)));
}
console.log(`Admin Theme03 canon tokens generated: ${path.relative(repoRoot, outputPath)}`);
if (standaloneArg) console.log("Admin Theme03 standalone canon blocks synchronized");
