import fs from "node:fs";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawn } from "node:child_process";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.resolve(__dirname, "../..");
const DEFAULT_PLAN = path.join(ROOT, "frontend/tests/visual/global-theme-matrix-probes.json");
const ROLE_SCHEMA = path.join(ROOT, "frontend/src/design-system/global-theme-role-schema.json");

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const readJson = (p) => JSON.parse(fs.readFileSync(p, "utf8"));

async function freePort() {
  return await new Promise((resolve, reject) => {
    const server = net.createServer();
    server.unref();
    server.on("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const address = server.address();
      const port = typeof address === "object" && address ? address.port : 0;
      server.close(() => resolve(port));
    });
  });
}

function chromiumBinary() {
  const candidates = [process.env.CHROMIUM_BIN, "/usr/bin/chromium", "/usr/bin/chromium-browser", "/usr/bin/google-chrome"].filter(Boolean);
  for (const candidate of candidates) if (fs.existsSync(candidate)) return candidate;
  throw new Error("Chromium executable not found. Set CHROMIUM_BIN.");
}

class Cdp {
  constructor(ws) {
    this.ws = ws;
    this.nextId = 1;
    this.pending = new Map();
    ws.addEventListener("message", (event) => {
      const payload = JSON.parse(String(event.data));
      if (!payload.id) return;
      const item = this.pending.get(payload.id);
      if (!item) return;
      this.pending.delete(payload.id);
      if (payload.error) item.reject(new Error(payload.error.message || JSON.stringify(payload.error)));
      else item.resolve(payload.result || {});
    });
  }
  send(method, params = {}) {
    const id = this.nextId++;
    const payload = JSON.stringify({ id, method, params });
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(payload);
    });
  }
  async evaluate(expression, returnByValue = true) {
    const result = await this.send("Runtime.evaluate", { expression, awaitPromise: true, returnByValue });
    if (result.exceptionDetails) throw new Error(result.exceptionDetails.text || "Runtime.evaluate failed");
    return result.result?.value;
  }
  close() { try { this.ws.close(); } catch {} }
}

async function waitJson(url, attempts = 80) {
  let last;
  for (let i = 0; i < attempts; i += 1) {
    try {
      const response = await fetch(url);
      if (response.ok) return await response.json();
      last = new Error(`${response.status} ${response.statusText}`);
    } catch (error) { last = error; }
    await sleep(50);
  }
  throw last || new Error(`Timed out: ${url}`);
}

async function waitReady(cdp) {
  for (let i = 0; i < 100; i += 1) {
    const state = await cdp.evaluate("document.readyState").catch(() => "");
    if (state === "complete") { await sleep(90); return; }
    await sleep(40);
  }
  throw new Error("Document did not reach readyState=complete");
}

async function openBrowser(width, height) {
  const port = await freePort();
  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), "efhc-theme-harness-"));
  const child = spawn(chromiumBinary(), [
    "--headless=new", "--no-sandbox", "--disable-gpu", "--disable-dev-shm-usage",
    "--allow-file-access-from-files", `--remote-debugging-port=${port}`, `--user-data-dir=${userDataDir}`, "about:blank",
  ], { stdio: "ignore" });
  const version = await waitJson(`http://127.0.0.1:${port}/json/version`);
  const target = await fetch(`http://127.0.0.1:${port}/json/new?${encodeURIComponent("about:blank")}`, { method: "PUT" }).then((r) => r.json());
  const ws = new WebSocket(target.webSocketDebuggerUrl || version.webSocketDebuggerUrl);
  await new Promise((resolve, reject) => { ws.addEventListener("open", resolve, { once: true }); ws.addEventListener("error", reject, { once: true }); });
  const cdp = new Cdp(ws);
  await cdp.send("Page.enable");
  await cdp.send("Runtime.enable");
  await cdp.send("Emulation.setDeviceMetricsOverride", { width, height, deviceScaleFactor: 1, mobile: true });
  return { cdp, child, userDataDir };
}

async function loadStandaloneContent(cdp, file) {
  const frameTree = await cdp.send("Page.getFrameTree");
  const frameId = frameTree.frameTree?.frame?.id;
  if (!frameId) throw new Error("Chromium main frame is unavailable.");
  const html = fs.readFileSync(path.resolve(file), "utf8");
  await cdp.send("Page.setDocumentContent", { frameId, html });
  await waitReady(cdp);
}

async function configureFrontend(cdp, themeId) {
  // Standalone theme state is private inside the product IIFE. Exercise the
  // existing UI/event contract instead of reaching into lexical state or
  // relying on file:// localStorage.
  for (let i = 0; i < 50; i += 1) {
    const ready = await cdp.evaluate(`document.querySelector('.efhc-independent-shell')?.dataset.globalThemeId || ''`);
    if (ready) break;
    await sleep(40);
  }
  let current = await cdp.evaluate(`document.querySelector('.efhc-independent-shell')?.dataset.globalThemeId || ''`);
  if (!current) { const diag = await cdp.evaluate(`({readyState:document.readyState, shell:!!document.querySelector('.efhc-independent-shell'), shellMode:document.querySelector('.efhc-independent-shell')?.dataset.interfaceAppMode||'', htmlTheme:document.documentElement.dataset.globalThemeId||'', bodyLength:document.body?.innerHTML.length||0, techTabs:document.querySelectorAll('[data-tech-page-index]').length, href:location.href, title:document.title, bodyText:(document.body?.innerText||'').slice(0,240)})`); throw new Error(`Standalone USER Global Theme marker is unavailable: ${JSON.stringify(diag)}`); }
  if (current === themeId) return;

  const direct = await cdp.evaluate(`(() => {
    const choice = document.querySelector('[data-select-global-theme="${themeId}"]');
    if (!choice) return false;
    choice.click();
    return true;
  })()`);
  if (direct) {
    await sleep(80);
    current = await cdp.evaluate(`document.querySelector('.efhc-independent-shell')?.dataset.globalThemeId || ''`);
    if (current === themeId) return;
  }

  const ids = ['01','02','03','04','05','06','07','08','09','10','11','12','13'];
  const from = ids.indexOf(current);
  const to = ids.indexOf(themeId);
  if (from < 0 || to < 0) throw new Error(`Unsupported Global Theme transition ${current} -> ${themeId}`);
  const opened = await cdp.evaluate(`(() => {
    const button=document.querySelector('#customizeButton');
    if(!button) return false;
    button.click();
    return document.querySelector('#globalThemeControl')?.hidden === false;
  })()`);
  if (!opened) throw new Error('Standalone customization mode could not be opened.');
  const steps = (to - from + ids.length) % ids.length;
  for (let i = 0; i < steps; i += 1) {
    const cycled = await cdp.evaluate(`(() => {
      const button=document.querySelector('#globalThemeControl');
      if(!button || button.hidden) return false;
      button.click();
      return true;
    })()`);
    if (!cycled) throw new Error('Standalone Global Theme control became unavailable.');
    await sleep(25);
  }
  current = await cdp.evaluate(`document.querySelector('.efhc-independent-shell')?.dataset.globalThemeId || ''`);
  if (current !== themeId) throw new Error(`Standalone frontend did not activate Global Theme ${themeId}; current=${current}`);
  const closed = await cdp.evaluate(`(() => {
    const button=document.querySelector('#customizeButton');
    if(!button) return false;
    button.click();
    return document.querySelector('#globalThemeControl')?.hidden === true;
  })()`);
  if (!closed) throw new Error('Standalone customization mode could not be closed.');
}

async function configureShop(cdp, themeId) {
  await cdp.evaluate(`document.documentElement.dataset.shopTheme='dark'; document.documentElement.dataset.globalThemeId=${JSON.stringify(themeId)}; if (typeof shopTheme !== \"undefined\") shopTheme='dark'; true`);
  await sleep(80);
}

async function routeFrontend(cdp, route) {
  if (!route) return;
  const nativeSelectors = {
    '/': '.efhc-game-nav_item[data-route="/"]',
    '/panels': '.efhc-game-nav_item[data-route="/panels"]',
    '/exchange': '.efhc-game-nav_item[data-route="/exchange"]',
    '/tasks': '.efhc-game-nav_item[data-route="/tasks"]',
    '/referrals': '.efhc-game-nav_item[data-route="/referrals"]',
    '/ranks': '.efhc-game-nav_item[data-route="/ranks"]',
    '/panels/portfolio': '[data-route-direct="/panels/portfolio"]',
    '/referrals/my': '[data-route-direct="/referrals/my"]',
    '/web-profile': '[data-profile-open]',
    '/faq': '[data-route-direct="/faq"]',
    '/withdraw': '[data-route-direct="/withdraw"]',
    '/hub': '.efhc-header-action[data-action="HUB"]',
    '/browser-shop': '.efhc-header-action[data-action="Deposit"]'
  };
  const selector = nativeSelectors[route];
  if (selector) {
    const clicked = await cdp.evaluate(`(() => { const node=document.querySelector(${JSON.stringify(selector)}); if(!node)return false; node.click(); return true; })()`);
    if (clicked) { await sleep(90); return; }
  }

  // Standalone Technical Workbench is an existing project QA route switcher and
  // covers owner surfaces that have no ordinary direct launcher (Ads/System).
  const techIndexes = {'/':1,'/panels':3,'/exchange':4,'/tasks':5,'/referrals':6,'/ranks':7,'/web-profile':8,'/hub':9,'/faq':10,'/withdraw':11,'/ads':12,'/browser-shop':13,'/404':14};
  const index = techIndexes[route];
  if (index !== undefined) {
    const clicked = await cdp.evaluate(`(() => { const node=document.querySelector('[data-tech-page-index="${index}"]'); if(!node)return false; node.click(); return true; })()`);
    if (clicked) { await sleep(90); return; }
  }
  throw new Error(`No standalone route control is available for ${route}`);
}

async function runSetup(cdp, setup = []) {
  for (const expression of setup) {
    await cdp.evaluate(`(()=>{${expression}; return true;})()`);
    await sleep(55);
  }
}

async function capture(cdp, selectors, properties, roleOrder, surface) {
  const payload = await cdp.evaluate(`(() => {
    const selectors=${JSON.stringify(selectors)};
    const properties=${JSON.stringify(properties)};
    const roleOrder=${JSON.stringify(roleOrder)};
    const roleName=(role)=>'--efhc-color-'+role.replace(/[A-Z]/g,m=>'-'+m.toLowerCase());
    const visible=(node)=>{ if(!node) return false; const s=getComputedStyle(node); const r=node.getBoundingClientRect(); return s.display!=='none'&&s.visibility!=='hidden'&&Number(s.opacity||1)!==0&&r.width>0&&r.height>0; };
    let node=null,selector=null;
    for(const candidate of selectors){ const current=document.querySelector(candidate); if(current&&visible(current)){node=current;selector=candidate;break;} }
    if(!node){ for(const candidate of selectors){ const current=document.querySelector(candidate); if(current){node=current;selector=candidate;break;} } }
    const roleHost=${JSON.stringify(surface)}==='shop' ? document.documentElement : (document.querySelector('.efhc-independent-shell')||document.documentElement);
    const roleStyle=getComputedStyle(roleHost);
    const roles={}; for(const role of roleOrder)roles[role]=roleStyle.getPropertyValue(roleName(role)).trim();
    if(!node)return {found:false,selector:null,visible:false,roles};
    const style=getComputedStyle(node); const rect=node.getBoundingClientRect(); const computed={}; for(const property of properties)computed[property]=style[property]??'';
    return {found:true,selector,visible:visible(node),computed,rect:{x:rect.x,y:rect.y,width:rect.width,height:rect.height,bottom:rect.bottom,right:rect.right},roles};
  })()`);
  return payload;
}

async function runSurface({ file, themeId, width, height, probes, surface, properties, roleOrder }) {
  const browser = await openBrowser(width, height);
  const results = [];
  try {
    await loadStandaloneContent(browser.cdp, file);
    if (surface === "frontend") await configureFrontend(browser.cdp, themeId);
    else await configureShop(browser.cdp, themeId);
    for (const probe of probes) {
      try {
        if (surface === "frontend") await routeFrontend(browser.cdp, probe.route);
        await runSetup(browser.cdp, probe.setup);
        const evidence = await capture(browser.cdp, probe.selectors, properties, roleOrder, surface);
        results.push({ id: probe.id, status: evidence.found && evidence.visible ? "HARNESS_PROBE_PASS" : "HARNESS_PROBE_FAIL", ...evidence });
      } catch (error) {
        results.push({ id: probe.id, status: "HARNESS_PROBE_FAIL", error: String(error?.message || error) });
      }
    }
  } finally {
    browser.cdp.close();
    if (browser.child.exitCode === null) {
      browser.child.kill("SIGTERM");
      await Promise.race([
        new Promise((resolve) => browser.child.once("exit", resolve)),
        sleep(750),
      ]);
    }
    if (browser.child.exitCode === null) browser.child.kill("SIGKILL");
    await sleep(80);
    fs.rmSync(browser.userDataDir, { recursive: true, force: true, maxRetries: 5, retryDelay: 80 });
  }
  return results;
}

async function main() {
  const args = process.argv.slice(2);
  const get = (name, fallback = null) => { const i = args.indexOf(name); return i >= 0 ? args[i + 1] : fallback; };
  const frontend = get("--frontend");
  const shop = get("--shop");
  const themeId = String(get("--theme", "03")).padStart(2, "0");
  const width = Number(get("--width", "390"));
  const height = Number(get("--height", "844"));
  const plan = readJson(path.resolve(get("--plan", DEFAULT_PLAN)));
  const roleSchema = readJson(ROLE_SCHEMA);
  const requested = String(get("--rows", "")).split(",").map((x) => x.trim()).filter(Boolean);
  const selected = requested.length ? plan.probes.filter((p) => requested.includes(p.id)) : plan.probes;
  if (requested.length && selected.length !== requested.length) throw new Error("One or more requested matrix row IDs are absent from the probe plan.");
  const surfaces = new Map();
  for (const probe of selected) {
    if (!surfaces.has(probe.surface)) surfaces.set(probe.surface, []);
    surfaces.get(probe.surface).push(probe);
  }
  const output = { schema: "EFHC_GLOBAL_THEME_MATRIX_HARNESS_RESULT_V1", themeId, width, height, results: [], note: "HARNESS_PROBE_PASS is runtime reachability/computed evidence, not final visual acceptance." };
  if (surfaces.has("frontend")) {
    if (!frontend) throw new Error("--frontend is required for frontend probes");
    output.results.push(...await runSurface({ file: frontend, themeId, width, height, probes: surfaces.get("frontend"), surface: "frontend", properties: plan.computedProperties, roleOrder: roleSchema.roleOrder }));
  }
  if (surfaces.has("shop")) {
    if (!shop) throw new Error("--shop is required for shop probes");
    output.results.push(...await runSurface({ file: shop, themeId, width, height, probes: surfaces.get("shop"), surface: "shop", properties: plan.computedProperties, roleOrder: roleSchema.roleOrder }));
  }
  output.pass = output.results.every((item) => item.status === "HARNESS_PROBE_PASS");
  output.passed = output.results.filter((item) => item.status === "HARNESS_PROBE_PASS").length;
  output.failed = output.results.length - output.passed;
  const outPath = get("--output");
  const serialized = JSON.stringify(output, null, 2) + "\n";
  if (outPath) fs.writeFileSync(path.resolve(outPath), serialized);
  process.stdout.write(serialized);
  process.exitCode = output.pass ? 0 : 1;
}

if (process.argv[1] && path.resolve(process.argv[1]) === __filename) {
  main().catch((error) => { console.error(String(error?.stack || error)); process.exit(2); });
}
