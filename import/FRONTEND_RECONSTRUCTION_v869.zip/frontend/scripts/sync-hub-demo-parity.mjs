// Synchronize the approved DEMO HUB surface from a single CSS source.
// Run after any change to frontend/src/styles/hub-demo-react-parity.css.
// The source applies to React and standalone using precisely the same declarations.
import { readFileSync, writeFileSync, readdirSync } from 'node:fs';
import { resolve } from 'node:path';
const root=resolve(import.meta.dirname, '../..');
const css=readFileSync(resolve(root,'frontend/src/styles/hub-demo-react-parity.css'),'utf8').trimEnd();
const htmlFiles=readdirSync(root).filter(f=>/^FRONTEND_v\d+\.html$/.test(f));
if(htmlFiles.length!==1) throw Error(`Expected exactly one physical standalone HTML; found ${htmlFiles.length}`);
const target=resolve(root,htmlFiles[0]);
const html=readFileSync(target,'utf8');
const markerStart='<style id="hub-demo-react-parity">\n';
const markerEnd='\n</style>';
const block=markerStart+css+markerEnd;
const existing=new RegExp('<style id="hub-demo-react-parity">[\\s\\S]*?<\\/style>','g');
const matches=[...html.matchAll(existing)];
if(matches.length>1) throw Error('Duplicate HUB parity style');
const next=matches.length===1?html.replace(existing,block):html.replace('</body>',`${block}\n</body>`);
if(next===html && !html.includes(block)) throw Error('Could not update standalone style');
if(!next.includes(block) || next.split(markerStart).length!==2)throw Error('HUB parity block insertion failed');
if(next!==html)writeFileSync(target,next,'utf8');
process.stdout.write(`HUB parity synchronized: ${htmlFiles[0]} / ${css.length} CSS bytes\n`);
