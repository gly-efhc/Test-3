import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import {
  brotliCompressSync,
  constants,
  gzipSync,
} from "node:zlib";
import { dirname, join, resolve } from "node:path";

const root = process.cwd();
const projectRoot = resolve(root, "..");
const nextRoot = join(root, ".next");
const manifest = JSON.parse(
  readFileSync(join(nextRoot, "build-manifest.json"), "utf8"),
);
const updatePolicy = JSON.parse(
  readFileSync(
    join(projectRoot, "release_config", "UPDATE_POLICY.json"),
    "utf8",
  ),
);
const archiveVersion =
  process.env.EFHC_RELEASE_VERSION ||
  readFileSync(join(projectRoot, "VERSION"), "utf8").trim();
const baselineVersion =
  process.env.EFHC_BASELINE_VERSION || "v172.89";
const minimumSupportedSourceVersion =
  process.env.EFHC_MINIMUM_SOURCE_VERSION ||
  updatePolicy.minimum_supported_source_version;
const outputPath = resolve(
  process.env.EFHC_BUDGET_OUTPUT ||
    join(
      projectRoot,
      ".local_artifacts/performance",
      `frontend_compressed_route_budgets_${archiveVersion}.json`,
    ),
);
const baselinePath = resolve(
  process.env.EFHC_BUDGET_BASELINE ||
    join(
      projectRoot,
      "reports/generated/generated",
      `frontend_compressed_route_budgets_${baselineVersion}.json`,
    ),
);

function limits(route) {
  if (route === "/faq") return { gzip: 300_000, brotli: 250_000 };
  if (route.startsWith("/admin")) {
    return { gzip: 420_000, brotli: 350_000 };
  }
  return { gzip: 420_000, brotli: 370_000 };
}

function readBaseline() {
  if (!existsSync(baselinePath)) return new Map();
  try {
    const value = JSON.parse(readFileSync(baselinePath, "utf8"));
    return new Map((value.rows || []).map((row) => [row.route, row]));
  } catch {
    return new Map();
  }
}

function delta(current, previous) {
  if (!Number.isFinite(previous) || previous <= 0) return null;
  return Number((((current - previous) / previous) * 100).toFixed(2));
}

const baseline = readBaseline();
const rows = [];
for (const [route, files] of Object.entries(manifest.pages || {})) {
  const assets = [...new Set(files)].filter(
    (file) => file.endsWith(".js") || file.endsWith(".css"),
  );
  let raw = 0;
  let gzip = 0;
  let brotli = 0;
  for (const file of assets) {
    const path = join(nextRoot, file);
    const content = readFileSync(path);
    raw += statSync(path).size;
    gzip += gzipSync(content, { level: 9 }).length;
    brotli += brotliCompressSync(content, {
      params: {
        [constants.BROTLI_PARAM_QUALITY]: 5,
      },
    }).length;
  }
  const budget = limits(route);
  const previous = baseline.get(route) || {};
  const gzipDelta = delta(gzip, Number(previous.gzip_bytes));
  const brotliDelta = delta(brotli, Number(previous.brotli_bytes));
  const regression =
    (gzipDelta !== null && gzipDelta > 12) ||
    (brotliDelta !== null && brotliDelta > 12);
  rows.push({
    route,
    assets: assets.length,
    raw_bytes: raw,
    gzip_bytes: gzip,
    brotli_bytes: brotli,
    gzip_budget: budget.gzip,
    brotli_budget: budget.brotli,
    previous_gzip_bytes: previous.gzip_bytes || null,
    previous_brotli_bytes: previous.brotli_bytes || null,
    gzip_delta_percent: gzipDelta,
    brotli_delta_percent: brotliDelta,
    comparison: regression ? "REGRESSION_REVIEW" : "OK",
    status:
      gzip <= budget.gzip && brotli <= budget.brotli
        ? "PASS"
        : "FAIL",
  });
}
rows.sort((left, right) => left.route.localeCompare(right.route));
const failed = rows.filter((row) => row.status === "FAIL");
const review = rows.filter(
  (row) => row.comparison === "REGRESSION_REVIEW",
);
mkdirSync(dirname(outputPath), { recursive: true });
writeFileSync(
  outputPath,
  JSON.stringify(
    {
      schema: "EFHC_FRONTEND_COMPRESSED_ROUTE_BUDGETS_V2",
      archive_version: archiveVersion,
      baseline_archive_version: baselineVersion,
      minimum_supported_source_version: minimumSupportedSourceVersion,
      baseline_available: baseline.size > 0,
      status: failed.length ? "FAILED" : "PASSED",
      routes: rows.length,
      failed_routes: failed.map((row) => row.route),
      regression_review_routes: review.map((row) => row.route),
      rows,
    },
    null,
    2,
  ) + "\n",
);
console.log(
  `EFHC COMPRESSED ROUTE BUDGETS: ${failed.length ? "FAIL" : "PASS"}; ` +
    `routes=${rows.length}; failed=${failed.length}; review=${review.length}`,
);
if (failed.length) {
  for (const row of failed) {
    console.error(
      `FAIL route=${row.route} gzip=${row.gzip_bytes}/${row.gzip_budget} ` +
        `brotli=${row.brotli_bytes}/${row.brotli_budget}; ` +
        `assets=${row.assets}; ` +
        `delta_gzip=${row.gzip_delta_percent ?? "n/a"}%; ` +
        `delta_brotli=${row.brotli_delta_percent ?? "n/a"}%`,
    );
    const routeAssets = [...new Set(manifest.pages[row.route] || [])].filter(
      (file) => file.endsWith(".js") || file.endsWith(".css"),
    );
    const largest = routeAssets.map((file) => {
      const buffer = readFileSync(join(nextRoot, file));
      return { file, gzip: gzipSync(buffer, { level: 9 }).length };
    }).sort((a, b) => b.gzip - a.gzip).slice(0, 5);
    for (const item of largest) {
      console.error(`  asset=${item.file} gzip_bytes=${item.gzip}`);
    }
  }
  process.exit(1);
}

// EFHC_BASELINE_VERSION "v172.89"

// EFHC_RELEASE_VERSION берётся из root VERSION

// EFHC_MINIMUM_SOURCE_VERSION берётся из UPDATE_POLICY.json
