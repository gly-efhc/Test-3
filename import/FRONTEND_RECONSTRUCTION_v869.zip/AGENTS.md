# AGENTS — FRONTEND RECONSTRUCTION, OWNER SCOPE

Всем агентам: начинать с `START_HERE.md` и `KERNEL.md`, затем читать
`docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md` и индекс. Эти правила — переносимый
контракт новой ветки реконструкции; изменения правил только прямой командой OWNER.

- **Visual SOURCE OF TRUTH:** неизменный `FRONTEND_v866.html`; SHA — в SSOT.
  React следует DEMO; DEMO никогда не следует React. Старую разметку/стили React
  удалять/перестраивать только при доказанной визуальной эквивалентности.
- **Production contracts:** не удалять Wallet, TON/Jetton, Global ID, RBAC,
  баланс/ledger, API contracts, точность D8 и активные настройки ради изменения UI.
  Реальные финансовые и админ-действия в публичном DEMO запрещены.
- **UX:** сохранить CT01–CT10, активные Design, защищённую языковую карусель,
  единственную музыку, HUD/HUB 50 px, скрытие только ⚙ через 3 секунды;
  механика 🌐 не меняется. Экран, отсутствующий в DEMO, сначала искать во
  вложенной секции; дизайн не придумывать.
- **Release:** только новый физический фронтенд-ZIP, один импорт, ручная сборка
  Pages. Никаких прямых GitHub writes/PR/deploy без OWNER approval.
- **Evidence:** различать ZIP/локальный source test/Next build/Chromium/Pages
  и OWNER visual acceptance. Нельзя называть CSS fixture доказательством parity.
- **No escalation:** не предлагать дополнительные секреты, токены и инфраструктуру,
  пока нет фактической ошибки и OWNER не согласовал её устранение.
- **Communication:** говорить по-русски, профессионально и прямо; давать файлы,
  путь одной строкой, точный статус; не повторять согласованные вопросы.

Текущие уточнения хранятся в `docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md`.
