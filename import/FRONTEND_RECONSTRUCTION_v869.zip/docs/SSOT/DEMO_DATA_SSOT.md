# DEMO data SSOT — read-only fixtures copied from frozen v866

Authoritative seed is `frontend/src/reconstruction/demo-tables-v866.json`.
Adapters: `demoTables.ts`, `useFrozenDemoTables.ts`. Execution of true React
components only; no shadow HTML renderer, no mutation of production backend.

- Panels: 60 active + 60 archived, 20-row batch, original `PNL-*` identifiers.
- Ranks: 220 generated members + DEMO player, original generator, ties preserved.
- Tasks: 5 source tasks, reward strings, template metadata, 10 ads/day from seed.
- Read-only activation gated by Pages build flag and runtime safety marker.

Do not invent live balances, user identities, TON transactions or completed
withdrawals. When adding future DEMO tables, derive exact deterministic source
from frozen HTML, record field mapping and extend persistent source tests.

Existing tests: `node --test frontend/src/reconstruction/verify-demo-tables.test.mjs`.
