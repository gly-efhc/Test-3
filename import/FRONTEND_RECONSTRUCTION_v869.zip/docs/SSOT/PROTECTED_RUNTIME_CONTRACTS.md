# Runtime protection envelope — reconstruction

Визуальный слой React подлежит полной замене по DEMO, однако остаются
неизменными без отдельного OWNER scope: API/REST contracts, Global ID,
account/session/RBAC, decimal precision D8, wallet/TON/Jetton/TonConnect,
ledger/financial history, комиссии, Energy/Panels экономические правила,
Browser Shop платежи, локализации и сохранённые настройки CT/Design.

Этот документ — boundary, а не дубликат всей production SSOT. Если необходимо
менять функциональные контракты, читать их **из полного основного архива**
(например `docs/SSOT/ECONOMY_CANON.md`, `PANELS_SSOT.md`,
`WALLETS_TONCONNECT_SSOT.md`, `GLOBAL_IDENTITY_SSOT.md`) и получить
новое OWNER-разрешение. Отсутствие backend в рабочем ZIP не отменяет контракты.
