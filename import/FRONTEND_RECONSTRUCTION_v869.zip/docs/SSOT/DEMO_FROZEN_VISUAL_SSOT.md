# Immutable DEMO Visual Authority — SSOT

Файл: `FRONTEND_v866.html` — внешний по отношению к transport ZIP.
SHA-256: `9b6371f5fb62939596b78206f95031c447e9f2b375e62b30704403bb25102aef`.
Физический полный архив исходника: `FRONTEND_v866.zip`, SHA-256
`459cc5d7467f358303e86ef2df92956204dc2bdadd4ea59cd17fe46d2c864e5a`.

Визуальная и поведенческая истина: только реально отрисованный original
standalone DEMO в browser. 5-секундная заставка, скрытие ⚙ после 3 сек,
независимая 🌐, CT01–CT10, защищённая языковая карусель, HUB 50 px,
музыка PCM loop (выключена по умолчанию), выбор Design, Admin visual lock.

Этот SSOT не является разрешением менять экономику, маршруты API, версию
схемы настроек, RBAC, wallet/TON, backend; соответствующие production SSOT
в основном archive остаются авторитетными по функциональной части.

Нельзя считать страницу «приемлемой» по похожему CSS. Полный критерий:
реальный Chromium на React и DEMO, одинаковый route/content/state/viewport,
пиксельная и DOM проверка, отсутствие устаревших элементов, обязательное
OWNER acceptance. Пока FULL_PARITY_CERTIFIED=false.
