# Release discipline — lightweight frontend reconstruction

Обязательное: current OWNER scope, один current HEAD/workspace, один read-only
startup Kernel, доказательство изменённых файлов, регрессионные тесты,
неизменность визуального canon, immutable отчет, полный frontend-only ZIP,
ZIP CRC+SHA, отсутствие дубликатов/unsafe paths, настоящий Pages run.

Версии `FRONTEND_RECONSTRUCTION_vNNN.zip` последовательны и не смешиваются
с полной production линейкой `FRONTEND_vNNN.zip`, ADMIN cycles и numbered reports.
Исправление нескольких связанных элементов — один консолидированный report,
не микрорепорт на каждое действие. Исторические отчёты нельзя переписывать.

Последовательность status: PASS LOCAL SOURCE → PASS NEXT BUILD → PASS CHROMIUM
REACT → PASS GITHUB PAGES → PASS VISUAL PARITY + OWNER acceptance.
Отсутствующий этап = UNVERIFIED, не автоматически PASS.

Нельзя загружать backend/ENV/секреты, ослаблять проверки, включать финансовые
операции в DEMO или заменять зависимость на старую ради сборки.
