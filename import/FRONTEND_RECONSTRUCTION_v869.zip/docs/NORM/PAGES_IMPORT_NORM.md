# Test-3 import and manual Pages publication — NORM

1. Один вход: `import/FRONTEND_RECONSTRUCTION_vNNN.zip` (одновременно только
   один ZIP), `import/README.md` неприкосновенен.
2. `efhc-import.yml` — импорт при загрузке, CRC/path checks, source selection;
   `site/frontend/` и `site/RELEASE.json` обновляются. Архив содержит
   ровно один deploy workflow: `ci/efhc-pages.yml`.
3. Действующий одноразово установленный импортёр должен записать его в
   `.github/workflows/efhc-pages.yml` в том же коммите **если GitHub позволяет**.
   Это изменение workflow-файла имеет отдельное GitHub permission enforcement.
   При отказе GitHub: FAIL, исходный ZIP сохранить, показать точную ошибку,
   не обходить запрет и не требовать токены без решения OWNER.
4. Только OWNER вручную запускает `efhc-pages.yml`: настоящий Next React,
   безопасная DEMO data mode, статическая сборка и проверка маршрутов.
5. После подтверждённой успешной Pages публикации cleanup удаляет совпадающий
   транспортный ZIP; `README.md` всегда остаётся.
6. Новые версии ZIP не требуют переименования обоих постоянных YAML.
7. Не менять исходники напрямую на GitHub, не создавать отдельные таблицы
   вручную, не использовать старый standalone HTML для замены React.
8. Если Pages мигает/циклически добавляет `/Test-3/`, это **FAIL BROWSER**,
   даже при зелёной GitHub Actions сборке. Сверять живой адрес и console.

Текущий `ci/efhc-pages.yml` наследуется из v868. Его действительный end-to-end
успех для нового архива v869 **ещё не подтверждён**. Не обещать PASS.
