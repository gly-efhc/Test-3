# Scope of this artifact

В этой ветке храним только готовый для импорта React Frontend, его public
assets, Pages workflow, read-only DEMO fixtures, компактные SSOT/NORM/governance,
тесты и доказательства конкретного состояния.

Не хранить production backend, реальные секреты, runtime `.env`, полный
исторический архив, большие external audits или непроверенные copied JSX.
`docs/**` и `ops/**` сохраняются **в физическом ZIP**, но действующий
GitHub import переносит только `frontend/src/`, `frontend/public/`,
frontend build settings и `ci/efhc-pages.yml`. Следовательно, GitHub Test-3
не является репозиторием полного governance; **каждый следующий ZIP должен
физически наследовать эти правила**, иначе теряется переносное состояние.

Главный визуальный canon внешнего HTML v866 не включать в transport ZIP и не
использовать для исполнения. Его SHA проверяется отдельно.
