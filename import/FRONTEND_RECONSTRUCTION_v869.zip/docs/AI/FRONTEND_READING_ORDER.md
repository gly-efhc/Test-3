# Reading order — frontend-only reconstruction

**First five, exact:**
1. `START_HERE.md`
2. `AGENTS.md`
3. `KERNEL.md`
4. `docs/AI/FRONTEND_OWNER_OPERATIONAL_LAWS.md`
5. `docs/AI/FRONTEND_READING_ORDER.md`

Then one small read-only Kernel intake. Next:
6. `docs/frontend/FRONTEND_DOCUMENTATION_SCOPE.md`
7. `docs/SSOT/DEMO_FROZEN_VISUAL_SSOT.md`
8. `docs/SSOT/DEMO_DATA_SSOT.md`
9. `docs/SSOT/PROTECTED_RUNTIME_CONTRACTS.md`
10. `docs/NORM/PAGES_IMPORT_NORM.md`
11. `docs/NORM/RECONSTRUCTION_RELEASE_NORM.md`
12. `docs/SSOT/ACTIVE_DOCUMENTATION_INDEX.md`
13. `docs/frontend/FRONTEND_ACTIVE_MAIN_ROADMAP.md`
14. `frontend/RECONSTRUCTION_SCHEMA.md`
15. `frontend/RECONSTRUCTION_ROUTE_MATRIX.csv`
16. `reports/RECONSTRUCTION_REPORT_MANIFEST.json` and last numbered report.

Beyond initial context, only read the exact React/CSS/fixture source, frozen DOM
and browser screenshots necessary for current OWNER task. Do not load full
original production reports/backend by default. When security/financial contracts
are required, consult the *real* full production canonical SSOT read-only.
